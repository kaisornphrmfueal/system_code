Private Sub frmReadCards_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Me.empsign.Text = strUser

            Me.txtBarcode.Text = ""
            Me.txtFGTAG.Text = ""
            Me.lbQtyAll.Text = "Qty."
            Me.lbRemain.Text = "Qty."

            Dim objCon As New MySqlConnection
            Dim strCon, strSql, strIP As String
            strCon = DBConnString.strConn
            With objCon
            If .State = ConnectionState.Open Then .Close()
            .ConnectionString = strCon
            .Open()
            End With

            strIP = getLine(stripaddresslog)

            ' Set focus to txtFGTAG after form load
            Me.txtFGTAG.Focus()

            strSql = "SELECT location_name,line_name FROM rfid_project.rf_location WHERE id_location = '" & strIP & "'"
            Dim dtAdapter As MySqlDataAdapter
            Dim dt As New DataTable
            dtAdapter = New MySqlDataAdapter(strSql, objCon)
            dtAdapter.Fill(dt)

            If dt.Rows.Count <> 0 Then
                ' Me.lblUser.Text = strUser
                Me.lbLocation.Text = CStr(dt.Rows(0)("line_name"))
            Else
                Me.lbLocation.Text = "Can't Select Location"

            End If


            tx_key.Enabled = False
            'btnWrite.Enabled = False

            Dim status As Int16, port As Integer = 0
            While port < 8
                port += 1
                status = rf_init_com(port, 9600)
                If (status <> 0) Then
                    rfidStatus.Text = "Can't connect to  the hardware" & port
                    Continue While
                ElseIf (status = 0) Then
                    rfidStatus.Text = "Connected"
                    Me.Timer1.Interval = 1
                    Me.Timer1.Enabled = True
                    Me.Timer1.Start()
                    Exit While
                Else
                    rfidStatus.Text = "Can't connect to  the hardware" & port
                    Exit While
                End If
            End While

          

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub