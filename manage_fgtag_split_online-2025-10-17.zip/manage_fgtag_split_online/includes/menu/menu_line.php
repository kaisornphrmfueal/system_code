	<div class="menu">
		<ul id="nav" class="dropdown dropdown-horizontal">
    
           <!--  <li><a href="index.php?id=<?=base64_encode('line')?>">Select Line</a></li>--!-->
            <li><a href="index.php?id=<?=base64_encode('print')?>">Print Tag</a></li>
             <li><a href="index.php?id=<?=base64_encode('reprint')?>">Reprint Tag</a></li>
            <li><a href="index.php?id=<?=base64_encode('line_report')?>">Tag Report</a></li>
			 <li><a href="index.php?id=<?=base64_encode('model_list')?>">Model List Report</a></li>
            <li><span class="dir">Upload Data</span>
				<ul>
					   <li><a href="index.php?id=<?=base64_encode('upload_tag')?>">Upload Data to Server</a></li>
                       <li><a href="index.php?id=<?=base64_encode('upload_tag_report')?>">Report Upload Data</a></li>
			   </ul>
		 	</li>
             <li><span class="dir">Update Master Data</span>
				<ul>
					   <li><a href="index.php?id=<?=base64_encode('update_master_data')?>">Update Master Data</a></li>
                       <li><a href="index.php?id=<?=base64_encode('update_master_data_report')?>">History Update Master Data</a></li>
			   </ul>
		 	</li>
             <li><a href="index.php?id=<?=base64_encode('operator')?>">Operator</a></li>
		</ul>
	</div>
    
    
    