﻿<?php

define('HTTP_SERVER_TRUE', 'http://prodw.tnth.local.denso-ten.com/');//must be localhost http://localhost/
define('HTTP_SERVER', 'http://prodw.tnth.local.denso-ten.com/');
// define('HTTP_SERVER_TRUE', 'http://10.164.213.51/');//must be localhost http://localhost/
// define('HTTP_SERVER', 'http://10.164.213.51/');

  define('SSO', 'sso/');
  define('DIR_PAGE', 'prod/manage_fgtag_split_online/');
  define('DIR_PARTH', '/www/prod/manage_fgtag_split_online/');
  

  define('DIR_IMAGES', 'images/');
  define('DIR_CSS', 'css/');
  define('DIR_INCLUDES', 'includes/');
  define('DIR_FUNCTIONS', 'functions/');
  define('DIR_JAVA', 'javascript/');
  define('DIR_VIEWS', 'views/');
  define('DIR_MENU', 'menu/');
  define('DIR_UPLOAD', 'uploads/');
  define('DIR_BTW', 'btw/');
  define('DIR_MPIC', 'picmodel/');
  define('DIR_LINE', 'lines/');
  define('DIR_SEVER', '\\\\10.164.213.32\\eticket_template\\print\\FGSPLIT\\');
  
 

  
  define('DB_DATABASE1', 'prod_fg_tag');
 // define('DB_DATABASESSO', 'sign_on');
 // define('DB_DATABASE3', 'target_board');
  define('USE_PCONNECT', 'false');
  define('STORE_SESSIONS', 'mysql');   


//$con = mysql_connect("172.16.131.97", "fgtag", "fgtag") or die( mysql_error() );
$con = mysqli_connect("10.164.213.27", "admin", "password") or die(mysqli_connect_error());
// $con = mysqli_connect("localhost", "root", "") or die(mysqli_connect_error());
mysqli_set_charset($con, "utf8");
//mysql_select_db(DB_DATABASESSO, $con)or die( mysql_error() );
//mysql_select_db(DB_DATABASE3, $con)or die( mysql_error() );


?>



