#configure
configure.php for line and bsi page  ** This file is diffarent with Local host with server


configure_srv.php for line connect to server

configure_host.php for server, BSI, FG

#template
template_top for Server manager
template_top_fg for FG printing supplier Tag

template_top_line for select Line => not login yet 
template_topl for Final Line => after login 
template_top_bsi for BSI Line => after login 


#LINK 
BSI => http://linuxapps.fttl.ten.fujitsu.com/prod/manage_fgtag/views/lines/index_line.php?gbsi=YnNpMjE4MjM=
Final => http://localhost/prod/manage_fgtag/views/lines/index_line.php
FG => http://10.164.214.49/prod/manage_fgtag/index_fg.php
Manage =>http://linuxapps.fttl.ten.fujitsu.com/prod/manage_fgtag/

