       <!---------------------------- END CONTENT ------------------------------->
   
 <br />
 <br />

	
</div>
<!-- CONTENT -->
<!-- FOOTER -->
	<div id="footer">
        <div class="bottom">
          Copyright &copy; 2013 
         <span class="copyright">Management by Production Planning & Material Control Dept. | Powered by I/T @ 2016</span></div>
        </div>
	</div>
 <!-- FOOTER -->

</body>
</html>