<?php

require_once '../includes/configure_host.php';
//include('../includes/configure.php');
				
if(!empty($_GET["gdata"]) && $_GET["gdata"]<>"undefined"){
	
	 $gtagsp=$_GET["gdata"];


//a.tag_no,a.tag_qty,a.item_status,b.id_fg_tag_conversion, 
		  $sqltk="SELECT a.model_kanban,a.matching_ticket_no,b.last_station,a.bsi_line_id
						FROM  ".DB_DATABASE1.".fgt_srv_tag a	
						LEFT JOIN ".DB_DATABASE1.".fgt_model b ON a.id_model =b.id_model
						WHERE fg_tag_barcode = '$gtagsp'  ";
		  $rstk = mysqli_query($con, $sqltk);

if(mysqli_num_rows($rstk)!= 0){
		$rstksp = mysqli_fetch_array($rstk);
		$tkmodel = $rstksp['model_kanban'];
		if($tkmodel != ""){
			$bsi_line = $rstksp['bsi_line_id'] ;
			 $lastst = $rstksp['last_station'] ;
			$ticketmt = $rstksp['matching_ticket_no'] ;
			if (($bsi_line == '') && ($lastst == '1') ){
				//lastst = >	0=Final, 1=BSI	
				//taglocat =>1=Line Printed ,2= BSI Passed 
				$resonse = $ticketmt."--&&--"."NG";
				echo $resonse ;
			}else{
				
				$resonse = $ticketmt."--&&--"."OK";
				echo $resonse ;
				
			}
			
			 
			}else{
				echo "No";
				// echo $mxsrl ;
			}//if($gserial-$rscht['mxtag']==1){

		
}else{
	 echo "No";
	 // echo $sqlg;
	}
 }//  if(!empty($_GET["code"]) && $_GET["code"]<>"undefined"){


?>