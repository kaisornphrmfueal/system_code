<?php

?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">
window.onload = function() {
	//alert("s");
	document.getElementById("button2").disabled = true;

	  document.getElementById("tsearch").focus();
	  document.getElementById("tsearch").select();
		document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน  FG TAG  for Combine </span>';

	 
}

	//START ckNext
 function ckNext(e) {
	  // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
        let tagbc=document.getElementById("tsearch").value.toString();
	 let lenbc = tagbc.length;
//alert(lenbc);
	if(lenbc == 17){
		 	 //----- START CHECK  FG TAG 
		
		
			 let tagsp=document.getElementById("tsearch").value;
		//  alert(tagsp);
		 
			     $.ajax({
				url: "chkltagcomb.php?gdata="+ tagsp ,
				method: 'GET', 
				success: function (datap) {
					//	alert(datap)
			var rqrTxtlb= datap.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '')
				
				//alert(rqrTxtlb);
	
				if(rqrTxtlb == "No"){
					//Duplicate
						document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >ไม่พบข้อมูล  FG TAG No. ในระบบ หรือมีการแสกนไปแล้ว กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("button2").disabled = true;
				
					
					}else{
						
				//alert("+"+rqrTxtlb);
						
						document.getElementById("tqty").length = 0;
						let text = rqrTxtlb;
						const myArray = text.split("--&&--");	
						var gticket = myArray[0];
						var gqty = Number(myArray[1]);	
						var gmol = Number(myArray[2]);	
						var gstdqty = Number(myArray[3]);
						var statusbsi = myArray[4];	
						if(statusbsi=="NG"){
							document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >NG ยังไม่มีการสแกนข้อมูล FG tag นี้จาก BSI,<br/> กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("tsearch");
						   input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("button2").disabled = true;
						}else{//if(statusbsi=="NG"){
						 let i = 2;
						while (i <= gstdqty) {
						  var x = document.createElement("OPTION");
						  x.setAttribute("i", "i");
						  var t = document.createTextNode(i);
						  x.appendChild(t);
						  document.getElementById("tqty").appendChild(x);

						  i++;

						}
						document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณา เลือกจำนวนที่ต้องการ Combine';
						 document.getElementById("button2").disabled = false;
						
						//let combqty=Number(document.getElementById("tqty").value);
						
					//	alert(combqty+ "+"+gqty);
							document.getElementById('sticket').value  = gticket;
						document.getElementById('tagqtys').value  = gqty;
						document.getElementById('tagmodl').value  = gmol;
													 
													 
						}//if(statusbsi=="NG"){
				
					}//if(data!= null){
					
					
				}
			}); // $.ajax({
		
		//----- END CCHECK  FG TAG
		
		 
	 }else{
		 document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน FG TAG for Combine </span>';
		 	document.getElementById("button2").disabled = true
		 const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
	 }
		 return false;

    }    return true;
 
 }
	//END ckNext
	 function showAlert(selectElement) {
		/*let selectedValue = selectElement.value;
		   alert(selectedValue);
	*/
	  }
		 function submitForm() {
			   let chkqty=Number(document.getElementById("tagqtys").value);
			 //alert(chkqty);
			   let combqty=Number(document.getElementById("tqty").value);
		 		if(combqty<=chkqty){
						//	alert("<<<<");
							document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >Combine Qty. น้อยกว่า หรือ เท่ากับ F/G Treansfer Tag Qty.<br/>  กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("button2").disabled = true;
							 return false;
						}else{
						//	alert(">>>");
							document.getElementById("txtStatus").innerHTML  = '<span class="txt-green-b-s" ><img src="../../images/yes.gif"  /><br/>ข้อมูลถูกต้อง ระบบกำลังบันทึกข้อมูล...</span>';
							
						document.getElementById("button2").disabled = false;
						 document.getElementById("form1").submit();
								//	 return false;
							
						}//if(combqty<gqty){

			 
			 
			 
			 
   
   
  }
	
	
	
</script>

<div align="center">
 <form id="form1" name="form1" method="post" action="index_fg.php?id=<?=base64_encode('fg_tag_combine_tag_start')?>"  autocomplete="off">
   <table width="530" border="1" align="center" class="table01" >
	  <tr>
     <td height="37" colspan="2" align="center" bgcolor= #F0EF4C>Combine F/G Transfer Tag</td>
     </tr>
 
     
      <tr>
     <td width="192" height="37"><div class="tmagin_right">Scan F/G Transfer Tag (Original)</div> </td>
     <td width="274"><div class="tmagin_right">
        <input type="text" name="tsearch" id="tsearch"   value="" onfocus="this.select()"  class="bigtxtbox" style="width:190px;"  onkeypress="return ckNext(event);" /> </div>

	   
	   </td>
   </tr>
	    <tr>
        <td height="37"><div class="tmagin_right">Combine Qty. </div></td>
        <td><div class="tmagin_right">
			<!--<input type="text" name="tqty" id="tqty"  
					 value="<?php echo $_POST['tqty']; ?>" class="bigtxtbox" style="width:50px;" readonly  />
			-->
			<select name="tqty" id="tqty" ><!--onchange="showAlert(this)"-->
     
         </select>
			</div> </td>
      </tr>
   <tr>
     <td height="37" colspan="2" align="center"><div id="txtStatus"></div></td>
     </tr>
   <tr>
     <td height="37" colspan="2" align="center">
	    
		 
		
		 
		  <input type="hidden" name="sticket" id="sticket"  value=""/>
		  <input type="hidden" name="tagqtys" id="tagqtys"  value=""/>
		 <input type="hidden" name="tagmodl" id="tagmodl"  value=""/>
		 <input type="hidden" name="statusnew" id="statusnew"  value="new"/>
<input type="button" name="button2" id="button2" value="Submit" onclick="submitForm()" /> 
		  <input type="hidden" name="scan2" id="scan2"  value="Submit" /> 
	   </td>
   </tr>
   </table>
</form>   
	
	<!--	 <button onclick="window.location.href='index_fg.php?id=<?php echo base64_encode('fg_tag_combine');?>'">Back to Select Qty.</button>-->
</div>
<?php
?>