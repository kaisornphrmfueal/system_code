<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<div class="rightPane" align="center">
<?php
// ใช้ $con เป็น mysqli connection

$query = "
  SELECT 
    id_update, action_name, path, fname, version_up, emp_insert,
    DATE_FORMAT(date_insert, '%d-%b-%Y %H:%i') AS date_modify, detail
  FROM (
    SELECT id_update, action_name, path, fname, version_up, emp_insert, date_insert, detail
    FROM " . DB_DATABASE1 . ".fgt_srv_update
    WHERE type_data = 'Bartender'
    ORDER BY id_update DESC
  ) a
  GROUP BY fname
";
$result = mysqli_query($con, $query);

if ($result && mysqli_num_rows($result) > 0): ?>
  <table width="750px" border="1" bordercolor="#CC9966" class="table01" align="center">
    <tr>
      <th colspan="8"><div align="center">Current Bartender file</div></th>
    </tr>
    <tr>
      <th width="5%">No.</th>
      <th width="17%">File</th>
      <th width="9%">Last Version</th>
      <th width="21%">Last Detail</th>
      <th width="20%">Date modified</th>
      <th width="10%">User modified</th>
      <th width="10%">Download</th>
      <th width="8%">Update file</th>
    </tr>
    <?php
    $i = 1;
    while ($row = mysqli_fetch_assoc($result)): ?>
      <tr <?=icolor($i)?> height="28" onMouseOver="className='over'" onMouseOut="className=''" align="center">
        <td><?= $i ?></td>
        <td><?= htmlspecialchars($row['fname']) ?></td>
        <td><?= htmlspecialchars($row['version_up']) ?></td>
        <td><?= htmlspecialchars($row['detail']) ?></td>
        <td><?= htmlspecialchars($row['date_modify']) ?></td>
        <td><?= htmlspecialchars($row['emp_insert']) ?></td>
        <td>
          <a href="uploads/btw/<?= urlencode($row['fname']) ?>.btw" target="_blank">
            <img src="../images/001_51.gif" alt="Download" />
          </a>
        </td>
        <td>
          <a href="#" onclick="openWins('windows.php?win=btw&idm=<?= urlencode($row['fname']) ?>', '_blank', 570, 250, 1, 1, 0, 0, 0); return false;">
            <img src="../images/001_45.gif" alt="Update" />
          </a>
        </td>
      </tr>
    <?php
      $i++;
    endwhile;
    ?>
  </table>
<?php else: ?>
  <br/><br/><br/>
  <center>
    <div class='table_comment'>No data available</div>
  </center>
<?php endif; ?>
</div>
