<?php

if(!empty($_POST['button2']) && $_POST['button2']=="Submit" && !empty($_POST['hidsplit']) ){ 
 $psplitid= $_POST['hidsplit'];
$pidconv= $_POST['hidconver'];
$psplitqty= $_POST['hidsplitqty'];
$pgmslabel= $_POST['gms_label'];
$psccanmodel =$_POST['model'];
	$gmodel = substr($psccanmodel,0,15);
	$gserial=substr($psccanmodel,16,8);
	//
	 $sqlg_split="SELECT  c.id_fg_tag_conversion,count(c.id_fg_tag_conversion) AS countsplit_qty,
				a.id_model,a.fg_tag_barcode,a.ticket_no,a.tag_no,a.tag_qty
				 FROM ".DB_DATABASE1.".fgt_split_fg_tag  a 
			  LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion b ON a.id_fg_split =b.id_fg_split
			  LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial c ON b.id_fg_tag_conversion=c.id_fg_tag_conversion
				  WHERE c.id_fg_tag_conversion ='$pidconv' AND gms_label_ref IS  NULL ";
		  $resultg_split = mysqli_query($con, $sqlg_split);
		$rstg_split = mysqli_fetch_array($resultg_split);
		$countsplit=$rstg_split['countsplit_qty'];
		$idmodel=$rstg_split['id_model'];
		$tagsplit=$rstg_split['tag_no'];
		$ticket_no=	$rstg_split['ticket_no'];
		if($countsplit==$psplitqty){ ////Create  NEW Tag
			 $mxtag=selectMxTag($ss_fgidline);
			//echo "<br/>--".$ss_fgidline;
				$linesp=sprintf("%02d",$ss_fgidline);
				$mxtagsp=sprintf("%07d",$mxtag);
				$tagnon=$linesp.$mxtagsp;
				if( date("H:i:s") >= "07:50:00" AND date("H:i:s") <= "20:19:59"){
							$chshift="Day";
							$datework=date('Y-m-d');
						}else{
							$chshift="Night";
							if( date("H:i:s") > "20:19:59" AND date("H:i:s") <= "23:59:59"){
								$datework=date('Y-m-d');
							}else{
								$datework=date( "Y-m-d",  strtotime("-1 day") );
							}
						}
				$tagb=date("Ymd").$tagnon;
				
						 $sqltg="INSERT INTO prod_fg_tag.fgt_srv_tag (line_id, 					
									tag_no,id_model,model_kanban,shift,fg_tag_barcode,
									status_print,matching_ticket_no,ticket_qty,kanban_status,
									date_insert,date_work,tag_location_creating,work_id)
									 SELECT '$ss_fgidline' AS line_id,  '$tagnon' AS tag_no, 
									'$idmodel' AS id_model, '$gmodel' AS model_kanban, 
									'$chshift' AS shift, '$tagb' AS fg_tag_barcode, 
									'Not yet' AS status_print , '$ticket_no' AS matching_ticket_no, 
									'$psplitqty' AS ticket_qty, 'A' AS kanban_status,  
									'".date('Y-m-d H:i:s')."' AS date_insert,  '$datework' AS date_work ,
									'1' AS tag_location_creating, work_id
									FROM prod_fg_tag.fgt_srv_tag WHERE  tag_no = '$tagsplit'"; 
							$qrtg=mysqli_query($con, $sqltg);
							log_hist($user_login,"New Tag",$mxtag,"fgt_srv_tag",$sqltg);

			
		}//Create  NEW Tag
	
		$sqlg="SELECT MIN(c.id_conversion_serial) AS idconserial,c.serial_label,d.tag_model_no, 
		  a.tag_no,a.tag_qty,a.item_status,b.id_fg_tag_conversion,d.model_destination,
		  b.stag_qty AS splittagqty,b.sn_start,b.sn_end,
		  count(b.id_fg_tag_conversion) AS countnotnull
          FROM ".DB_DATABASE1.".fgt_split_fg_tag  a 
          LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion b ON a.id_fg_split =b.id_fg_split
          LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial c ON b.id_fg_tag_conversion=c.id_fg_tag_conversion
		  LEFT JOIN ".DB_DATABASE1.".fgt_model d ON a.id_model =d.id_model
          WHERE b.id_fg_tag_conversion ='$pidconv' AND gms_label_ref IS  NULL  ";
		  $resultg = mysqli_query($con, $sqlg);
	
		if(mysqli_num_rows($resultg)<>0){
			
			//	$pline=$_POST['hslid'];
			$rstg = mysqli_fetch_array($resultg);
				$serial = $rstg['serial_label'];
				$tagmodel = $rstg['tag_model_no'];
				$splittagqty = $rstg['splittagqty'];
				$idconser = $rstg['idconserial'];
				$model_dest = $rstg['model_destination'];
				if($serial == $gserial ){
					if($splittagqty == 1){ //split qty ==1
							//print Tag
							$sqlup_tag="UPDATE ".DB_DATABASE1.".fgt_srv_tag SET 
										sn_start='$gserial' , sn_end='$gserial' ,
										status_print='Printed', tag_qty='$psplitqty',
										date_print='".date('Y-m-d H:i:s')."',
										tag_location='6'
										WHERE tag_no='$tagnon' " ;
							$qrup_tag=mysqli_query($con, $sqlup_tag);
							//0=Tag Reserved ,1=Line Printed ,2= BSI Passed , 3 = Packing Passed, 4 =FG Passed, 5 = PC Cancel, 6= FG Splite , 7 FG Combine, 8= Line cancel
							$sqlsr="INSERT INTO ".DB_DATABASE1.".fgt_srv_serial SET  tag_no='$tagnon', 
									model_scan_label='$tagmodel', serial_scan_label='$gserial', 
									date_scan='".date('Y-m-d H:i:s')."'";
							$qrsr=mysqli_query($con, $sqlsr);
							log_hist($user_login,"Insert",$gserial,"fgt_srv_serial",$sqlsr);
						
						
							$sqlutk="UPDATE ".DB_DATABASE1.".fgt_split_fg_tag_conversion a 
									LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial b ON a.id_fg_tag_conversion = b.id_fg_tag_conversion
									SET a.date_conversion='".date('Y-m-d H:i:s')."',
									a.emp_conversion='$user_login',a.tag_no_new='$tagnon',item_status=2
									b.serial_label_confirm='$psccanmodel',b.gms_label_ref='$pgmslabel',
									b.date_scan_confirm='".date('Y-m-d H:i:s')."',b.emp_scan_confirm='$user_login'
									WHERE b.id_conversion_serial ='$idconser' ";
							$qrtk=mysqli_query($con, $sqlutk); 
						
							
						
						// START INSERT FOR MATCHING
						//echo "--".$model_dest;
						
						if($model_dest=="E"){
						$ip = $_SERVER['REMOTE_ADDR']; 
						$tkno9=sprintf("%09d",$ticket_no);
						$sqlmc = "INSERT INTO ewi_packing.record_mathing_kanban SET 
							record_code='".date("YmdHis")."', ticket_no='$ticket_no',	model_no_scan='$gmodel', 
							fg_tag_no='$tagb', model_no_auto='$gmodel', judge='OK', 
							operator_id='$user_log_name', record_time='".date('Y-m-d H:i:s')."', 
							error_code='-', line_leader_id='-',ip='$ip',kanban_group='".date("ymdH")."',
							working_location='2',status_scan = '7'"; 
							mysqli_query($con, $sqlmc); 
							
							
						$sqlmc = "INSERT INTO ewi_packing.record_mathing_kanban_log SET 
							record_code='".date("YmdHis")."', ticket_no='$ticket_no', model_no_scan='$gmodel', fg_tag_no='$tagb', 
							model_no_auto='$gmodel', judge='ok', operator_id='$user_log_name', record_time='".date('Y-m-d H:i:s')."',
							error_code='-', line_leader_id='-',ip='$ip'";
							mysqli_query($con, $sqlmc);
							
							log_record_packing($user_log_name,'FG insert to record_mathing_kanban',$sqlmc);
							}//if($model_dest==""){
						// END  INSERT FOR MATCHING 
						
						//sprintTag
						// printTagSplit($tagnon);
						//eprinTag
							log_hist($user_login,"Printed Tag",$tagnon,"fgt_srv_tag","");
					//---END  Checking Qty if 1 print -----------		
					sleep(3);
					//gotopage("index_fg.php?id=".base64_encode('fgprint_split_tag_printing')."&lid=".$user_login);

						
						//Print Tag
							
						}else{//split qty ==1=> else <> 1 
							if($rstg['countnotnull']=="1"){ //Last all only 1 Tag
								//print Tag


								
								
								//ย้านขึ้นไปแทน if($splittagqty == 1){  เพราะไม่มีทางจะเปน 1


							}else{
								//save and Next
								


							}//if($rstg['countnotnull']=="1"){ //Last all only 1 Tag


						}//if($splittagqty == 1)
					
	
				}elseif ($tagmodel != $gmodel ) {
						 alert("Model No. ไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่อีกครั้ง");
						gotopage("index_fg.php?id=".base64_encode('fgprint_split_tag_printing')."&idconv=".$ptagno);
				}else{
						 alert("Serial No. ไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่อีกครั้ง");
						gotopage("index_fg.php?id=".base64_encode('fgprint_split_tag_printing')."&idconv=".$ptagno);
						// echo $mxsrl ;
					}//if($gserial-$rscht['mxtag']==1){


		}else{
			 alert("Serial No. ไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่อีกครั้ง");
			gotopage("index_fg.php?id=".base64_encode('fgprint_split_tag_printing')."&idconv=".$ptagno);
			 // echo $sqlg;
			}

	
	
	
	
	
		
		
			
/*	alert("Serial No. ไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่อีกครั้ง");
			gotopage("index.php?id=".base64_encode('printtag')."&idtg=".base64_encode($ptagno));
	*/
	
}//if(!empty($_POST['button2']) && $_POST['button2']=="Submit" && !empty($_POST['hidsplit']) ){ 
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">
window.onload = function() {
  document.getElementById("gms_label").focus();
  document.getElementById("gms_label").select();
	document.getElementById("model").disabled = true;
}


 function ckNext(e) {
	  // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
        let val=document.getElementById("gms_label").value.toString();
	 let len = val.length;
//alert(len);
	 if(len == 9){
		 document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน Serial Label หลังเครื่อง</span>';
		document.getElementById("model").disabled = false;
		document.getElementById("model").focus();
	 }else{
		 document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน GMS Label Ref.</span>';
	 }
		 return false;
   
    }    return true;

	 
 }


	/********************************-*/
function ckKeyPresse1(e) 
{

    // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
        document.getElementById('btnscan').click();
		alert( document.getElementById('btnscan').value)
		 return false;
   
    }    return true;

    
}//  if (e.keyCode == 13)
	
	

	
	
	
</script>

<?php
?>
 <div class="rightPane" align="center">
  <?php
  	//$lineid= $_GET['lid'];

	
  	if (!empty($_GET['idconv'])){
		$gidconv =$_GET['idconv'];

			$sql_st="SELECT a.tag_no,a.tag_qty,a.item_status,a.id_fg_split,c.stag_qty,a.ticket_no,
		  b.id_model,b.model_code,   b.model_name,b.tag_model_no,b.customer,b.std_qty,
          b.customer_part_no,b.customer_part_name,b.model_picture,b.status_tag_printing,
		  CONCAT(c.sn_start,'-',c.sn_end) AS allserial
          FROM ".DB_DATABASE1.".fgt_split_fg_tag  a 
		  LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion c ON a.id_fg_split =c.id_fg_split
          LEFT JOIN ".DB_DATABASE1.".fgt_model b ON a.id_model =b.id_model 
		   WHERE  c.id_fg_tag_conversion ='".$gidconv."'  ";
						
	} 
	  //echo $sql_st;
		$qr_st=mysqli_query($con, $sql_st);
		if($num_st=mysqli_num_rows($qr_st)<>0){
			$rsst=mysqli_fetch_array($qr_st);
			$modelid=$rsst['id_model'];
			$id_split=$rsst['id_fg_split'];
			$stmodel=$rsst['tag_model_no'];
			$splitqty=$rsst['stag_qty'];
			$sttag=$rsst['tag_no'];
			$sttag_qty=$rsst['tag_qty'];
			$stticket=$rsst['ticket_no'];
			$stfg_tag_barcode=$rsst['fg_tag_barcode'];
			$all_serial=$rsst['allserial'];
			
  ?>
  

<form name="scan"  id="scan" method="post" action="index_fg.php?id=<?=base64_encode('fgprint_split_tag_printing')?>"   onsubmit="return false;"  autocomplete="off" >
            
    <table width="952" height="359" border="1" align="center" class="table01">
              <tr>
                <td height="40" colspan="2" align="center"><span class="text_black">
				<?php
				 
				 echo $ss_fgidline."FG FG Tag Spliting";
				 ?>
                </span>  </td>
              </tr>
              <tr>
                <td height="40"><div class="tmagin_left"><span class="text_black">Model :<br />
                </span></div></td>
                <td height="40"><div class="tmagin_right"> <span class="text_black">
                  <?php  echo "<span id=txtModel>$stmodel</span> ";?>
                  </span> <span class="txt-blue-big"><?php echo "[".$rsst['model_name']."]"; ?></span>
					<span id="convid"><?php echo $gidconv;?></span>
              		<!--   style="display:none;" -->
					
                  <!--0= start, 1= spliting,  2= finished, 3=cancel-->
                </div></td>
              </tr>
              <tr>
                <td width="375" height="40"><div class="tmagin_left"><span class="text_black">Tag Original No. :<br />
                </span></div></td>
                <td width="561" height="40">  <div class="tmagin_right">
                <span class="text_black"><?php  echo "<span id=txt-black-big>$sttag</span> ";?> </span>
                <!--0= start, 1= spliting,  2= finished, 3=cancel--></div>
                </td>
              </tr>
             
				   <tr>
                <td height="40"><div class="tmagin_left"><span class="text_black">Ticket Original No. : <br />
                </span></div></td>
                <td height="40">  <div class="tmagin_right"> <span class="text_black">
				<?php  echo $stticket; ?>  || Ticket Qty. : </span>
               
               <span class="text_black"> 	<?php  echo $sttag_qty; ?> </span> </div>
                </td>
              </tr>
              <tr>
                <td height="40"><div class="tmagin_left"><span class="text_black">Serial Split Start - End </span><br />
                </div></td>
                <td height="40">  <div class="tmagin_right"> 
                <span class="txt-black-big"><?php  echo "<span id=txtTag>$all_serial</span> ";?>
                </span> || <span class="text_black">Tag Split  Qty. : </span><span class="txt-blue-big">
                <?php  echo $splitqty; ?>
                </span></div>
                </td>
              </tr>
           
		<tr>
                <td height="40"><div class="tmagin_left"><span class="text_black">Scan GMS Label ref. : </span><br />
                </div></td>
                <td height="40">  <div class="tmagin_right">
                  <input type="text" name="gms_label" id="gms_label"  class="bigtxtbox" style="width:290px;"  onkeypress="return ckNext(event);" onClick="this.select();" />
                </div>
                </td>
              </tr>
		
                <tr>
                <td height="40"><div class="tmagin_left"> <span class="text_black">Scan Label barcode  : <br />
                </span></div></td> 
                <td >
                <div class="tmagin_right">
               
                  <input type="text" name="model" id="model"  class="bigtxtbox" style="width:290px;"  onkeypress="return ckKeyPresse1(event);" />
					</div>
             
              </tr>	
				
					<tr>
			     
                <td colspan="2" height="75px"  align="center">
             <div id="txtStatus"></div>

                </td>
              </tr>
				<tr>
                <td height="40" colspan="2" align="center">
                <input type="button" name="button3" id="button3" value="Cancel" class="button3"  
            onClick="window.location.href='index.php?id=<?=base64_encode('fgprint_split_tag_printing')?>&stag=<?=$id_split?>&idconv=<?=$gidconv?>';"/>
					
					  <input type="button" name="btnscan" id="btnscan" value="Submit" class="myButton" onclick="validateConverTag(this.value)" />
                  <input type="hidden" name="button2" id="button2"  value="Submit" /> 
                  <input type="hidden" name="hidsplit" id="hidsplit" value="<?=$id_split?>" />
					<input type="hidden" name="hidconver" id="hidconver" value="<?=$gidconv?>" />
				<input type="hidden" name="hidsplitqty" id="hidsplitqty" value="<?=$splitqty?>" />	
					

                </td>
              </tr>	
					
    </table>
  
</form>

<?php

		  $sql ="SELECT c.stag_qty,a.ticket_no,
		  b.id_model,b.model_code,   b.model_name,b.tag_model_no,b.customer,b.std_qty,
          b.customer_part_no,b.customer_part_name,b.model_picture,b.status_tag_printing,
		  CONCAT(c.sn_start,'-',c.sn_end) AS allserial
          FROM ".DB_DATABASE1.".fgt_split_fg_tag_conversion c ON a.id_fg_split =c.id_fg_split
          LEFT JOIN ".DB_DATABASE1.".fgt_model b ON a.id_model =b.id_model 
		   WHERE  c.id_fg_tag_conversion ='".$gidconv."'
		  
		  SELECT id_serial,tag_no,model_scan_label,serial_scan_label,
					 DATE_FORMAT(date_scan, '%d-%b-%Y %H:%i') AS dateprint 
					 FROM ".DB_DATABASE1.".fgt_srv_serial
					 WHERE tag_no='$sttag'
					 ORDER BY id_serial DESC ";
		$qr=mysqli_query($con, $sql);
		$nums=mysqli_num_rows($qr);
		if($nums<>0){				
			$i=1;
?>
<!-- <form id="form1" name="form1" method="post" action="index.php?id=<?=base64_encode('printtag')?>" autocomplete="off" >!-->

<table width="863" border="1" class="table01" align="center" >
     <tr height="31">
       <th colspan="4" align="left" >
         <span class="text_black_bold">Model No.(หมายเลขโมเดล) : </span><?php echo $stmodel;?> <br />
 
        <span class="text_black_bold">  STD Qty. (จำนวน): </span><?php echo $st_stdqty;?></th>
       <th >
		<!---   <input type="button" name="button5" id="button5" value="Print"  class="button1" onclick="javascript:openWins('windows.php?win=print&idm=<?=$sttag?>', '_blank',650, 530, 1, 1, 0, 0, 0);return false;"/>!-->
	   </th>
     </tr>
     <tr height="31">
       <th width="77" ><span class="text_black_bold">No. <br/>(ลำดับ)</span></th>
       <th width="129" ><span class="text_black_bold">Tag No.<br />
         (หมายเลขแท็ก) </span><br />
      </th> 
       <th width="230" ><span class="text_black_bold">Model on label<br />
       (หมายเลขโมลเดลของลาเบล)</span></th>
       <th width="235"><span class="text_black_bold">Serial on label<br />
(หมายเลขซีเรียลของลาเบล)       </span></th>
       <th width="158"><span class="text_black_bold">Date scan<br />
         (วันที่แสกน)
       </span></th>
    </tr>
   		<?php
        	while($rs=mysqli_fetch_array($qr)){
		?>
     <tr <?php //echo icolor($v); $v = $v + 1; ?> onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" height="31px" align="center">
       <td><span class="text_black_normal02"><?=$i?></span></td>
       <td><span class="text_black_normal02"><?=$rs['tag_no'];?></span></td>
       <td><span class="text_black_normal02"><?=$rs['model_scan_label'];?></span></td>
       <td><span class="text_green_normal02"><?=$rs['serial_scan_label'];?></span></td>
       <td><span class="text_black_normal02"><?=$rs['dateprint'];?></span></td>
    </tr>
     	<?php
			$i++;
			}//while($rs=mysql_fetch_array()){
		?>
     <tr align="center">
       <td colspan="5"><input type="hidden" name="htag" id="htag" value="<?=$sttag?>" /> 
            <input type="hidden" name="hqtys" id="hqtys" value="<?=$nums?>" />
		   
		   
			<!-- <input type="hidden" name="hidtag" id="hidtag" value="<?=$id_tag?>" />!-->
   
     </td>
     </tr>

   </table>
<!--</form>!-->
		  <?php
                }else{
					echo "<center><div class='table_comment' >No have data...</div></center>";
					}//if($nums=mysql_num_rows($qr)){		
	
}else{
	echo "<center><div class='table_comment' >
	<a href='index.php?id=".base64_encode('line')."'>ไม่มีข้อมูลการตั้งต้นของโมเดล คลิกที่นี่ เพื่อแสกน Kanban อีกครั้ง</a></div></center>";
	}//if($num_st=mysql_num_rows($qr_st)<>0){
          ?>
</div>
