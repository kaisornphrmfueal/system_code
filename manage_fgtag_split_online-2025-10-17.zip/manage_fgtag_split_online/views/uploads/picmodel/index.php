<?
		echo "<META HTTP-EQUIV=refresh CONTENT=\"1; URL=../../lines/\">";
?>