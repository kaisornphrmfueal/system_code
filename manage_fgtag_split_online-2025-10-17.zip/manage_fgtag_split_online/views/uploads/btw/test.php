<?php

echo $serverPath = '\\\\10.164.213.32\\eticket_template\\print\\FGSPLIT\\45\\fgtag.txt';
// $serverPath = 'cmdb/fgtag.txt';
		$sourceFile = 'fgtag.txt';
		$destFile = $serverPath . "fgtag.txt";
		$cmdSource = $serverPath . "cmd.txt";
		$cmdDest = $serverPath . "cmds\\cmd.txt";

		echo $flgCopyDT = copy($sourceFile, $serverPath);
		// $flgCopy1 = copy($cmdSource, $cmdDest);