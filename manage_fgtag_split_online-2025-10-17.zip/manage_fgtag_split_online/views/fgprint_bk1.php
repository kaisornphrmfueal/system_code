
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

 <form id="form1" name="form1" method="post" action="">
   <table width="710" border="1" align="center" class="table01" >
     <tr>
       <td width="366" height="37"><div class="tmagin_right">Search : Tag No.</div> </td>
       <td width="328">
              <input type="text" name="tsearch" id="tsearch" style=" width:180px;"  value="<? echo @$_POST['tsearch']?>"/>
       <input type="submit" name="button" id="button" value="Search" /></td>
     </tr>
   </table>
</form>   
 
 <div class="rightPane">
<?
		   	if(!empty($_POST['tsearch'])){
				$txtsearsh= $_POST['tsearch'];
					$x="AND   ((tag_no LIKE '%$txtsearsh%')   )";
				}else{ $x=""; }
         	  	  
		 	$q="SELECT a.id_tag,b.id_model,b.model_code,a.tag_no,a.shift,b.model_name,b.tag_model_no,
				DATE_FORMAT(a.date_print, '%d-%b-%Y') AS dateprint ,	a.tag_qty,
				CONCAT(a.sn_start,'-',a.sn_end) AS allserial,a.sn_start,a.sn_end,a.line_id,a.fg_tag_barcode,
				b.customer_part_no,b.customer_part_name,b.model_picture,a.status_print,b.status_tag_printing,c.line_name
				FROM ".DB_DATABASE1.".fgt_srv_tag  a
				LEFT JOIN ".DB_DATABASE1.".fgt_model b ON a.id_model=b.id_model
				LEFT JOIN ".DB_DATABASE1.".view_line c ON a.line_id=c.line_id
				WHERE status_print in ( 'Printed','Reprinted') 
				$x ";
				
			$qr=mysql_query($q);
								$total=mysql_num_rows($qr);  
					$i=1;
					if($total<>0)			
				{	
								$e_page=15; // ????? ???????????????????????????
								
								if(!isset($_GET['s_page']) or !empty($txtsearsh)){     
									$_GET['s_page']=0;     
								}else{     
									$chk_page=$_GET['s_page'];       
									$_GET['s_page']=$_GET['s_page']*$e_page;     
								}     
								$q.=" LIMIT ".$_GET['s_page'].",$e_page";  
								$qr=mysql_query($q);  
								if(mysql_num_rows($qr)>=1){     
									@$plus_p=($chk_page*$e_page)+mysql_num_rows($qr);     
								}else{     
									@$plus_p=($chk_page*$e_page);         
								}     
								$total_p=ceil($total/$e_page);     
								@$before_p=($chk_page*$e_page)+1; 
								
							?>
	


<table width="98%" height="108" border="1" bordercolor="#CC9966"class="table01" align="center">
    <tr >
      <th height="27" colspan="10">
      <div align="center">Tag Reprinting</div>  </th>
      </tr>
      
    <tr>
      <th width="3%" height="27">No.</th>
      <th width="7%">Tag No</th>
      <th width="9%">Model Code</th>
      <th width="13%"><span class="tmagin_right">Model No. (Tag)</span></th>
      <th width="9%">Model Name</th>
      <th width="17%">Serial </th>
      <th width="8%">Tag Qty.</th>
      <th width="7%">Line</th>
      <th width="15%">Print Date</th>
      <th width="12%">Print Tag</th>
    </tr>
       <?php while(@extract($rs=mysql_fetch_array($qr))){ 
	   		$rtag=$rs['tag_no'];
	   		  ?>
      <tr  <?php $v =0; $v = $v + 1; echo  icolor($v); ?>height="28" onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" align="center">
      <td ><?=$i?></td>
      <td ><?=$rs['tag_no']?></td>
      <td><?=$rs['model_code']?></td>
      <td><?=$rs['tag_model_no']?></td>
      <td><?=$rs['model_name']?></td>
      <td><?=$rs['allserial']?></td>
      <td><?=$rs['tag_qty']?></td>
      <td><?=$rs['line_name']?></td>
      <td><?=$rs['dateprint']?></td>
      <td> <a href="#" onClick="javascript:openWins('windows.php?win=fgp&idm=<?=$rs['id_tag'];?>', '_blank', 650, 460, 1, 1, 0, 0, 0);return false;"  >

        <img src="../images/printingtag.png" /></a></td>
    </tr>
	 <? 
        $i++;
     
        }//	while($rsp=mysql_fetch_array($qrp)){
    ?>
  
  </table>
  
  <?php
								
		 if($total>0){ ?>  
<div class="browse_page" >
			  <?php       @page_navigator_user($before_p,$plus_p,$total,$total_p,$chk_page,base64_encode('fgprint'),$txtsearsh);  	  ?>
  </div>  
<?php }
				
			}else{
					echo "<br/><br/><br/><center><div class='table_comment' >No hava Data  ";
		

			}//if(rows($qr)<>0){
		 ?>
</div>
  
