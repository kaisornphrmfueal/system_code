

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['station'])) {
	$_SESSION['station'] = $_POST['station'];
	gotopage("index_fg.php?id=".base64_encode('fgprint')." ");
}

$get_line = get_line_fg();
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<style>
	.station-container {
		display: flex;
		justify-content: center;
		align-items: center;
		height: 60vh;
		background: #f8f9fa;
	}
	.station-form {
		background: #fff;
		padding: 32px 40px 24px 40px;
		border-radius: 12px;
		box-shadow: 0 2px 16px rgba(0,0,0,0.08);
		min-width: 320px;
	}
	.station-form h2 {
		margin-bottom: 24px;
		color: #333;
		font-weight: 600;
		font-size: 1.4rem;
		text-align: center;
	}
	.station-form .form-control {
		width: 100%;
		padding: 10px 12px;
		border-radius: 6px;
		border: 1px solid #ced4da;
		margin-bottom: 20px;
		font-size: 1rem;
	}
	.station-form button {
		width: 100%;
		padding: 10px;
		background: #007bff;
		color: #fff;
		border: none;
		border-radius: 6px;
		font-size: 1rem;
		font-weight: 500;
		cursor: pointer;
		transition: background 0.2s;
	}
	.station-form button:hover {
		background: #0056b3;
	}
</style>
 
<div class="station-container">
	<form id="form1" name="form1" method="post" action="" class="station-form">
		<h2>เลือกพื้นที่การทำงาน</h2>
		<select class="form-control" name="station" required>
			<option value="">-- กรุณาจุดทำงาน --</option>
			<?php foreach ($get_line as $line): ?>
				<option value="<?= $line['line_id'] ?>"><?= $line['line_name'] ?></option>
			<?php endforeach; ?>
		</select>
		<button type="submit">ยืนยัน (Submit)</button>
	</form>
</div>
