

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">

window.onload = function() {
	document.getElementById("button2").disabled = true;
	let valticket=document.getElementById("sticket").value.toString();
	//alert("1");
	if(valticket == ""){
		document.getElementById("tsearch").disabled = true; 
	  document.getElementById("sticket").focus();
	  document.getElementById("sticket").select();
		document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน  New Ticket No.( Special Ticket)  </span>';
	}
	 
}


//START ckNextTicket
 function ckNextTicket(e) {
	  // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
        let val=document.getElementById("sticket").value.toString();
	 let len = val.length;
//alert(len);
	 if(len == 9){
			 //----- START CHECK  Ticket special
			//  alert(document.getElementById("sticket").value);
			 let ticketck=document.getElementById("sticket").value;
			 
			     $.ajax({
				url: "chklticketsp.php?gdata="+ ticketck,
				method: 'GET', 
				success: function (datap) {
						//alert(datap)
			var rqrTxtlb= datap.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '')
		
				//alert(rqrTxtlb);
	
				if(rqrTxtlb == "No"){
					//Duplicate
						document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >ไม่พบข้อมูล  Ticket No.( Special Ticket) ในระบบ กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("sticket");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("button2").disabled = true;
				
					
					}else{
						
						document.getElementById('hdtkmodel').value  = rqrTxtlb;
						//alert(document.getElementById('hdtkmodel').value);
						 document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน Scan FG Tag Original </span>';
						
						document.getElementById("tsearch").disabled = false;
						  document.getElementById("sticket").readOnly = true;
						const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
						
									

					}//if(data!= null){
					
					
				}
			}); // $.ajax({
		
		//----- END CCHECK  Ticket special
			 
			 
			 
			 
		
			 
			 
			 
	 }else{
		 	 document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน  New Ticket No.( Special Ticket) </span>';
		 const input = document.getElementById("sticket");
						  input.focus();
						  input.select(); // Update for handheld
	 }
		 return false;
 
    }    return true; // if (e.keyCode == 13)
 
 }
	//END ckNextTicket
	


//START ckNext
 function ckNext(e) {
	  // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
        let tagbc=document.getElementById("tsearch").value.toString();
	 let lenbc = tagbc.length;
//alert(lenbc);
	 if(lenbc == 17){
		 	 //----- START CHECK  FG TAG 
			
			 let tkmodel=document.getElementById("hdtkmodel").value;
			 let tagsp=document.getElementById("tsearch").value;
		//  alert(tkmodel);
		 
			     $.ajax({
				url: "chkltagsp.php?gdata="+ tagsp +"&gtkmodel="+ tkmodel,
				method: 'GET', 
				success: function (datap) {
					//	alert(datap)
			var rqrTxtlb= datap.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '')
		
				//alert(rqrTxtlb);
	
				if(rqrTxtlb == "No"){
					//Duplicate
						document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >ไม่พบข้อมูล  FG TAG No. หรือ Model No. ไม่ตรงกับ Ticket ในระบบ กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("button2").disabled = true;
					}else{
						
					//	alert("dd");
						
						
						document.getElementById("txtStatus").innerHTML  = '<span class="txt-green-b-s" ><img src="../../images/yes.gif"  /><br/>ข้อมูลถูกต้อง ระบบกำลังบันทึกข้อมูล... </span>';
						
						document.getElementById("button2").disabled = false;
						//document.getElementById("button2").submit();
						 document.getElementById("form1").submit();
						
									

					}//if(data!= null){
					
					 
				}
			}); // $.ajax({
		
		//----- END CCHECK  FG TAG
		
		 
	 }else{
		 document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน FG TAG Original</span>';
		 
		 const input = document.getElementById("txtStatus");
						  input.focus();
						  input.select(); // Update for handheld
	 }
		 return false;
  
    }    return true;

 }
	//END ckNext

</script>

<div align="center">
 <form id="form1" name="form1" method="post" action="<?php echo "index_fg.php?id=".base64_encode('fgprint_split_all');?>" autocomplete="off">
   <table width="550" border="1" align="center" class="table01" >
	  <tr>
	    <th height="32" colspan="2" align="center" >Split F/G Transfer Tag</th>
      </tr>
   <tr>
     <td width="227" height="140"><div class="tmagin_right"><a href="index_fg.php?id=<?=base64_encode('fgprint_split_normal')?>">Split F/G Transfer Tag</a>
		 <br/> Document for scan
		 <br/> 
		 - F/G Transfer Tag (Original)<br/> - GMS Label Ref.
		 <br/> - Model Serial No.
		 </div></td>
     <td width="239"><div class="tmagin_right"><a href="index_fg.php?id=<?=base64_encode('fgprint_split_special')?>">Split F/G Transfer Tag
		 - Special Case</a>
		 <br/> Document for scan
		 <br/> 
		 - F/G Transfer Tag (Original
		 <br/> - New Ticket No. (Special Ticket)
		 <br/> - Model Serial No.
		 </div></td>
   </tr>
  
   </table>
</form>   
</div>
<?php
?>