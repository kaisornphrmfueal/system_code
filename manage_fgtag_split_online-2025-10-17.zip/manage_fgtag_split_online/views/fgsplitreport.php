<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<form id="form1" name="form1" method="post" action="">
    <table width="710" border="1" align="center" class="table01">
        <tr>
            <td width="395" height="37">
                <div class="tmagin_right">Search : Model No., Model Code, Model Name, F/G Tag No.</div>
            </td>
            <td width="299">
                <input type="text" name="tsearch" id="tsearch" style="width:180px;" value="<?= htmlspecialchars(@$_POST['tsearch']) ?>"/>
                <input type="submit" name="button" id="button" value="Search" />
            </td>
        </tr>
    </table>
</form>

<div class="rightPane">
<?php
// Assume $con is a valid mysqli connection

function getSearchText() {
        if (!empty($_POST['tsearch'])) {
                return $_POST['tsearch'];
        }
        if (!empty($_GET['serh'])) {
                return $_GET['serh'];
        }
        return '';
}

$txtsearch = getSearchText();
$searchCondition = '';
if ($txtsearch !== '') {
        $txtsearch_esc = mysqli_real_escape_string($con, $txtsearch);
        $searchCondition = "AND (a.tag_no_original LIKE '$txtsearch_esc%'
                OR b.model_code LIKE '$txtsearch_esc%'
                OR b.model_name LIKE '$txtsearch_esc%'
                OR b.tag_model_no LIKE '$txtsearch_esc%'
				 OR c.tag_no_new LIKE '$txtsearch_esc%'
				
        )";
}

  $query = "SELECT a.id_fg_split,a.process_status,a.tag_no_original,a.tag_qty,a.separate_qty,a.item_status, 
		 CASE WHEN a.item_status=0 THEN 'Start'
		WHEN a.item_status =1 THEN 'Split' 
		WHEN a.item_status=2 THEN 'Finished' 
		WHEN a.item_status=3 THEN 'Cancel' ELSE 'Error' END AS itemstatus,
		CASE WHEN a.process_status = 0 THEN 'Link to GMS Label Ref.' 
		WHEN a.process_status=1 THEN 'Special Split'  ELSE 'Error' END AS prstatus,
		b.model_name,b.tag_model_no,
		CONCAT( d.name_en ,'[', DATE_FORMAT(a.date_insert, '%d-%b-%Y %H:%i'),']') AS conv_date ,
		GROUP_CONCAT(DISTINCT(c.tag_no_new) SEPARATOR ', ') AS alltag
		FROM " . DB_DATABASE1 . ".fgt_split_fg_tag a 
		LEFT JOIN " . DB_DATABASE1 . ".fgt_model b ON a.id_model =b.id_model
		LEFT JOIN " . DB_DATABASE1 . ".fgt_split_fg_tag_conversion c ON a.id_fg_split =c.id_fg_split 
		LEFT JOIN ".DB_DATABASESSO.".so_view_fttl_and_sub d ON a.emp_id_insert =d.emp_id 
		WHERE a.item_status <> 3 
		 $searchCondition
		GROUP BY a.tag_no_original  ORDER BY a.item_status , c.date_conversion DESC";

$result = mysqli_query($con, $query);
$total = mysqli_num_rows($result);

if ($total > 0) {
        $e_page = 15;
        $chk_page = isset($_GET['s_page']) ? intval($_GET['s_page']) : 0;
        $start = $chk_page * $e_page;

        $pagedQuery = $query . " LIMIT $start, $e_page";
        $pagedResult = mysqli_query($con, $pagedQuery);

        $plus_p = ($chk_page * $e_page) + mysqli_num_rows($pagedResult);
        $total_p = ceil($total / $e_page);
        $before_p = ($chk_page * $e_page) + 1;
        $i = $before_p;
?>
<table width="98%" border="1" bordercolor="#CC9966" class="table01" align="center">
        <tr>
                <th height="27" colspan="11">
                        <div align="center">F/G Transfer Tag Split Report</div>
                </th>
        </tr>
        <tr>
                <th width="4%" height="27">No.</th>
                <th width="13%"><span class="tmagin_right">Model No. (Tag)</span></th>
                <th width="9%">Model Name</th>
                <th width="9%">F/G Tag (Original)</th>
                <th width="14%">New F/G Tag</th>
                <th width="6%">Tag Qty.</th>
                <th width="6%">Separate Qty.</th>
                <th width="7%">Status Split</th>
                <th width="8%">Process</th>
                <th width="16%">Split By</th>
                <th width="8%">View</th>
        </tr>
        <?php while ($rs = mysqli_fetch_assoc($pagedResult)): ?>
        <tr <?= icolor($i) ?> height="28" onMouseOver="className='over'" onMouseOut="className=''" align="center">
                <td><?= $i ?></td>
                <td><?= htmlspecialchars($rs['tag_model_no']) ?></td>
                <td><?= htmlspecialchars($rs['model_name']) ?></td>
                <td><?= htmlspecialchars($rs['tag_no_original']) ?></td>
                <td><?= htmlspecialchars($rs['alltag']) ?></td>
                <td><?= htmlspecialchars($rs['tag_qty']) ?></td>
                <td><?= htmlspecialchars($rs['separate_qty']) ?></td>
                <td><?= htmlspecialchars($rs['itemstatus']) ?></td>
                <td><?= htmlspecialchars($rs['prstatus']) ?></td>
                <td><?= htmlspecialchars($rs['conv_date']) ?></td>
                <td>
					 
                        <a href="index_fg.php?id=<?= base64_encode('fgprint_split_tag') ?>&stag=<?= $rs['id_fg_split'] ?>&idproc=<?= $rs['process_status'] ?>">
                                <img src="../images/preview_24.png" />
                        </a>
                </td>
        </tr>
        <?php $i++; endwhile; ?>
</table>
<?php if ($total > 0): ?>
        <div class="browse_page">
                <?php page_navigator_user($before_p, $plus_p, $total, $total_p, $chk_page, base64_encode('fgsplitreport'), $txtsearch); ?>
        </div>
<?php endif; ?>
<?php
} else {
        echo "<br/><br/><br/><center><div class='table_comment'>No data available.</div></center>";
}
?>
</div>
