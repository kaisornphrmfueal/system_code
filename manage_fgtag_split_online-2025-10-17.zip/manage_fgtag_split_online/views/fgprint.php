<?php
  // ใช้ $con เป็น mysqli connection
  if(!empty($_POST['hbutton']) && $_POST['hbutton']=="Start"){
    $mxsid = selectMxSupp();
    $sqlup = "INSERT INTO ".DB_DATABASE1.".fgt_supplier_tag 
      SET id_print_tag='$mxsid', 
        id_model='".$_POST['hmodel']."', 
        tag_qty='".$_POST['tqty']."', 
        separate_qty='".$_POST['tqty']."', 
        emp_insert='$user_login', 
        date_insert='".date('Y-m-d H:i:s')."'";
    mysqli_query($con, $sqlup);
    gotopage("index_fg.php?id=".base64_encode('fgprint_tag')."&stag=$mxsid");
  }
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">
window.onload = function() {
  document.getElementById("tsearch").focus();
  document.getElementById("tsearch").select();
}

function validate(form2) {   
  if(document.form2.model_code.value == ""){
      alert("Please input Model code");
      document.form2.model_code.focus();
      return (false);
  }else{  
      form2.button.disabled = true;  
      form2.button.value = 'Adding...';  
      return true;  
      }
}
</script>

<div align="center">
 <form id="form1" name="form1" method="post" action="" autocomplete="off">
   <table width="482" border="1" align="center" class="table01" >
	     <tr>
     <td height="37" colspan="2" align="center" bgcolor="#EBD94E">Supplier Tag Printing</td>
     </tr>
   <tr>
   <tr>
     <td width="196" height="37"><div class="tmagin_right">Scan Model No.</div> </td>
     <td width="411">
        <input type="text" name="tsearch" id="tsearch" style=" width:180px;"  value="<?php echo @$_POST['tsearch']?>"/>
     <input type="submit" name="button" id="button" value="Submit" /></td>
   </tr>
   </table>
</form>   
</div>
<?php
?>
 <div class="rightPane" align="center">
<?php
    if(!empty($_POST['tsearch'])){
      $sql = "SELECT b.id_model,b.model_code,b.model_name,b.tag_model_no,b.customer,b.std_qty,
          b.customer_part_no,b.customer_part_name,b.model_picture,b.status_tag_printing
          FROM ".DB_DATABASE1.".fgt_model b 
          WHERE b.tag_model_no ='".$_POST['tsearch']."' ";
      $qr = mysqli_query($con, $sql);
      $rs = mysqli_fetch_array($qr);
      $total = mysqli_num_rows($qr);  
      if($total != 0){    
?>
 <form action="" method="post"  name="form2" id="form2"  onsubmit='return validate(this)' autocomplete="off">
<table width="600px"  border="1" class="table01" align="center">

  <tr>
  <th height="27" colspan="2">Separate Supplier Tag</th>
  </tr>
  <tr>
    <td width="452" height="25"><div class="tmagin_left">Model Picture :</div></td>  
    <td width="682"><div class="tmagin_right">
  <?php 
     if(!empty($rs['model_picture'])){
      echo "<img src='".DIR_UPLOAD.DIR_MPIC.$rs['model_picture']."' />";    
      //echo "<img src='".HTTP_SERVER_TRUE.DIR_PAGE.DIR_VIEWS.DIR_UPLOAD.DIR_MPIC.$rs['model_picture']."' />";    
      }
     ?>
    </div>
    </td>
  </tr>
  <tr>
  <td width="452" height="25"><div class="tmagin_left">Model Code. :</div></td>  
  <td width="682"><div class="tmagin_right">
   <?php echo $rs['model_code'];?>
  </div></td>
  </tr>
   <tr>
  <td width="452" height="25"><div class="tmagin_left">Model No. (Tag) :</div></td>
  <td width="682"><div class="tmagin_right">
   <?php echo $rs['tag_model_no']." [".$rs['model_name']."]"; ?>
  </div></td>
  </tr>
   <tr>
   <td width="452" height="25"><div class="tmagin_left">Customer Name :</div></td>  
   <td width="682"><div class="tmagin_right"> 
   <?php echo $rs['customer'];?></div></td>
   </tr>
   <tr>
  <td width="452" height="25"><div class="tmagin_left">Customer Part No.   :</div></td>
  <td width="682"><div class="tmagin_right"> 
   <?php echo $rs['customer_part_no']." [".$rs['customer_part_name']."]";?></div></td>
  </tr>
<tr> 
  <td width="452" height="25"><div class="tmagin_left">Standard  Qty.    :</div></td> 
  <td width="682"><div class="tmagin_right">  <?php echo $rs['std_qty'];?></div>  </td>
</tr>
   <tr>
    <td width="452" height="25"><div class="tmagin_left">Separate Tag Qty/page :</div></td>  
    <td width="682"><div class="tmagin_right">
    <select name="tqty" id="tqty">
      <?php  for ($j=1;$j<=$rs['std_qty'];$j++){
       echo " <option value='$j'>$j</option>";
   }?>
    </select>
   </div>
    </td>
  </tr>
  <td height="25" colspan="2" align="center">
    <input id='button'  name='button' type='submit' value='Start' />
    <input type="hidden" name="hbutton" id="hbutton" value="Start" />
    <input type="hidden" name="hmodel" id="hmodel"  value="<?=$rs['id_model']?>"/>
    <input type="hidden" name="hstdqty" id="hstdqty"  value="<?=$rs['std_qty']?>"/></td>
  </tr>
</table>
 </form>  
 <?php }else{
          echo "<br/><br/><br/><center><div class='table_comment' >ไม่มีข้อมูลที่ค้นหา กรุณาแสกนข้อมูลอีกครั้ง ";
      }
     ?>
 <?php }else{
          echo "<br/><br/><br/><center><div class='table_comment' >กรุณาแสกนโมเดลที่ต้องการปริ้น Supplier Tag ";
      }
     ?>
</div>
