<?php require('../includes/template_top.php'); ?>


<div class="body_resize"> 

<?php 

	if(!empty($_GET['id']) ){
		 require(base64_decode($_GET['id']).".php"); 
	}else{
		 require("manage.php"); 
	}
?>
</div>

<?php require('../includes/template_bottom.php'); ?>