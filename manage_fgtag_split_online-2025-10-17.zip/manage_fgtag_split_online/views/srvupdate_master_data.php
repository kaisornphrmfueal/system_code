<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<div align="center">
	<form id="searchForm" method="post" action="">
		<table width="710" border="1" align="center" class="table01">
			<tr>
				<td width="366" height="37">
					<div class="tmagin_right">Search : Type Data or Model Name</div>
				</td>
				<td width="328">
					<input type="text" name="tsearch" id="tsearch" style="width:180px;" value="<?= htmlspecialchars(@$_POST['tsearch']) ?>" />
					<input type="submit" name="button" id="button" value="Submit" />
				</td>
			</tr>
		</table>
	</form>
</div>
<div class="rightPane">
<?php
// Assume $con is a valid mysqli connection
$search = '';
if (!empty($_POST['tsearch']) || !empty($_GET['serh'])) {
	$search = !empty($_POST['tsearch']) ? $_POST['tsearch'] : $_GET['serh'];
	$search_esc = mysqli_real_escape_string($con, $search);
	$where = "WHERE (a.type_data LIKE '%$search_esc%' OR b.model_name LIKE '%$search_esc%')";
} else {
	$where = "";
}

$sql = "
	SELECT 
		a.id_update, a.id_action, a.action_name, a.path, a.version_up, a.emp_insert, a.type_data,
		IFNULL(b.model_name, '-') AS modelname,
		IFNULL(a.detail, '-') AS details,
		DATE_FORMAT(a.date_insert, '%d-%b-%Y %H:%i') AS date_modify
	FROM " . DB_DATABASE1 . ".fgt_srv_update a
	LEFT JOIN " . DB_DATABASE1 . ".fgt_model b ON a.id_action = b.id_model
	$where
	GROUP BY a.id_update
	ORDER BY a.id_update DESC
";
$result = mysqli_query($con, $sql);
$total = mysqli_num_rows($result);

if ($total > 0) {
	$e_page = 15;
	$chk_page = isset($_GET['s_page']) ? (int)$_GET['s_page'] : 0;
	$start = $chk_page * $e_page;
	$sql .= " LIMIT $start, $e_page";
	$result = mysqli_query($con, $sql);

	$plus_p = ($chk_page * $e_page) + mysqli_num_rows($result);
	$total_p = ceil($total / $e_page);
	$before_p = ($chk_page * $e_page) + 1;
	$i = 1;
?>
	<form id="dataForm" method="post" action="">
		<table width="892" border="1" bordercolor="#CC9966" class="table01" align="center">
			<tr>
				<th colspan="9"><div align="center">Update Master Data</div></th>
			</tr>
			<tr>
				<th width="4%">No.</th>
				<th width="9%">ID Update</th>
				<th width="12%">Action Name</th>
				<th width="11%">Type Data</th>
				<th width="14%">Model Name</th>
				<th width="15%">Detail</th>
				<th width="10%">Last Version</th>
				<th width="17%">Date modified</th>
				<th width="8%">User modified</th>
			</tr>
			<?php while ($rs = mysqli_fetch_assoc($result)) { ?>
				<tr height="28" onMouseOver="className='over'" onMouseOut="className=''" align="center">
					<td><?= $i ?></td>
					<td><?= htmlspecialchars($rs['id_update']) ?></td>
					<td><?= htmlspecialchars($rs['action_name']) ?></td>
					<td><?= htmlspecialchars($rs['type_data']) ?></td>
					<td><?= htmlspecialchars($rs['modelname']) ?></td>
					<td><?= htmlspecialchars($rs['details']) ?></td>
					<td><?= htmlspecialchars($rs['version_up']) ?></td>
					<td><?= htmlspecialchars($rs['date_modify']) ?></td>
					<td><?= htmlspecialchars($rs['emp_insert']) ?></td>
				</tr>
			<?php $i++; } ?>
		</table>
	</form>
	<?php if ($total > 0) { ?>
		<div class="browse_page">
			<?php @page_navigator_user($before_p, $plus_p, $total, $total_p, $chk_page, base64_encode('srvupdate_master_data'), $search); ?>
		</div>
	<?php }
} else {
	echo "<br/><br/><br/><center><div class='table_comment'>No data available.</div></center>";
}
?>
</div>
