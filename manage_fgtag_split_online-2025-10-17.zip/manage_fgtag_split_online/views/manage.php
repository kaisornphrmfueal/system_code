<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<div class="body_resize" align="center">

<form id="form1" name="form1" method="post" action="">
  <table width="710" border="1" align="center" class="table01">
    <tr>
      <td width="366" height="37">
        <div class="tmagin_right">Search : Model Code or Model No. or Model Name</div>
      </td>
      <td width="328">
        <input type="text" name="tsearch" id="tsearch" style="width:180px;" value="<?= htmlspecialchars(@$_POST['tsearch']) ?>" />
        <input type="submit" name="button" id="button" value="Submit" />
      </td>
    </tr>
  </table>
</form>

<?php
$txtsearsh = '';
if (!empty($_POST['tsearch']) || !empty($_GET['serh'])) {
    $txtsearsh = !empty($_POST['tsearch']) ? $_POST['tsearch'] : $_GET['serh'];
    // Escape for LIKE
    $txtsearsh_esc = mysqli_real_escape_string($con, $txtsearsh);
    $x = "WHERE ((model_code LIKE '%$txtsearsh_esc%') OR (tag_model_no LIKE '%$txtsearsh_esc%') OR (model_name LIKE '%$txtsearsh_esc%'))";
} else {
    $x = "";
}

$q = "SELECT id_model, model_code, tag_model_no, label_model_no, model_name, std_qty,
        customer, customer_part_no, customer_part_name, model_picture,
        CASE status_tag_printing WHEN 0 THEN 'FG Tag, Supplier Tag' WHEN 1 THEN 'Only FG Tag' ELSE 'No Tag' END AS sptag
      FROM " . DB_DATABASE1 . ".fgt_model
      $x
      GROUP BY id_model
      ORDER BY tag_model_no";

$qr = mysqli_query($con, $q);
$total = mysqli_num_rows($qr);

if ($total != 0) {
    $e_page = 15;
    $chk_page = 0;

    if (!isset($_GET['s_page'])) {
        $_GET['s_page'] = 0;
    } else {
        $chk_page = $_GET['s_page'];
        $_GET['s_page'] = $_GET['s_page'] * $e_page;
    }

    $q .= " LIMIT " . $_GET['s_page'] . ",$e_page";
    $qr = mysqli_query($con, $q);

    if (mysqli_num_rows($qr) >= 1) {
        @$plus_p = ($chk_page * $e_page) + mysqli_num_rows($qr);
    } else {
        @$plus_p = ($chk_page * $e_page);
    }
    $total_p = ceil($total / $e_page);
    @$before_p = ($chk_page * $e_page) + 1;
    $i = 1;
    ?>
    <div class="rightPane">
      <table width="98%" height="123" border="1" bordercolor="#CC9966" class="table01" align="center">
        <tr>
          <th height="28" colspan="11">
            <div align="center">Model Master Report</div>
          </th>
          <th height="28">
            <a href="#" onClick="javascript:openWins('windows.php?win=add&idm=', '_blank',650, 380, 1, 1, 0, 0, 0);return false;">
              Add New
            </a>
          </th>
        </tr>
        <tr>
          <th width="3%" height="28">No.</th>
          <th width="5%">Model Code</th>
          <th width="11%"><span class="tmagin_right">Model No. (Tag)</span></th>
          <th width="12%">Model No.(Label)</th>
          <th width="8%">Model Name</th>
          <th width="6%">Standard Qty.</th>
          <th width="8%">Customer</th>
          <th width="10%">  Customer Part  No.  </th>
          <th width="9%">Customer Part  name</th>
          <th width="11%">Tag</th>
          <th width="11%">Model Image</th>
          <th width="6%">Update</th>
        </tr>
        <?php while ($rs = mysqli_fetch_array($qr)) { ?>
          <tr <?= icolor($i) ?> onMouseOver="className='over'" onMouseOut="className=''" align="center">
            <td height="30px"><?= $i ?></td>
            <td height="30px"><?= htmlspecialchars($rs['model_code']) ?></td>
            <td><?= htmlspecialchars($rs['tag_model_no']) ?></td>
            <td><?= htmlspecialchars($rs['label_model_no']) ?></td>
            <td><?= htmlspecialchars($rs['model_name']) ?></td>
            <td><?= htmlspecialchars($rs['std_qty']) ?></td>
            <td><?= htmlspecialchars($rs['customer']) ?></td>
            <td><?= htmlspecialchars($rs['customer_part_no']) ?></td>
            <td height="30px"><?= htmlspecialchars($rs['customer_part_name']) ?></td>
            <td height="30px"><div class="tmagin_right"><?= htmlspecialchars($rs['sptag']) ?></div></td>
            <td height="30px">
              <img src="<?= DIR_UPLOAD . DIR_MPIC . $rs['model_picture'] ?>" />
            </td>
            <td>
              <a href="#" onClick="javascript:openWins('windows.php?win=add&idm=<?= $rs['id_model']; ?>', '_blank', 650, 460, 1, 1, 0, 0, 0);return false;">
                <img src="../images/001_45.gif" />
              </a>
            </td>
          </tr>
        <?php $i++;
        } ?>
      </table>
      <?php if ($total > 0) { ?>
        <div class="browse_page">
          <?php @page_navigator_user($before_p, $plus_p, $total, $total_p, $chk_page, base64_encode('manage'), $txtsearsh); ?>
        </div>
      <?php } ?>
    </div>
    <?php
} else {
    echo "<br/><br/><br/><center><div class='table_comment' >No hava Data...Click ";
    ?>
    <a href="#" onClick="javascript:openWins('windows.php?win=add&idm=', '_blank',650, 380, 1, 1, 0, 0, 0);return false;">here</a>
    <?php
    echo " to create new data </div> </center>";
}
?>
