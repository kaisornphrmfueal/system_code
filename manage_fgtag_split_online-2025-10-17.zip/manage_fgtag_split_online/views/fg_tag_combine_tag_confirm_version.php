
<?php
/*echo "</br>--".	 $_POST['cmid'];
echo "</br>--".$idmodel= $_POST['tagmodl'];
echo "</br>--".	$combine_qty= $_POST['tqty'];
echo "</br>--".	$start_tag=$_POST['tsearch'];
echo "</br>--".	$start_tagno=substr($_POST['tsearch'],-9); 
echo "</br>--".	$start_ticket=sprintf("%09d", $_POST['sticket']); 
echo "</br>--".	$stag_qty=$_POST['tagqtys'];
	echo "</br>--" .$pstatusnew=$_POST['statusnew'];
	
*/
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">

 $(window).on('load', function() {

		//// alert("ddd")
        	if (document.getElementById("usern").value == '') {
				document.getElementById("usern").focus();
				document.getElementById("usern").select();
				document.getElementById("button2").disabled = true;		
			document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณากรอก Username เพื่อยืนยันการ Combine ต่าง Version';
			}
      });
	
	
	
	//START userNext
 function userNext(e) {
	  // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
		 let gusern=document.getElementById("usern").value.toString();
		let lenbc = gusern.length;
	//alert(lenbc);
		if(lenbc == 6){
    	
				document.getElementById("passw").focus();
				document.getElementById("passw").select();
				document.getElementById("usern").readOnly = true;		
			document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณากรอก Password เพื่อยืนยันการ Combine ต่าง Version';
		
		}else{
				document.getElementById("usern").focus();
				document.getElementById("usern").select();
				document.getElementById("button2").disabled = true;		
			document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณากรอก Username เพื่อยืนยันการ Combine ต่าง Version';
		}//if(gusern == 6){

    }///   if (e.keyCode == 13)
	 return true;
 
 }// function userNext(e) {
	//END userNext

	

 function passConfirm(e) {
	  //alert("ddd")
	  e = e || window.event;
    if (e.keyCode == 13)
    {
		
		let usr=document.getElementById("usern").value;
		let pass=document.getElementById("passw").value;
//alert(pass);
		if(pass != ""){
		//	alert(pass);
			 $.ajax({
				url: "chkpass.php?guser="+ usr + "&gpass="+ pass ,
				method: 'GET', 
				success: function (data) {
						//alert(data)
			var rqrPass= data.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '')
					
				
				if(rqrPass == "No"){
					//alert ("NO" + rqrPass);
					const input = document.getElementById("passw");
					  input.focus();
					  input.select();
					document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณากรอกUsername  หรือ  Password ที่ถูกต้อง';
					
					}else{
						//alert ("YES" + rqrPass);
				
								document.getElementById("passw").readOnly = true;
						
								document.getElementById("button2").disabled = false; ;
							 document.getElementById("scan2").submit();
						
					//	return false;

					}//if(data!= null){
				}
			}); // $.ajax({
			
		 }else{

			 	document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณากรอก Password เพื่อยืนยันการ Combine ต่าง Version';
		
		 }//if(pass != ""){

		}   // if (e.keyCode == 13) return true;
	 
		
    }//function getQty(e) {

</script>


 <div class="rightPane" align="center">
  <?php
  	//$lineid= $_GET['lid'];

	
  	if (!empty($_GET['idcomb'])){
	//	idcomb=" + pcombid + "&nstick=" + gticket + "&ntagqtys=" + gqty + "&ntagmodl=" + gmol+ "&ntagbarc=" + tagsp;
		
		$gidcomb =$_GET['idcomb'];
		$gnew_ticket=$_GET['nstick'];
		$gnew_tagqty=$_GET['ntagqtys'];
		$gnew_modelid=$_GET['ntagmodl'];
		$gnew_tagbarcode=$_GET['ntagbarc'];
		
		$sql_newml ="SELECT tag_model_no , id_model
					FROM ".DB_DATABASE1.".fgt_model 
					WHERE id_model='$gnew_modelid'
					GROUP BY id_model  ";
		$qr_newml=mysqli_query($con, $sql_newml);
		 $rssnewml=mysqli_fetch_array($qr_newml);	
		$rsnewm_no=$rssnewml['tag_model_no'];

	 		
		 $sql_st="SELECT a.id_combine ,e.tag_model_no,a.combine_qty,COUNT(c.id_combine_serial) AS count_qty
				FROM ".DB_DATABASE1.".fgt_split_combine AS a
				LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag AS b  ON a.id_combine=b.id_combine 
				 LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial c ON b.id_fg_combine_tag =c.id_fg_combine_tag AND c.serial_label_confirm IS NOT NULL
				INNER JOIN (
					SELECT tag_model_no , id_model,MAX(id_model ) AS max_id
					FROM ".DB_DATABASE1.".fgt_model 
					GROUP BY id_model
				) e ON b.id_model=e.id_model  AND b.id_model
				WHERE  a.id_combine ='".$gidcomb."'   
				GROUP BY a.id_combine   "; 

	 // echo $sql_st;
		$qr_st=mysqli_query($con, $sql_st);
		if($num_st=mysqli_num_rows($qr_st)<>0){
			$rsst=mysqli_fetch_array($qr_st);
			//$modelid=$rsst['id_model'];
			$id_combine=$rsst['id_combine'];
			$currentmo=$rsst['tag_model_no'];
			$combine_qty=$rsst['combine_qty'];
			$countall=$rsst['count_qty'];
  ?>
  

<form name="scan2"  id="scan2" method="post" action="index_fg.php?id=<?=base64_encode('fg_tag_combine_tag_start')?>"   onsubmit="return false;"  autocomplete="off" >
            
    <table width="952" height="333" border="1" align="center" class="table01">
              <tr>
                <td height="40" colspan="2" align="center"><span class="text_black">F/G Transfer Tag Combine</span>  =&gt; <span class="txt-red-b-s" >Confirm Different Version</span></td>
              </tr>
		
	
		
		
		
		
		
		 <tr>
                <td height="40"><div class="tmagin_left"><span class="text_black">Combine Target Model :<br />
           </span></div></td>
                <td height="40"><div class="tmagin_right">
					 
              		<!--   style="display:none;" -->
					
                  <!--0= start, 1= spliting,  2= finished, 3=cancel-->
                  <input  type="text" name="current_model" id="current_model"  class="bigtxtbox" style="width:290px;"  value="<?php echo $currentmo;?>"   readonly / >
                </div></td>
              </tr>
			<tr>
			<td height="40"><div class="tmagin_left"><span class="text_black">Combine Qty. : </span></div></td>
                <td height="40"><div class="tmagin_right"> <span class="txt-black-big">
                  <?php  echo "<span id=txtTag>$combine_qty</span> ";?>
                  </span> ||  <span class="text_black"> Combine Qty. Remaining : </span><span class="txt-blue-big" id="split_tagnew_qty2">
                    <?php  echo $combine_remain=$combine_qty-$countall; ?>
                </span></div></td>
      </tr>
	
		 <tr>
                <td height="40"><div class="tmagin_left"><span class="text_black"> New F/G Tag for Combine :<br />
                </span></div></td>
                <td height="40"><div class="tmagin_right">
					  
                  <input type="text" name="tsearch" id="tsearch"  class="bigtxtbox" style="width:290px;"  value="<?php echo $gnew_tagbarcode;?>"  readonly />
                </div></td>
              </tr>
	 <tr>
                <td height="40"><div class="tmagin_left"><span class="text_black"> New  Model for Combine :<br />
        </span></div></td>
                <td height="40"><div class="tmagin_right">
					  
                  <input type="text" name="new_model" id="new_model"  class="bigtxtbox" style="width:290px;"   value="<?php echo $rsnewm_no;?>"  readonly /> 
                </div></td>
              </tr>
				
		<tr>
                <td height="40"><div class="tmagin_left"><span class="text_black"> New  Tag Qty. for Combine :<br />
                </span></div></td>
                <td height="40"><div class="tmagin_right">
					  
                  <input type="text" name="tagqtys" id="tagqtys"  class="bigtxtbox" style="width:50px;"  value="<?php echo $gnew_tagqty;?>"  readonly />
                </div></td>
              </tr>
		
		
			
		<tr>
                <td width="375" height="40"><div class="tmagin_left"><span class="text_black">Username : </span><br />
                </div></td>
                <td width="561" height="40">  <div class="tmagin_right">
                  <input type="text" name="usern" id="usern"  class="bigtxtbox" style="width:290px;"  onkeypress="return userNext(event);" onClick="this.select();" />
                </div>
                </td>
      </tr>
		
		
                <tr>
                <td height="40"><div class="tmagin_left"> <span class="text_black">Password  : <br />
                </span></div></td> 
                <td >
                <div class="tmagin_right">
               
                  <input type="password" name="passw" id="passw"  class="bigtxtbox" style="width:290px;"  onkeypress="return passConfirm(event);" />
				  </div>
             
              </tr>	
		
		
		
					<tr>
			     
                <td colspan="2" height="75px"  align="center">
             <div id="txtStatus"></div>

                </td>
              </tr>
				<tr>
                <td height="40" colspan="2" align="center"> 
				
				<input type="button" name="button2" id="button2" value="Submit" /> 
		  <input type="hidden" name="scan2" id="scan2"  value="Submit" />  
					<input type="hidden" name="cmid" id="cmid"  value="<?php echo $id_combine;?>"/> 
			  <input type="hidden" name="sticket" id="sticket"  value="<?php echo $gnew_ticket;?>"/> 
			 <input type="hidden" name="tagmodl" id="tagmodl"  value="<?php echo $gnew_modelid;?>"/>
					<input type="hidden" name="statusnew" id="statusnew"  value="conf"/>
					 <input type="hidden" name="tqty" id="tqty"  value="<?php echo $combine_qty;?>"/>
					
                </td>
              </tr>	
					
    </table>
  
</form>

  <?php

	}else{
		echo "<center><div class='table_comment' >
		<a href='index.php?id=".base64_encode('line')."'>ไม่มีข้อมูลการตั้งต้นของโมเดล คลิกที่นี่ เพื่อแสกน Kanban อีกครั้ง</a></div></center>";
		}//if($num_st=mysql_num_rows($qr_st)<>0){


	} //if (!empty($_GET['combid'])){
	 ?>
</div>
