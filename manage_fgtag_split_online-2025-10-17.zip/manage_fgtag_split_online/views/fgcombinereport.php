<?php

if (!empty($_GET['idrep']) && $_GET['idrep'] == "rep") {

	$id_reprint=$_GET['reqid'];
	$sqldl = "UPDATE " . DB_DATABASE1 . ".fgt_split_combine
			SET  emp_reprint='$user_login',date_reprint='" . date('Y-m-d H:i:s') . "'
			WHERE id_combine='" . $id_reprint . "' ";
	$qrdl = mysqli_query($con, $sqldl);

	 $sqlcbtg = "SELECT f.id_model, m.status_tag_printing, f.tag_no_original 
									FROM ".DB_DATABASE1.".fgt_split_combine_fg_tag  f
									LEFT JOIN ".DB_DATABASE1.".fgt_model m ON f.id_model =m.id_model 
									WHERE f.id_combine='$id_reprint'
									GROUP BY f.id_model  
									ORDER BY f.id_model DESC ";
		
						$qrmo = mysqli_query($con, $sqlcbtg);
						$qrmomax = mysqli_query($con, $sqlcbtg);
						$totalmo = mysqli_num_rows($qrmo);	
					if ($totalmo != 0) 
						$rsmomax = mysqli_fetch_array($qrmomax);
						// START Print Suppllier TAG 
						if($rsmomax['status_tag_printing']==0){
							$mxsptag=$rsmomax['tag_no_original'];
							printTagCombineSupplier($mxsptag,$id_reprint);
						}
						
						
						///------END  Print Suppllier TAG -------
						
						while ($rsmo = mysqli_fetch_array($qrmo)) {
							$modelqrcomb=$rsmo['id_model'];
							$sql_maxtag="
							SELECT t2.tag_no_original,a.date_print ,f.id_model,SUM(f.tag_qty) AS tagqt,t2.date_print
							FROM  ".DB_DATABASE1.".fgt_split_combine_fg_tag  f
							LEFT JOIN  ".DB_DATABASE1.".fgt_srv_tag  a  ON f.tag_no_original =a.tag_no 
							INNER JOIN (
								SELECT f.tag_no_original,MAX(a.date_print ) AS date_print  ,f.id_model,f.id_combine
								FROM  ".DB_DATABASE1.".fgt_split_combine_fg_tag  f
								LEFT JOIN  ".DB_DATABASE1.".fgt_srv_tag  a  ON f.tag_no_original =a.tag_no 
								WHERE a.date_print = (SELECT MAX(a.date_print ) 
												FROM  ".DB_DATABASE1.".fgt_split_combine_fg_tag f 
								 			LEFT JOIN  ".DB_DATABASE1.".fgt_srv_tag a ON f.tag_no_original =a.tag_no
											 WHERE f.id_combine='$id_reprint' AND f.id_model = '$modelqrcomb'    ) 
								) t2 ON f.id_combine = t2.id_combine AND f.id_model=t2.id_model  
							WHERE   f.id_model = '$modelqrcomb'
							GROUP BY f.id_combine , f.id_model  ";
								$qr_maxtag=mysqli_query($con, $sql_maxtag);
							   $rsmaxtag=mysqli_fetch_array($qr_maxtag);	
								$mxtagn=$rsmaxtag['tag_no_original'];
								$tagqtymodel=$rsmaxtag['tagqt'];
							
							//echo "</br>--".$pcombineid;
								
										printTagCombine($mxtagn,$id_reprint,$tagqtymodel,$modelqrcomb); 
						
						sleep(3);
						

						}//while ($rsmo = mysqli_fetch_array($qrserial)) {
	
	
			log_hist($usprint,"Reprinted Combine Tag",$preprint,"fgt_tag","");
	gotopage("index_fg.php?id=" . base64_encode('fgcombinereport'));
	
	
}
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">

	function rePrint(reqid){//(reqid)
  if(confirm('Do you want to Repritn F/G Trensfer Tag?')) { 
 //	alert(reqid);
	  
    let linkenc =  btoa(unescape(encodeURIComponent("fgcombinereport")));
 window.location.href="index_fg.php?id="+ linkenc +"&reqid="+ reqid + "&idrep=rep"; 
  }
  else {
     //'Cancel' is clicked
  }
}
</script>

<form id="form1" name="form1" method="post" action="">
    <table width="710" border="1" align="center" class="table01">
        <tr>
            <td width="349" height="37">
                <div class="tmagin_right">Search : Model No., Model Code, Model Name, F/G Tag No.</div>
            </td>
            <td width="345">
                <input type="text" name="tsearch" id="tsearch" style="width:180px;" value="<?= htmlspecialchars(@$_POST['tsearch']) ?>"/>
                <input type="submit" name="button" id="button" value="Search" />
            </td>
        </tr>
    </table>
</form>

<div class="rightPane">
<?php
// Assume $con is a valid mysqli connection

function getSearchText() {
        if (!empty($_POST['tsearch'])) {
                return $_POST['tsearch'];
        }
        if (!empty($_GET['serh'])) {
                return $_GET['serh'];
        }
        return '';
}

$txtsearch = getSearchText();
$searchCondition = '';
if ($txtsearch !== '') {
        $txtsearch_esc = mysqli_real_escape_string($con, $txtsearch);
        $searchCondition = "AND (c.tag_no_original LIKE '$txtsearch_esc%'
                OR b.model_code LIKE '$txtsearch_esc%'
                OR b.model_name LIKE '$txtsearch_esc%'
                OR b.tag_model_no LIKE '$txtsearch_esc%' 
        )";
}

   $query = "SELECT a.id_combine,a.combine_qty, a.item_status,
		 CASE WHEN a.item_status=0 THEN 'Start'
		WHEN a.item_status =1 THEN 'Start Combine' 
		WHEN a.item_status=2 THEN 'Finished' 
		WHEN a.item_status=3 THEN 'Cancel' 
		WHEN a.item_status=4 THEN 'Accept Duplicate Combine' ELSE 'Error' END AS itemstatus,
		b.model_name,b.tag_model_no,
		CONCAT( d.name_en ,'[', DATE_FORMAT(a.date_insert, '%d-%b-%Y %H:%i'),']') AS conv_date,
		IFNULL(CONCAT( e.name_en ,'[', DATE_FORMAT(a.date_reprint, '%d-%b-%Y %H:%i'),']'),'-') AS reprint_date ,
		GROUP_CONCAT(DISTINCT(c.tag_no_original) SEPARATOR ', ') AS alltag
		FROM " . DB_DATABASE1 . ".fgt_split_combine a 
		LEFT JOIN " . DB_DATABASE1 . ".fgt_split_combine_fg_tag c ON a.id_combine =c.id_combine 
		LEFT JOIN " . DB_DATABASE1 . ".fgt_model b ON c.id_model =b.id_model
		LEFT JOIN ".DB_DATABASESSO.".so_view_fttl_and_sub d ON a.emp_id_insert =d.emp_id
		LEFT JOIN ".DB_DATABASESSO.".so_view_fttl_and_sub e ON a.emp_reprint = e.emp_id 
		WHERE a.item_status <> 3 
		 $searchCondition
		GROUP BY a.id_combine  ORDER BY a.item_status , a.date_insert DESC";
//echo $query ;
$result = mysqli_query($con, $query);
$total = mysqli_num_rows($result);

if ($total > 0) {
        $e_page = 15;
        $chk_page = isset($_GET['s_page']) ? intval($_GET['s_page']) : 0;
        $start = $chk_page * $e_page;

        $pagedQuery = $query . " LIMIT $start, $e_page";
        $pagedResult = mysqli_query($con, $pagedQuery);

        $plus_p = ($chk_page * $e_page) + mysqli_num_rows($pagedResult);
        $total_p = ceil($total / $e_page);
        $before_p = ($chk_page * $e_page) + 1;
        $i = $before_p;
?>
<table width="98%" border="1" bordercolor="#CC9966" class="table01" align="center">
        <tr>
                <th height="27" colspan="10">
                        <div align="center">F/G Transfer Tag Combine Report</div>
                </th>
        </tr>
        <tr>
                <th width="3%" height="27">No.</th>
                <th width="26%">Model No. (Tag)(Original Latest Version)</th>
                <th width="11%">Model Name</th>
                <th width="10%">All F/G Tag</th>
                <th width="10%">Combine Qty.</th>
                <th width="8%">Status</th>
                <th width="14%">Combine By</th>
                <th width="13%">Re-Print By</th>
                <th width="6%">View</th>
                <th width="9%">Reprint</th>
        </tr>
        <?php while ($rs = mysqli_fetch_assoc($pagedResult)): ?>
        <tr <?= icolor($i) ?> height="28" onMouseOver="className='over'" onMouseOut="className=''" align="center">
                <td><?= $i ?></td>
                <td><?= htmlspecialchars($rs['tag_model_no']) ?></td>
                <td><?= htmlspecialchars($rs['model_name']) ?></td>
                <td><?= htmlspecialchars($rs['alltag']) ?></td>
                <td><?= htmlspecialchars($rs['combine_qty']) ?></td>
                <td><?= htmlspecialchars($rs['itemstatus']) ?></td>
                <td><?= htmlspecialchars($rs['conv_date']) ?></td>
                <td><?= htmlspecialchars($rs['reprint_date']) ?></td>
                <td><a href="index_fg.php?id=<?= base64_encode('fg_tag_combine_tag_start') ?>&combid=<?= $rs['id_combine'] ?>"> <img src="../images/preview_24.png" /> </a></td>
                <td>
					 
                         <?php  if($rs['item_status']=="2"){?> 
		  <input type="button"  id="btn_reprint" name="btn_reprint" class="button3" 
		value="Re-Print"     onclick="return rePrint(<?php echo $rs['id_combine'];?> );" >
	</input>
	
		<?php } //0= start, 1= spliting,  2= finished, 3=cancel ?>
                     
                </td>
        </tr>
        <?php $i++; endwhile; ?>
</table>
<?php if ($total > 0): ?>
        <div class="browse_page">
                <?php page_navigator_user($before_p, $plus_p, $total, $total_p, $chk_page, base64_encode('fgcombinereport'), $txtsearch); ?>
  </div>
<?php endif; ?>
<?php
} else {
        echo "<br/><br/><br/><center><div class='table_comment'>No data available.</div></center>";
}
?>
</div>
