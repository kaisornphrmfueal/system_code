<?php
// สมมติว่ามี $con = mysqli_connect(...) แล้ว

if (!empty($_POST['hbutton']) && $_POST['hbutton'] == "Print") {
	$stagp = $_POST['hidprintst'];
	$pidsplit = $_POST['idsplit'];
	mysqli_query($con, "UPDATE " . DB_DATABASE1 . ".fgt_supplier_tag SET print_status=2 WHERE id_print_tag='$stagp' ");
	//--------- Create Text head ------------------
	$fp = fopen(DIR_UPLOAD . DIR_BTW . "fgtag.txt", "w");
	$i = 1;
	fwrite($fp, "Model,Tag No,Shift,Model Name,Model No,Produce Date ,Qty ,Serial No 1-n,Printed by,Printed date,Serial 1,Serial 2,Serial 3,Serial 4,Serial 5,Serial 6,Serial 7,Serial 8,Serial 9,Serial 10,Serial 11,Serial 12,Serial 13,Serial 14,Serial 15,Serial 16,FgTag,Part No,Part Name,image,status print,fg print,stdQty,datereprint\r\n");
	foreach ($pidsplit as $pids) :
		if ($pids != "" && $pids != "Array") {
			mysqli_query($con, "UPDATE " . DB_DATABASE1 . ".fgt_supplier_tag_split SET emp_reprint='$user_login', date_reprint='" . date('Y-m-d H:i:s') . "' WHERE id_split='$pids'");
			log_hist($user_login, "LGT RePrint", $pids, "fgt_supplier_tag_split", "");
			//------ Start Print SP Tag
			$sqltg = "SELECT a.id_split,b.id_model,b.model_code,a.tag_no,d.shift,b.model_name,b.tag_model_no,
				DATE_FORMAT(d.date_print, '%d-%b-%Y %H:%i') AS dateprint, a.stag_qty,
				CASE  a.stag_qty WHEN 1 THEN  a.sn_start ELSE  CONCAT(a.sn_start,'-',a.sn_end) END AS allserial,
				a.sn_start,a.sn_end,d.line_id,d.fg_tag_barcode,
				b.customer_part_no,b.customer_part_name,b.model_picture,d.status_print,b.status_tag_printing,c.line_name,b.std_qty
				FROM " . DB_DATABASE1 . ".fgt_supplier_tag_split a
				LEFT JOIN " . DB_DATABASE1 . ".fgt_srv_tag  d ON a.tag_no=d.tag_no
				LEFT JOIN " . DB_DATABASE1 . ".fgt_model b ON d.id_model=b.id_model
				LEFT JOIN " . DB_DATABASE1 . ".view_line c ON d.line_id=c.line_id
				WHERE a.id_split = '$pids' ";
			$qrtg = mysqli_query($con, $sqltg);
			$rstg = mysqli_fetch_array($qrtg);
			$serialtxt = whileprt($rstg['sn_start'], $rstg['sn_end'], $rstg['stag_qty']);
			fwrite($fp, $rstg['model_code'] . "," . $rstg['tag_no'] . "," . $rstg['shift'] . "," . $rstg['model_name'] . "," . $rstg['tag_model_no'] . "," . $rstg['dateprint'] . "," . $rstg['stag_qty'] . "," . $rstg['allserial'] . "," . $rstg['line_name'] . "," . $rstg['dateprint'] . $serialtxt . $rstg['fg_tag_barcode'] . "," . $rstg['customer_part_no'] . "," . $rstg['customer_part_name'] . "," . $rstg['model_picture'] . "," . $rstg['status_print'] . ",-," . $rstg['std_qty'] . ",\r\n");
			// ------ END Print SP Tag
		}
	endforeach;
	fclose($fp);
	// run commander
	//$flgCopy1 = copy("uploads/btw/cmd.txt", "uploads/btw/cmds/cmd.txt");
	$serverPath = DIR_SEVER.$_SESSION['station'] . "\\";
	$sourceFile = DIR_UPLOAD . DIR_BTW . "fgtag.txt";
	$destFile = $serverPath . "fgtag.txt";
	$cmdSource = $serverPath . "cmd.txt";
	$cmdDest = $serverPath . "cmds\\cmd.txt";

	$flgCopyDT = copy($sourceFile, $destFile);
	$flgCopy1 = copy($cmdSource, $cmdDest);

	sleep(3);
	gotopage("index_fg.php?id=" . base64_encode('fgreport'));
}
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">
// ... (เหมือนเดิม)
</script>

<?php
if (!empty($_GET['stag'])) {
	$gstag = $_GET['stag'];
	$sql = "SELECT b.id_model,b.model_code,b.model_name,b.tag_model_no,b.std_qty,a.separate_qty,b.model_picture,
		b.customer_part_no,b.customer_part_name,b.customer,a.id_print_tag
		FROM " . DB_DATABASE1 . ".fgt_supplier_tag a
		LEFT JOIN " . DB_DATABASE1 . ".fgt_model b ON a.id_model=b.id_model
		WHERE a.id_print_tag ='" . $gstag . "' ";
	$qr = mysqli_query($con, $sql);
	$rs = mysqli_fetch_array($qr);
	$total = mysqli_num_rows($qr);
	if ($total <> 0) {
		$tgmoel = $rs['tag_model_no'];
		$idpstag = $rs['id_print_tag'];
		$stdqty = $rs['std_qty'];
		$splitqty = $rs['separate_qty'];
?>
<div align="center">
<table width="762"  border="1" class="table01" align="center">
  <tr>
	<th height="27" colspan="6">Separate Supplier Tag</th>
  </tr>
	<tr>
	  <th width="117" height="25">Model Picture</th>
	  <th width="177">Model No. (Tag)</th>
	  <th width="113">Customer </th>
	  <th width="149">Customer <br />
	  Part No.  </th>
	  <th width="69">Standard  Qty</th>
	  <th width="97">Separate Tag Qty/page</th>
	</tr>
	<tr align="center">
	  <td height="25">
		<?php if (!empty($rs['model_picture'])) {
			echo "<img src='" . DIR_UPLOAD . DIR_MPIC . $rs['model_picture'] . "' />";
		}
		?>
	 </td>
	  <td><?php echo $tgmoel . " [" . $rs['model_name'] . "]"; ?></td>
	  <td><?php echo $rs['customer']; ?></td>
	  <td><?php echo $rs['customer_part_no'] . " [" . $rs['customer_part_name'] . "]"; ?></td>
	  <td><?php echo $stdqty; ?></td>
	  <td><?php echo $splitqty; ?></td>
	</tr>
</table>
<?php
	} else {
		echo "<br/><br/><br/><center><div class='table_comment' >No hava Data, please try again ";
	}
} else {
	echo "<br/><br/><br/><center><div class='table_comment' >Please scan Model No. ";
}
?>
</div>

<div class="rightPane" align="center">
	<form id="form1" name="form1" method="post" action="" onsubmit='return validate(this)'>
<?php
$q = "SELECT id_split,tag_no ,CONCAT(sn_start,'-',sn_end) AS allserial,stag_qty,
	IFNULL(emp_print,'-') AS empprint, IFNULL(DATE_FORMAT(date_print, '%d-%b-%Y %H:%i'),'-') AS dateprint, 
	IFNULL(emp_reprint,'-') AS empreprint, IFNULL(DATE_FORMAT(date_reprint, '%d-%b-%Y %H:%i'),'-') AS datereprint
	FROM " . DB_DATABASE1 . ".fgt_supplier_tag_split 
	WHERE id_print_tag = '$idpstag'
	ORDER BY id_split DESC";

$qr = mysqli_query($con, $q);
$total = mysqli_num_rows($qr);
$i = 1;
if ($total <> 0) {
?>
<table width="950px" height="108" border="1" bordercolor="#CC9966" class="table01" align="center">
	<tr>
	  <th height="27" colspan="9">
	  <div align="center">Tag Reprinting</div>  </th>
	  </tr>
	<tr>
	  <th width="3%" height="27">No.</th>
	  <th width="3%"><input type="checkbox" name="Check_ctr" value="yes"  onClick="Check(document.form1.idsplit)"/></th>
	  <th width="16%">Tag No</th>
	  <th width="23%">Serial </th>
	  <th width="7%">Tag Qty.</th>
	  <th width="11%">Print By</th>
	  <th width="14%">Print Date</th>
	  <th>Re-Print By</th>
	  <th>Re-Print Date</th>
	  </tr>
<?php while ($rs = mysqli_fetch_array($qr)) {
	$rtag = $rs['tag_no'];
	$resplit = $rs['id_split'];
?>
	  <tr <?php $v = 0; $v = $v + 1; echo icolor($v); ?> height="28" onMouseOver="className='over'"  onMouseOut="className=''" align="center">
	  <td><?php echo $i ?></td>
	  <td><input name="idsplit[]" id="idsplit" type="checkbox" value="<?php echo $resplit ?>" /></td>
	  <td><?php echo $rs['tag_no'] ?></td>
	  <td><?php echo $rs['allserial'] ?></td>
	  <td><?php echo $rs['stag_qty'] ?></td>
	  <td><?php echo $rs['empprint'] ?></td>
	  <td><?php echo $rs['dateprint'] ?></td>
	  <td><?php echo $rs['empreprint'] ?></td>
	  <td><?php echo $rs['datereprint'] ?></td>
	  </tr>
<?php
	$i++;
}
?>
  </table>
<div align="center">
	<input type="submit" name="btnprint" id="btnprint" value="Re-Print" class="buttonb" />
	<input type="hidden" name="hbutton" id="hbutton" value="Print" />
	<input type="hidden" name="hidprintst" id="hidprintst" value="<?php echo $idpstag ?>" />
</div>
<?php
} else {
	echo "<br/><br/><br/><center><div class='table_comment' >No hava Data  ";
}
?>
	</form>
</div>
