
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">


</script>

<div align="center">
 <form id="form1" name="form1" method="post" action="<?php echo "index_fg.php?id=".base64_encode('fg_tag_combine_tag');?>" autocomplete="off">
   <table width="482" border="1" align="center" class="table01" >
	  <tr>
     <td height="37" colspan="2" align="center" bgcolor= #F0EF4C>Combine F/G Transfer Tag</td>
     </tr>
 
   <tr>
     <td width="196" height="37"><div class="tmagin_right">Select Qty.</div> </td>
     <td width="411">
       <select name="tqty" id="tqty">
         <?php  
		
			for ($j=2;$j<13;$j++){
       echo " <option value='$j'>$j</option>";
   }?>
         </select>
        <input type="Submit" name="button2" id="button2" value="Submit" />
	   
	   
	   </td>
   </tr>
 
   </table>
</form>   
</div>
<?php
?>