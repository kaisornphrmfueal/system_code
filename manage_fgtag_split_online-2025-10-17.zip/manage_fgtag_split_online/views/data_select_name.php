<?php 
	require('../includes/configure.php'); 
	//require('../includes/chk_session.php'); 

	if (!empty($_GET["id"]) && $_GET["id"] !== "undefined") {
		$get_id = $_GET["id"];

		$sqlg = "SELECT CONCAT(name_en,'   ',lastname_en) AS sname 
				 FROM sign_on.so_employee_data 
				 WHERE emp_id = '$get_id'";        
		$resultg = mysqli_query($con, $sqlg);

		if (mysqli_num_rows($resultg) != 0) {
			$rowg = mysqli_fetch_assoc($resultg);
			echo $rowg['sname'];
		} else {
			echo "No have data...";
		}
	}
?>
