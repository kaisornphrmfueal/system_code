<?php

require_once '../includes/configure_host.php';
//include('../includes/configure.php');
				
if(!empty($_GET["gdata"]) && $_GET["gdata"]<>"undefined"){
	
	 $gtagsp=$_GET["gdata"];

	 $sqltk=" SELECT a.fg_tag_barcode , a.model_kanban, a.matching_ticket_no,a.tag_qty,a.id_model,b.std_qty,
	 		b.last_station,a.bsi_line_id
						FROM ".DB_DATABASE1.".fgt_srv_tag a
						LEFT JOIN ".DB_DATABASE1.".fgt_model b ON a.id_model=b.id_model
					 	WHERE  a.fg_tag_barcode = '$gtagsp'
						AND  a.fg_tag_barcode NOT IN (
							SELECT b.fg_tag_barcode  
							FROM  ".DB_DATABASE1.".fgt_split_fg_tag  b 
							 WHERE   b.item_status  IN (0,1,2)
							 GROUP BY b.fg_tag_barcode 
							 UNION ALL
							 SELECT c.fg_tag_barcode
							FROM  ".DB_DATABASE1.".fgt_split_fg_tag_conversion c 
							LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag  b  ON c.id_fg_split = b.id_fg_split
							 WHERE    b.item_status <> 2
							 AND  c.fg_tag_barcode  IS NOT NULL
							   GROUP BY c.fg_tag_barcode 
							  UNION ALL
						 SELECT b.fg_tag_barcode_original AS fg_tag_barcode
					  		FROM ".DB_DATABASE1.".fgt_split_combine AS a
							LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag AS b  ON a.id_combine=b.id_combine
							WHERE a.item_status = 2
							GROUP BY b.fg_tag_barcode_original  )
							GROUP BY a.fg_tag_barcode   ";
						//  0= start, 1= combine,  2= finished, 3=cancel,4= Accept duplicate
						//loop split = c.item_status  IN (0,2)
		  $rstk = mysqli_query($con, $sqltk);
	

if(mysqli_num_rows($rstk)!= 0){ 
		$rstksp = mysqli_fetch_array($rstk);
		$tkmodel = $rstksp['model_kanban'];
		if($tkmodel != ""){
			 $tk= $rstksp['matching_ticket_no'] ;
			$qty= $rstksp['tag_qty'] ;
			 $qidm= $rstksp['id_model'] ;
			 $qstd_qty= $rstksp['std_qty'] ;
			$bsi_line = $rstksp['bsi_line_id'] ;
			 $lastst = $rstksp['last_station'] ;
			if (($bsi_line == '') && ($lastst == '1') ){
				$resonse = $tk."--&&--".$qty."--&&--".$qidm."--&&--".$qstd_qty."--&&--"."NG";
				echo  $resonse;
			}else{
				$resonse = $tk."--&&--".$qty."--&&--".$qidm."--&&--".$qstd_qty."--&&--"."OK";
				echo  $resonse;
			}
			
			
			
			
			
			}else{
				echo "No";
				// echo $mxsrl ;
			}//if($gserial-$rscht['mxtag']==1){

		
}else{
	 echo "No";
	 // echo $sqlg;
	}
 }//  if(!empty($_GET["code"]) && $_GET["code"]<>"undefined"){


?>