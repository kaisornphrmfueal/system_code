<?php
//include('../includes/configure.php');
require_once '../includes/configure_host.php';

if (!empty($_GET["qctag"]) && $_GET["qctag"] != "undefined") {

	$ptagn = mysqli_real_escape_string($con, $_GET['qctag']);
	$pgmodel = mysqli_real_escape_string($con, $_GET['tsmodel']);

	$sqlg = "SELECT a.id_model
			FROM " . DB_DATABASE1 . ".fgt_model a
			LEFT JOIN " . DB_DATABASE1 . ".fgt_srv_tag b ON a.id_model = b.id_model
			WHERE b.tag_no = '$ptagn'
			AND a.tag_model_no = '$pgmodel'
			AND status_fg_reprint = '0'";

	$result = mysqli_query($con, $sqlg);

	if ($result && mysqli_num_rows($result) != 0) {
		$row = mysqli_fetch_assoc($result);
		echo $row['id_model'];
	} else {
		echo "No";
	}
}
?>
