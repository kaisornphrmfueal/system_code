<?php require('../includes/template_top_fg.php'); ?>


<div class="body_resize"> 

<?php 
	if(!empty($_GET['id']) ){
		 require(base64_decode($_GET['id']).".php"); 
	}else{
		 gotopage("index_fg.php?id=".base64_encode('fg_station')." "); // fgprint
	}

?>
</div>

<?php require('../includes/template_bottom.php'); ?>