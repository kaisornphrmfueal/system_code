<?php
//include('../includes/configure.php');
require_once '../includes/configure_host.php';
if(!empty($_GET["tconv"]) && $_GET["tconv"]<>"undefined"){
	
	$gtconv=$_GET["tconv"];
	$gmodelsr=$_GET["modelsr"];
	$gmodel = substr($gmodelsr,0,15);
	$gserial=substr($gmodelsr,16,8);
	//a.tag_no,a.tag_qty,a.item_status,b.id_fg_tag_conversion, 
		  $sqlg="SELECT MIN(c.id_conversion_serial),c.serial_label,d.tag_model_no
          FROM ".DB_DATABASE1.".fgt_split_fg_tag  a 
          LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion b ON a.id_fg_split =b.id_fg_split
          LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial c ON b.id_fg_tag_conversion=c.id_fg_tag_conversion
		  LEFT JOIN ".DB_DATABASE1.".fgt_model d ON a.id_model =d.id_model
          WHERE b.id_fg_tag_conversion ='$gtconv' AND gms_label_ref IS  NULL  ";
		  $resultg = mysqli_query($con, $sqlg);

if(mysqli_num_rows($resultg)<>0){
		$rstg = mysqli_fetch_array($resultg);
		$serial = $rstg['serial_label'];
		$tagmodel = $rstg['tag_model_no'];
		if($tagmodel != $gmodel ){
			 echo "No";
			}elseif ($serial == $gserial) {
				echo "1";
			}else{
				echo "Wrong";
				// echo $mxsrl ;
			}//if($gserial-$rscht['mxtag']==1){

		
}else{
	 echo "Non";
	 // echo $sqlg;
	}
 }//  if(!empty($_GET["code"]) && $_GET["code"]<>"undefined"){


?>