<?php
	// Ccheck Model, Line, Bartender 
	if (!empty($_GET['idup']) && $_GET['idup'] == "Model") {
		$gtype = $_GET['idup'];
		$timenow = date('Y-m-d H:i:s');
		$sqlmxs = "SELECT MAX(id_update) AS mxsidrvup FROM " . DB_DATABASE1 . ".fgt_srv_update WHERE type_data = '$gtype' AND date_insert < '$timenow'";
		$qrmxs = mysqli_query($con, $sqlmxs);
		$rsmxs = mysqli_fetch_array($qrmxs);
		$mxsvup = $rsmxs['mxsidrvup'];
		$sqlup = "SELECT b.* 
			FROM (
				SELECT a.id_update,a.id_action,a.action_name,a.path,a.version_up,a.emp_insert, a.type_data,
				CASE a.fname WHEN '' THEN '-' ELSE a.fname END AS nfname,
				DATE_FORMAT(a.date_insert, '%d-%b-%Y %H:%i') AS date_modify 
				FROM " . DB_DATABASE1 . ".fgt_srv_update a 
				WHERE a.type_data = '$gtype' 
				AND a.id_update > (SELECT IFNULL(MAX(last_id_srvupdate),0) AS mxup FROM " . DB_DATABASE1 . ".fgt_update_master_forlocal   
								  WHERE type_data = '$gtype' )
				AND a.date_insert < '$timenow'
				AND fname <> '' 
				AND fname <> 'fgTag' 
				ORDER BY a.id_update DESC 
			)b
			GROUP BY b.id_action,b.path ";
		$qrup = mysqli_query($con, $sqlup);
		while ($rsup = mysqli_fetch_array($qrup)) {
			$sqlq = "SELECT id_model,model_code,tag_model_no,label_model_no,model_name,std_qty,customer,
							customer_part_no,customer_part_name,model_picture,status_tag_printing
							FROM " . DB_DATABASE1 . ".fgt_model WHERE id_model = '" . $rsup['id_action'] . "'";
			$qrq = mysqli_query($con, $sqlq);
			if (mysqli_num_rows($qrq) <> 0) {
				$rsq = mysqli_fetch_array($qrq);
				$upmodelid = $rsq['id_model'];
				$modelpic = $rsq['model_picture'];
				$actionn = $rsup['action_name'];
				$srvfile = "http://10.164.213.91/" . DIR_PAGE . DIR_VIEWS . DIR_UPLOAD . DIR_MPIC . $modelpic;
				if (copy($srvfile, DIR_UPLOAD . DIR_MPIC . $modelpic)) {
				} else {
					alert("can't copy file");
				}
			}
			log_hist($user_login, "FG Download", $upmodelid, "Picture", "");
		}
		$sqlupl = "INSERT INTO " . DB_DATABASE1 . ".fgt_update_master_forlocal SET last_id_srvupdate='$mxsvup', 
				type_data='$gtype', user_update='$user_login', date_update='$timenow'";
		mysqli_query($con, $sqlupl);
		gotopage("index_fg.php?id=" . base64_encode('fg_download'));
	}

	if (!empty($_GET['idup']) && $_GET['idup'] == "Bartender") {
		$gtype = $_GET['idup'];
		$timenow = date('Y-m-d H:i:s');
		if (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
			$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
		} else {
			$ip = $_SERVER["REMOTE_ADDR"];
		}
		$sqlmxs = "SELECT MAX(id_update) AS mxsidrvup FROM " . DB_DATABASE4 . ".fgt_srv_update WHERE type_data = '$gtype' AND date_insert < '$timenow'";
		$qrmxs = mysqli_query($con2, $sqlmxs);
		$rsmxs = mysqli_fetch_array($qrmxs);
		$mxsvup = $rsmxs['mxsidrvup'];
		$sqlup = "SELECT b.* 
			FROM (
				SELECT a.id_update,a.id_action,a.action_name,a.path,a.version_up,a.emp_insert, a.type_data,
				CASE a.fname WHEN '' THEN '-' ELSE a.fname END AS nfname,
				DATE_FORMAT(a.date_insert, '%d-%b-%Y %H:%i') AS date_modify 
				FROM " . DB_DATABASE1 . ".fgt_srv_update a 
				WHERE a.type_data = '$gtype' 
				AND a.id_update > (SELECT IFNULL(MAX(last_id_srvupdate),0) AS mxup FROM " . DB_DATABASE1 . ".fgt_update_master_forlocal   
								   WHERE type_data = '$gtype')
				AND a.date_insert < '$timenow'
				AND fname <> '' 
				AND fname <> 'fgTag' 
				ORDER BY a.id_update DESC 
			)b
			GROUP BY b.id_action,b.path,nfname ";
		$qrup = mysqli_query($con, $sqlup);
		while ($rsup = mysqli_fetch_array($qrup)) {
			$btwname = $rsup['nfname'] . ".btw";
			$newbtnname = $btwname . date('YmdHis') . ".btw";
			copy("../" . DIR_UPLOAD . DIR_BTW . $btwname, "../" . DIR_UPLOAD . DIR_BTW . "backup_file/$newbtnname");
			$srvfile = HTTP_SERVER_TRUE . DIR_PAGE . DIR_VIEWS . DIR_UPLOAD . DIR_BTW . $btwname;
			copy($srvfile, DIR_UPLOAD . DIR_BTW . "$btwname");
		}
		$sqlupl = "INSERT INTO " . DB_DATABASE1 . ".fgt_update_master_forlocal SET last_id_srvupdate='$mxsvup', 
				type_data='$gtype', user_update='$user_login', date_update='$timenow'";
		mysqli_query($con, $sqlupl);
		gotopage("index_fg.php?id=" . base64_encode('fg_download'));
	}
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<div class="rightPane" align="center">
<?php
	$arr = array("Model");
	$i = 0;
?>
<form id="form1" name="form1" method="post" action="">
<table width="780px" border="1" bordercolor="#CC9966" class="table01">
	<tr>
	  <th height="29" colspan="7">
		<div align="center">Manage Customer Data</div> </th>
	  </tr>
	<tr>
	  <th width="10%" height="28">Type data</th>
	  <th width="8%">Update</th>
	  <th width="12%">Action Name </th>
	  <th width="13%">Last Version</th>
	  <th width="22%">File </th>
	  <th width="20%">Date modified</th>
	  <th width="15%">User modified</th>
	</tr>
	<?php while ($i < 1) {
		$rstype = $arr[$i];
		$qp = "SELECT b.* 
			FROM (
				 SELECT a.id_update,a.id_action,a.action_name,a.path,a.version_up,a.emp_insert, a.type_data, 
				CASE a.fname WHEN '' THEN '-' ELSE a.fname END AS nfname,
				DATE_FORMAT(a.date_insert, '%d-%b-%Y %H:%i') AS date_modify,b.model_name
				FROM " . DB_DATABASE1 . ".fgt_srv_update a 
				LEFT JOIN  " . DB_DATABASE1 . ".fgt_model b ON a.id_action=b.id_model 
				WHERE a.type_data = '$rstype' 
				AND a.id_update > (SELECT IFNULL(MAX(last_id_srvupdate),0) AS mxup FROM " . DB_DATABASE1 . ".fgt_update_master_forlocal   
								  WHERE type_data = '$rstype' )
				AND fname <> '' 
				AND fname <> 'fgTag' 
				ORDER BY a.id_update DESC 
			)b
			GROUP BY b.id_action,b.path
			ORDER BY b.date_modify DESC ";
		$qrp = mysqli_query($con, $qp);
		$np = mysqli_num_rows($qrp);
		if ($np <> 0) {
	?>
	<tr <?php $v = 0; $v = $v + 1; echo icolor($v); ?> onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" align="center">
		<td height="28" <?php if ($np > 1) { $nps = $np + 1; echo "rowspan='" . $nps . "'"; } ?> ><strong> <?=$rstype?>
		</strong></td>
		<td <?php if ($np > 1) { $nps = $np + 1; echo "rowspan='" . $nps . "'"; } ?>>
		<a href="index_fg.php?id=<?=base64_encode('fg_download')?>&idup=<?=$rstype?>" onclick="return confirm('Do you need to update Master data?');" >
			<img src="../images/update2.png" /></a>
		</td>
		<?php
			if ($np == 1) {
				while ($rsp = mysqli_fetch_array($qrp)) {
		?>
			<td align="center"><?php echo $rsp['action_name'] . "  " . $rsp['model_name']; ?></td>
			<td align="center"><?=$rsp['version_up']?></td>
			<td align="center"><img src="<?=HTTP_SERVER_TRUE . DIR_PAGE . DIR_VIEWS . DIR_UPLOAD . DIR_MPIC . $rsp['nfname']?>" /> </td>
			<td align="center"><?=$rsp['date_modify']?></td>
			<td align="center"><?=$rsp['emp_insert']?></td>
		<?php
				}
			}
		?>
	</tr>
	<?php
			if ($np == 1) {
				while ($rsp = mysqli_fetch_array($qrp)) {
				}
			}
		?>
	</tr>
	<?php
			if ($np > 1) {
				while ($rsp = mysqli_fetch_array($qrp)) {
	?>
		<tr <?php $v = 0; $v = $v + 1; echo icolor($v); ?> onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;">
			<td height="26" align="center"><?php echo $rsp['action_name'] . "  " . $rsp['model_name']; ?></td>
			<td align="center"><?=$rsp['version_up']?></td>
			<td align="center"><img src="<?=HTTP_SERVER_TRUE . DIR_PAGE . DIR_VIEWS . DIR_UPLOAD . DIR_MPIC . $rsp['nfname']?>" /> </td>
			<td align="center"><?=$rsp['date_modify']?></td>
			<td align="center"><?=$rsp['emp_insert']?></td>
		</tr>
	<?php
				}
			}
		}
		$i++;
	}
	?>
</table>
</form>
<br/>
<input type="button" value="Refresh Page" onClick="window.location.reload()">
</div>
