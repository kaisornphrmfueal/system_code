<?php
include "../includes/configure.php";
function printSPTag($tagn, $station) {

		$serverPath = DIR_SEVER.$station.'\\fgtag.txt';
		$sourceFile = "../views/".DIR_UPLOAD . DIR_BTW . "fgtag.txt";
		$destFile = $serverPath . "fgtag.txt";
		$cmdSource = $serverPath . "cmd.txt";
		$cmdDest = $serverPath . "cmds/cmd.txt";

		// $flgCopyDT = copy($sourceFile, $serverPath);
		// $flgCopy1 = copy($cmdSource, $cmdDest);

        $flgFGTAG = copy("../views/uploads/btw/fgtag.txt", DIR_SEVER.$station.'\\fgtag.txt');
		$flgCopy1 = copy("../views/uploads/btw/cmd.txt", DIR_SEVER.$station.'/cmdo/cmd.txt');

        
		// copy("uploads/btw/cmd.txt", "uploads/btw/cmds/cmd.txt");
	}


   echo  $test = printSPTag('12345', '45');