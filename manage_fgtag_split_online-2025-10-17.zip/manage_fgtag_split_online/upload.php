<html>
<head>
<title>Test Copy File</title>
</head>
<body>
<?php

$flgCopy = copy("thaicreate.txt","thaicreate-bak.txt");
if($flgCopy)
{
	echo "File copy";
}
else
{
	echo "File can not copy";
}

?>
</body>
</html>