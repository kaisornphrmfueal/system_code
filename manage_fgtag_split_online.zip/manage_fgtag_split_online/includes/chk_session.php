<?php

$user_ip = session_id();
$user_login = isset($_SESSION['user_login']) ? $_SESSION['user_login'] : '';
// $user_login = '2298';

if ($user_ip !== session_id() || empty($user_login)) {
	header("Refresh: 1; URL=" . HTTP_SERVER . SSO);
	exit();
}
?>
