	<div class="menu">
		<ul id="nav" class="dropdown dropdown-horizontal">
    
            <li><a href="index_bsi.php?id=<?=base64_encode('bsi_scan')?>">BSI Scaning</a></li>
             <li><a href="index_bsi.php?id=<?=base64_encode('bsi_report')?>">BSI Report</a></li>

         
		</ul>
	</div>
    
    
    