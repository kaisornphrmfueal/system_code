	<div class="menu">
		<ul id="nav" class="dropdown dropdown-horizontal">
     		 <li><a href="index_fg.php?id=<?=base64_encode('fgprint')?>">Supplier Tag Printing</a></li>
			<li><a href="index_fg.php?id=<?=base64_encode('fgprint_fg_tag')?>">Split F/G Transfer Tag</a></li>
			<li><a href="index_fg.php?id=<?=base64_encode('fg_tag_combine_tag')?>">Combine F/G Transfer Tag</a></li>
          <!--  <li><a href="index_fg.php?id=<?=base64_encode('test')?>">test</a></li>-->
          
				 <li><span class="dir">Report</span>
				<ul>
				 <li><a href="index_fg.php?id=<?=base64_encode('fgreport')?>">Supplier Tag Printing Report</a></li>
				 <li><a href="index_fg.php?id=<?=base64_encode('fgsplitreport')?>">F/G Transfer Tag Spliting Report</a></li>
					<li><a href="index_fg.php?id=<?=base64_encode('fgcombinereport')?>">F/G Transfer Tag Combine Report</a></li>
					
			   </ul>
		 	</li>
			
		</ul>
	</div>
    
    
    