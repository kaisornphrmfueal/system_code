	<div class="menu">
		<ul id="nav" class="dropdown dropdown-horizontal">
     		<li><a href="index.php?id=<?=base64_encode('manage')?>">Manage Model Data</a></li>
            <li><a href="index.php?id=<?=base64_encode('report')?>">Tag Report</a></li>
          <!--  	<li><span class="dir">Supplier Tag</span>
				<ul>
					  <li><a href="index.php?id=<?=base64_encode('fgprint')?>">Supplier Tag Printing</a></li>
                      <li><a href="index.php?id=<?=base64_encode('fgreport')?>">Supplier Tag Printing Report</a></li>
			   </ul>
		 	</li> ---!-->
            	<li><span class="dir">Manage Master for Client</span>
				<ul>
					  <li><a href="index.php?id=<?=base64_encode('srvupfile')?>">Update btw. file to client</a></li>
                      <li><a href="index.php?id=<?=base64_encode('srvupdate_master_data')?>">History update Master data </a></li>
                      <li><a href="index.php?id=<?=base64_encode('client_download_report')?>">History client downloading</a></li>
			   </ul>
		 	</li>
           <!-- <li><a href="index.php?id=<?=base64_encode('line_upload_tag_report')?>">Tag upload report</a></li> ---!-->
           <li><a href="index.php?id=<?=base64_encode('manage_work_process')?>">Work Process</a></li>
           <li><a href="index.php?id=<?=base64_encode('operator')?>">Operator</a></li>
		</ul>
	</div>
    
    
    