﻿# MySQL-Front 5.0  (Build 1.96)



# Host: 10.164.214.49    Database: prod_fg_tag
# ------------------------------------------------------
# Server version 5.1.41

USE `prod_fg_tag`;

#
# Table structure for table fgt_log_history
#

CREATE TABLE `fgt_log_history` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action_name` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `table_name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `table_id_action` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sql_code` text COLLATE utf8_unicode_ci,
  `record_date` datetime DEFAULT NULL,
  `ip_address` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mac_address` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=549 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# Dumping data for table fgt_log_history
#

INSERT INTO `fgt_log_history` VALUES (1,'1','Insert','fgt_serial','BN600326','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000000\', \r\n\t\t\t\t\t\tmodel_scan_label=\'139001-81200101\', serial_scan_label=\'BN600326\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-26 10:39:18\'','2016-07-26 10:39:18','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (2,'1','Insert','fgt_serial','BN600321','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000000\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'139001-81200101\', serial_scan_label=\'BN600321\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 10:39:33\'','2016-07-26 10:39:33','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (3,'1','Insert','fgt_serial','BN600327','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000000\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'139001-81200101\', serial_scan_label=\'BN600327\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 10:39:37\'','2016-07-26 10:39:37','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (4,'1','Insert','fgt_serial','BN600320','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000000\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'139001-81200101\', serial_scan_label=\'BN600320\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-07-26 10:40:08\'','2016-07-26 10:40:08','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (5,'1','Print Tag','fgt_tag','010000000','','2016-07-26 10:40:08','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (6,'1','Insert','fgt_serial','BN601310','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\tmodel_scan_label=\'\', serial_scan_label=\'BN601310\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-26 11:21:24\'','2016-07-26 11:21:24','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (7,'1','Insert','fgt_serial','BN601310','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'\', serial_scan_label=\'BN601310\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 11:21:26\'','2016-07-26 11:21:26','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (8,'1','Insert','fgt_serial','BN600331','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600331\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-26 13:15:28\'','2016-07-26 13:15:28','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (9,'1','Insert','fgt_serial','BN600332','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600332\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:15:49\'','2016-07-26 13:15:49','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (10,'1','Insert','fgt_serial','BN600333','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600333\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:15:54\'','2016-07-26 13:15:54','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (11,'1','Insert','fgt_serial','BN600334','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600334\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:15:57\'','2016-07-26 13:15:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (12,'1','Insert','fgt_serial','BN600338','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600338\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:18:02\'','2016-07-26 13:18:02','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (13,'1','Print Tag','fgt_tag','010000002','','2016-07-26 13:18:02','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (14,'1','Insert','fgt_serial','BN600331','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000000\', \r\n\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600331\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-26 13:19:18\'','2016-07-26 13:19:18','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (15,'1','Insert','fgt_serial','BN600332','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000000\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600332\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:19:19\'','2016-07-26 13:19:19','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (16,'1','Insert','fgt_serial','BN600336','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000000\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600336\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:19:21\'','2016-07-26 13:19:21','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (17,'1','Insert','fgt_serial','BN600331','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000001\', \r\n\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600331\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-26 13:22:51\'','2016-07-26 13:22:51','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (18,'1','Insert','fgt_serial','BN600332','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000001\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600332\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:22:53\'','2016-07-26 13:22:53','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (19,'1','Insert','fgt_serial','BN600333','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000001\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600333\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:22:54\'','2016-07-26 13:22:54','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (20,'1','Insert','fgt_serial','BN600334','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000001\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600334\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:22:58\'','2016-07-26 13:22:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (21,'1','Insert','fgt_serial','BN600335','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000001\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600335\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:22:59\'','2016-07-26 13:22:59','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (22,'1','Print Tag','fgt_tag','010000001','','2016-07-26 13:22:59','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (23,'1','Insert','fgt_serial','BN700017','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700017\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-26 13:29:30\'','2016-07-26 13:29:30','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (24,'1','Insert','fgt_serial','BN700018','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700018\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:29:34\'','2016-07-26 13:29:34','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (25,'1','Insert','fgt_serial','BN700019','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700019\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:29:41\'','2016-07-26 13:29:41','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (26,'1','Insert','fgt_serial','BN700020','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700020\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:29:43\'','2016-07-26 13:29:43','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (27,'1','Insert','fgt_serial','BN700021','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700021\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:29:45\'','2016-07-26 13:29:45','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (28,'1','Insert','fgt_serial','BN700022','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700022\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:29:51\'','2016-07-26 13:29:51','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (29,'1','Print Tag','fgt_tag','010000002','','2016-07-26 13:29:51','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (30,'1','Insert','fgt_serial','BN601311','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000003\', \r\n\t\t\t\t\t\tmodel_scan_label=\'\', serial_scan_label=\'BN601311\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-26 13:33:39\'','2016-07-26 13:33:39','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (31,'1','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000003\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:33:41\'','2016-07-26 13:33:41','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (32,'1','Insert','fgt_serial','BN601313','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000003\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'\', serial_scan_label=\'BN601313\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:33:42\'','2016-07-26 13:33:42','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (33,'1','Insert','fgt_serial','BN601314','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000003\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'\', serial_scan_label=\'BN601314\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-07-26 13:33:46\'','2016-07-26 13:33:46','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (34,'1','Print Tag','fgt_tag','010000003','','2016-07-26 13:33:46','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (35,'1','Insert','fgt_serial','BN600377','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000004\', \r\n\t\t\t\t\t\tmodel_scan_label=\'139000-67300101\', serial_scan_label=\'BN600377\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-26 14:01:54\'','2016-07-26 14:01:54','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (36,'1','Insert','fgt_serial','BN600378','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000004\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'139000-67300101\', serial_scan_label=\'BN600378\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 14:01:55\'','2016-07-26 14:01:55','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (37,'1','Insert','fgt_serial','BN600379','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000004\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'139000-67300101\', serial_scan_label=\'BN600379\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-26 14:01:57\'','2016-07-26 14:01:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (38,'1','Insert','fgt_serial','BN600380','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000004\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'139000-67300101\', serial_scan_label=\'BN600380\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-07-26 14:02:00\'','2016-07-26 14:02:00','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (39,'1','Print Tag','fgt_tag','010000004','','2016-07-26 14:02:00','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (40,'1','Insert','fgt_serial','BN700021','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000005\', \r\n\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700021\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-26 14:59:52\'','2016-07-26 14:59:52','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (41,'','Waiting','fgt_tag','010000005','','2016-07-27 14:22:20','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (42,'','Waiting','fgt_tag','010000005','','2016-07-27 14:22:33','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (43,'','Waiting','fgt_tag','010000005','','2016-07-27 14:22:44','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (44,'','Waiting','fgt_tag','010000005','','2016-07-27 14:23:02','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (45,'','Waiting','fgt_tag','010000005','','2016-07-27 14:23:22','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (46,'','Waiting','fgt_tag','010000005','','2016-07-27 14:24:00','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (47,'','Waiting','fgt_tag','010000005','','2016-07-27 14:26:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (48,'','Waiting','fgt_tag','010000005','','2016-07-27 14:26:50','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (49,'1','Insert','fgt_serial','BN700022','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000005\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700022\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-27 15:00:12\'','2016-07-27 15:00:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (50,'1','Waiting','fgt_tag','010000005','','2016-07-27 15:00:15','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (51,'1','Insert','fgt_serial','BN700017','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000006\', \r\n\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700017\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-27 15:10:59\'','2016-07-27 15:10:59','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (52,'1','Insert','fgt_serial','BN700018','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000006\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700018\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-27 15:11:01\'','2016-07-27 15:11:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (53,'1','Insert','fgt_serial','BN700019','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000006\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700019\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-27 15:11:04\'','2016-07-27 15:11:04','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (54,'1','Insert','fgt_serial','BN700020','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000006\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700020\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-27 15:11:08\'','2016-07-27 15:11:08','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (55,'1','Insert','fgt_serial','BN700018','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000006\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700018\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-27 15:11:10\'','2016-07-27 15:11:10','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (56,'1','Insert','fgt_serial','BN700021','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000006\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700021\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-07-27 15:11:13\'','2016-07-27 15:11:13','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (57,'1','Print Tag','fgt_tag','010000006','','2016-07-27 15:11:13','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (58,'1','Insert','fgt_serial','BN600331','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000007\', \r\n\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600331\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-27 15:12:23\'','2016-07-27 15:12:23','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (59,'1','Insert','fgt_serial','BN600332','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000007\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600332\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-27 15:12:25\'','2016-07-27 15:12:25','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (60,'1','Insert','fgt_serial','BN600333','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000007\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'123001-4870C101\', serial_scan_label=\'BN600333\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-27 15:12:26\'','2016-07-27 15:12:26','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (61,'1','Print Tag','fgt_tag','7','','2016-07-27 15:44:46','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (62,'1','Insert','fgt_serial','BN600377','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000008\', \r\n\t\t\t\t\t\tmodel_scan_label=\'139000-67300101\', serial_scan_label=\'BN600377\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-27 16:06:13\'','2016-07-27 16:06:13','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (63,'1','Insert','fgt_serial','BN600378','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000008\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'139000-67300101\', serial_scan_label=\'BN600378\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-27 16:06:15\'','2016-07-27 16:06:15','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (64,'1','Insert','fgt_serial','BN600379','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000008\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'139000-67300101\', serial_scan_label=\'BN600379\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-27 16:06:16\'','2016-07-27 16:06:16','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (65,'2','Insert','fgt_serial','BN601311','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\tmodel_scan_label=\'\', serial_scan_label=\'BN601311\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-28 08:19:31\'','2016-07-28 08:19:31','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (66,'2','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-28 08:19:32\'','2016-07-28 08:19:33','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (67,'2','Insert','fgt_serial','BN601311','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601311\', \r\n\t\t\t\t\t\tdate_scan=\'2016-07-28 08:22:09\'','2016-07-28 08:22:09','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (68,'2','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-28 08:22:11\'','2016-07-28 08:22:11','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (69,'2','Insert','fgt_serial','BN601313','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601313\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-28 08:22:13\'','2016-07-28 08:22:13','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (70,'2','Insert','fgt_serial','BN601314','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601314\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-28 08:22:14\'','2016-07-28 08:22:14','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (71,'2','Insert','fgt_serial','BN601315','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601315\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-28 08:22:15\'','2016-07-28 08:22:15','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (72,'2','Insert','fgt_serial','BN601316','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601316\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-28 08:22:18\'','2016-07-28 08:22:18','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (73,'2','Insert','fgt_serial','BN601317','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601317\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-28 08:22:19\'','2016-07-28 08:22:19','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (74,'2','Insert','fgt_serial','BN601318','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601318\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-28 08:22:21\'','2016-07-28 08:22:21','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (75,'2','Insert','fgt_serial','BN601319','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601319\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-28 08:22:21\'','2016-07-28 08:22:21','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (76,'2','Insert','fgt_serial','BN601319','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601319\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-07-28 08:22:29\'','2016-07-28 08:22:29','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (77,'2','Print Tag','fgt_tag','020000009','','2016-07-28 08:22:29','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (78,'2','Insert','fgt_serial','BN601319','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000009\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601319\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-07-28 09:02:42\'','2016-07-28 09:02:42','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (79,'2','Print Tag','fgt_tag','020000009','','2016-07-28 09:02:42','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (80,'1','Insert','fgt_serial','BN700023','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000005\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700023\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-28 09:42:51\'','2016-07-28 09:42:51','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (81,'1','Insert','fgt_serial','BN700024','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000005\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700024\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-28 09:42:54\'','2016-07-28 09:42:54','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (82,'1','Insert','fgt_serial','BN700025','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000005\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700025\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-07-28 09:42:56\'','2016-07-28 09:42:56','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (83,'1','Insert','fgt_serial','BN700026','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000005\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700026\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-07-28 09:42:58\'','2016-07-28 09:42:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (84,'1','Print Tag','fgt_tag','010000005','','2016-07-28 09:42:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (85,'5','Insert','fgt_serial','BN601311','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000010\', \r\n\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601311\', \r\n\t\t\t\t\t\tdate_scan=\'2016-08-01 09:18:46\'','2016-08-01 09:18:46','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (86,'5','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000010\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-01 09:18:47\'','2016-08-01 09:18:47','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (87,'5','Insert','fgt_serial','BN601313','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000010\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601313\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-01 09:18:49\'','2016-08-01 09:18:49','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (88,'5','Insert','fgt_serial','BN601314','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000010\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601314\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-01 09:18:52\'','2016-08-01 09:18:52','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (89,'5','Waiting','fgt_tag','050000010','','2016-08-01 09:19:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (90,'5','Waiting','fgt_tag','050000010','','2016-08-01 11:20:09','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (91,'5','Insert','fgt_serial','BN700002','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700002\', \r\n\t\t\t\t\t\tdate_scan=\'2016-08-01 11:23:44\'','2016-08-01 11:23:44','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (92,'5','Insert','fgt_serial','BN700006','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700006\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-01 11:23:48\'','2016-08-01 11:23:48','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (93,'5','Insert','fgt_serial','BN700004','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700004\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-01 11:24:19\'','2016-08-01 11:24:19','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (94,'5','Insert','fgt_serial','BN700005','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700005\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-01 11:24:23\'','2016-08-01 11:24:23','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (95,'5','Waiting','fgt_tag','050000011','','2016-08-01 11:25:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (96,'5','Insert','fgt_serial','BN701529','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000012\', \r\n\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701529\', \r\n\t\t\t\t\t\tdate_scan=\'2016-08-01 11:25:36\'','2016-08-01 11:25:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (97,'5','Insert','fgt_serial','BN701530','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000012\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701530\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-08-01 11:25:38\'','2016-08-01 11:25:38','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (98,'5','Print Tag','fgt_tag','050000012','','2016-08-01 11:25:38','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (99,'5','Print Tag','fgt_tag','050000010','','2016-08-08 16:30:48','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (100,'5','Insert','fgt_serial','BN601315','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000010\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601315\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-08 16:33:10\'','2016-08-08 16:33:10','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (101,'5','Insert','fgt_serial','BN601316','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000010\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601316\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-08-08 16:33:18\'','2016-08-08 16:33:18','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (102,'5','Insert','fgt_serial','BN700003','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700003\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-17 16:07:50\'','2016-08-17 16:07:50','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (103,'5','Insert','fgt_serial','BN700007','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700007\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-17 16:07:57\'','2016-08-17 16:07:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (104,'5','Insert','fgt_serial','BN700008','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700008\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-17 16:07:59\'','2016-08-17 16:07:59','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (105,'5','Insert','fgt_serial','BN700012','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700012\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-17 16:08:06\'','2016-08-17 16:08:06','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (106,'5','Insert','fgt_serial','BN700013','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700013\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-17 16:08:07\'','2016-08-17 16:08:07','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (107,'5','Insert','fgt_serial','BN700009','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700009\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-17 16:08:58\'','2016-08-17 16:08:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (108,'5','Insert','fgt_serial','BN700013','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700013\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-17 16:08:59\'','2016-08-17 16:08:59','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (109,'5','Insert','fgt_serial','BN700011','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700011\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-08-17 16:09:01\'','2016-08-17 16:09:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (110,'5','Waiting','fgt_tag','050000011','','2016-08-17 16:18:04','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (111,'5','Waiting','fgt_tag','050000011','','2016-08-17 16:18:18','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (112,'5','Waiting','fgt_tag','050000012','','2016-08-17 16:18:55','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (113,'5','Insert','fgt_serial','BN700010','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700010\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-17 16:20:01\'','2016-08-17 16:20:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (114,'5','Insert','fgt_serial','BN700011','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700011\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-08-17 16:20:04\'','2016-08-17 16:20:04','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (115,'5','Insert','fgt_serial','BN700011','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700011\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-08-17 16:22:16\'','2016-08-17 16:22:16','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (116,'5','Print Tag','fgt_tag','050000011','','2016-08-17 16:22:16','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (117,'5','Insert','fgt_serial','BN601310','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000011\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601310\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-08-17 16:41:39\'','2016-08-17 16:41:39','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (118,'5','Print Tag','fgt_tag','050000011','','2016-08-17 16:41:39','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (119,'4','Insert','fgt_serial','BN700017','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000013\', \r\n\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700017\', \r\n\t\t\t\t\t\tdate_scan=\'2016-08-18 13:40:14\'','2016-08-18 13:40:14','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (120,'4','Insert','fgt_serial','BN700018','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000013\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700018\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-18 13:40:17\'','2016-08-18 13:40:17','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (121,'4','Insert','fgt_serial','BN700019','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000013\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700019\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-18 13:40:19\'','2016-08-18 13:40:19','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (122,'4','Insert','fgt_serial','BN700017','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000013\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700017\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-18 13:40:21\'','2016-08-18 13:40:21','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (123,'4','Insert','fgt_serial','BN700020','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000013\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700020\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-18 13:40:48\'','2016-08-18 13:40:48','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (124,'4','Insert','fgt_serial','BN700021','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000013\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700021\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-18 13:40:52\'','2016-08-18 13:40:52','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (125,'4','Insert','fgt_serial','BN700022','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000013\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700022\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-08-18 13:40:54\'','2016-08-18 13:40:54','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (126,'4','Print Tag','fgt_tag','040000013','','2016-08-18 13:40:54','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (127,'1972','Update','fgt_model','15',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'48\', \r\n\t\t\t\t\ttag_model_no=\'139000-67300151\', label_model_no=\'123001-4870C101\', model_name=\'T-426TW\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'TOYOTA \', customer_part_no=\'86120-0KC40\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160819145319.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 14:53:20\'\r\n\t\t\t\t\tWHERE id_model=\'15\'','2016-08-19 14:53:20','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (128,'1972','Update','fgt_model','49',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'1\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C151\', label_model_no=\'138000-6350F101\', model_name=\'T-245VN\', \r\n\t\t\t\t\tstd_qty=\'6\', customer=\'ISUZU\', customer_part_no=\'T-245VN\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160819145358.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 14:53:58\'\r\n\t\t\t\t\tWHERE id_model=\'49\'','2016-08-19 14:53:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (129,'1972','Update','fgt_model','20',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'40\', \r\n\t\t\t\t\ttag_model_no=\'123000-72500103\', label_model_no=\'123000-72500103\', model_name=\'T-422MY\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'GM\', customer_part_no=\'PC600-0D00B\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160819145559.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 14:55:59\'\r\n\t\t\t\t\tWHERE id_model=\'20\'','2016-08-19 14:55:59','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (130,'1972','Update','fgt_model','16',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'47\', \r\n\t\t\t\t\ttag_model_no=\'139000-67300101\', label_model_no=\'139000-67300101\', model_name=\'T-425TH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'GM\', customer_part_no=\'86120-0KD20\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160819145612.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 14:56:12\'\r\n\t\t\t\t\tWHERE id_model=\'16\'','2016-08-19 14:56:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (131,'1972','Update','fgt_model','26',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'14\', \r\n\t\t\t\t\ttag_model_no=\'123001-6090C152\', label_model_no=\'138000-6370E101\', model_name=\'T-250ID\', \r\n\t\t\t\t\tstd_qty=\'10\', customer=\'GM\', customer_part_no=\'898171 4812\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160819145640.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 14:56:40\'\r\n\t\t\t\t\tWHERE id_model=\'26\'','2016-08-19 14:56:40','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (132,'1972','Update','fgt_model','2',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'32\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B151\', label_model_no=\'123000-5940B101\', model_name=\'T-258MY\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'TOYOTA \', customer_part_no=\'86120-0K661\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160819145655.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 14:56:55\'\r\n\t\t\t\t\tWHERE id_model=\'2\'','2016-08-19 14:56:55','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (133,'1972','Update','fgt_model','15',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'48\', \r\n\t\t\t\t\ttag_model_no=\'139000-67300151\', label_model_no=\'123001-4870C101\', model_name=\'T-426TW\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'TOYOTA \', customer_part_no=\'86120-0KC40\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160819152847.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 15:28:47\'\r\n\t\t\t\t\tWHERE id_model=\'15\'','2016-08-19 15:28:47','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (134,'1972','Update','fgt_model','49',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'1\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C151\', label_model_no=\'138000-6350F101\', model_name=\'T-245VN\', \r\n\t\t\t\t\tstd_qty=\'6\', customer=\'ISUZU\', customer_part_no=\'T-245VN\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160819152902.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 15:29:02\'\r\n\t\t\t\t\tWHERE id_model=\'49\'','2016-08-19 15:29:02','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (135,'1972','Update','fgt_model','20',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'40\', \r\n\t\t\t\t\ttag_model_no=\'123000-72500103\', label_model_no=\'123000-72500103\', model_name=\'T-422MY\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'GM\', customer_part_no=\'PC600-0D00B\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160819152922.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 15:29:23\'\r\n\t\t\t\t\tWHERE id_model=\'20\'','2016-08-19 15:29:23','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (136,'1972','Update','fgt_model','16',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'47\', \r\n\t\t\t\t\ttag_model_no=\'139000-67300101\', label_model_no=\'139000-67300101\', model_name=\'T-425TH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'GM\', customer_part_no=\'86120-0KD20\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160819152932.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 15:29:32\'\r\n\t\t\t\t\tWHERE id_model=\'16\'','2016-08-19 15:29:32','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (137,'1972','Update','fgt_model','49',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'1\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C151\', label_model_no=\'138000-6350F101\', model_name=\'T-245VN\', \r\n\t\t\t\t\tstd_qty=\'6\', customer=\'ISUZU\', customer_part_no=\'T-245VN\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160819152940.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 15:29:40\'\r\n\t\t\t\t\tWHERE id_model=\'49\'','2016-08-19 15:29:40','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (138,'1972','Update','fgt_model','27',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'13\', \r\n\t\t\t\t\ttag_model_no=\'123001-6090C151\', label_model_no=\'138000-6370E101\', model_name=\'T-249ID\', \r\n\t\t\t\t\tstd_qty=\'10\', customer=\'GM\', customer_part_no=\'898219 8443\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160819153005.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 15:30:05\'\r\n\t\t\t\t\tWHERE id_model=\'27\'','2016-08-19 15:30:05','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (139,'1972','Update','fgt_model','2',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'32\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B151\', label_model_no=\'123000-5940B101\', model_name=\'T-258MY\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'TOYOTA \', customer_part_no=\'86120-0K661\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160819153015.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-19 15:30:15\'\r\n\t\t\t\t\tWHERE id_model=\'2\'','2016-08-19 15:30:15','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (140,'2','Insert','fgt_serial','BN700017','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000014\', \r\n\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700017\', \r\n\t\t\t\t\t\tdate_scan=\'2016-08-19 14:33:56\'','2016-08-19 14:33:56','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (141,'2','Insert','fgt_serial','BN700018','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000014\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700018\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-19 14:33:58\'','2016-08-19 14:33:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (142,'2','Insert','fgt_serial','BN700019','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000014\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700019\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-19 14:33:59\'','2016-08-19 14:33:59','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (143,'2','Insert','fgt_serial','BN700020','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000014\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700020\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-19 14:34:01\'','2016-08-19 14:34:02','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (144,'2','Insert','fgt_serial','BN700021','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000014\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700021\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-08-19 14:34:03\'','2016-08-19 14:34:03','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (145,'2','Insert','fgt_serial','BN700022','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'020000014\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700022\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-08-19 14:34:04\'','2016-08-19 14:34:04','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (146,'2','Print Tag','fgt_tag','020000014','','2016-08-19 14:34:04','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (147,'1972','Update','fgt_model','25',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'12\', \r\n\t\t\t\t\ttag_model_no=\'123000-6090C101\', label_model_no=\'138000-6370E101\', model_name=\'T-241TH\', \r\n\t\t\t\t\tstd_qty=\'10\', customer=\'GM\', customer_part_no=\'898126 0813\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160822112721.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:27:21\'\r\n\t\t\t\t\tWHERE id_model=\'25\'','2016-08-22 11:27:21','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (148,'1972','Update','fgt_model','36',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'20\', \r\n\t\t\t\t\ttag_model_no=\'123000-6110B101\', label_model_no=\'123000-6110B101\', model_name=\'T-242TH\', \r\n\t\t\t\t\tstd_qty=\'16\', customer=\'ISUZU\', customer_part_no=\'898340 5000\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822112933.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:29:33\'\r\n\t\t\t\t\tWHERE id_model=\'36\'','2016-08-22 11:29:33','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (149,'1972','Update','fgt_model','4',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'37\', \r\n\t\t\t\t\ttag_model_no=\'123000-72500101\', label_model_no=\'123000-72500101\', model_name=\'T-361TH\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'TOYOTA \', customer_part_no=\'86120-0K821\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822113047.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:30:47\'\r\n\t\t\t\t\tWHERE id_model=\'4\'','2016-08-22 11:30:47','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (150,'1972','Update','fgt_model','19',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'38\', \r\n\t\t\t\t\ttag_model_no=\'123000-72500102\', label_model_no=\'123000-72500101\', model_name=\'T-388TH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'GM\', customer_part_no=\'PC600-00001\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160822113242.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:32:42\'\r\n\t\t\t\t\tWHERE id_model=\'19\'','2016-08-22 11:32:42','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (151,'1972','Update','fgt_model','18',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'39\', \r\n\t\t\t\t\ttag_model_no=\'123000-72500151\', label_model_no=\'123000-72500101\', model_name=\'T-423SG\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'GM\', customer_part_no=\'86120-0KD40\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160822113334.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:33:34\'\r\n\t\t\t\t\tWHERE id_model=\'18\'','2016-08-22 11:33:34','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (152,'1972','Update','fgt_model','22',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'41\', \r\n\t\t\t\t\ttag_model_no=\'123000-72500152\', label_model_no=\'123000-72500101\', model_name=\'T-389TH\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'GM\', customer_part_no=\'898052 9354\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160822113510.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:35:10\'\r\n\t\t\t\t\tWHERE id_model=\'22\'','2016-08-22 11:35:10','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (153,'1972','Update','fgt_model','21',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'42\', \r\n\t\t\t\t\ttag_model_no=\'123000-72700102\', label_model_no=\'123000-72700101\', model_name=\'T-427TH\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'GM\', customer_part_no=\'PC600-0D00H\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160822113632.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:36:32\'\r\n\t\t\t\t\tWHERE id_model=\'21\'','2016-08-22 11:36:32','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (154,'1972','Update','fgt_model','17',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'43\', \r\n\t\t\t\t\ttag_model_no=\'123000-72700151\', label_model_no=\'123000-72700101\', model_name=\'T-390TW\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'GM\', customer_part_no=\'86120-0KD30\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160822113802.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:38:02\'\r\n\t\t\t\t\tWHERE id_model=\'17\'','2016-08-22 11:38:02','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (155,'1972','Update','fgt_model','1',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'33\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B152\', label_model_no=\'123000-5940B101\', model_name=\'T-259MY\', \r\n\t\t\t\t\tstd_qty=\'1\', customer=\'TOYOTA \', customer_part_no=\'86120-0K641\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822113812.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:38:12\'\r\n\t\t\t\t\tWHERE id_model=\'1\'','2016-08-22 11:38:12','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (156,'1972','Update','fgt_model','6',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'31\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B154\', label_model_no=\'123000-5940B101\', model_name=\'T-261IN\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'TOYOTA \', customer_part_no=\'86120-0K781\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822113824.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:38:24\'\r\n\t\t\t\t\tWHERE id_model=\'6\'','2016-08-22 11:38:24','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (157,'1972','Update','fgt_model','37',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'2\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C102\', label_model_no=\'123000-5950C101\', model_name=\'T-247TH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A39-1C\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822113833.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:38:33\'\r\n\t\t\t\t\tWHERE id_model=\'37\'','2016-08-22 11:38:33','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (158,'1972','Update','fgt_model','38',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'3\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C103\', label_model_no=\'123000-5950C101\', model_name=\'T-248TH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A39-1D\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', \r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:38:38\'\r\n\t\t\t\t\tWHERE id_model=\'38\'','2016-08-22 11:38:38','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (159,'1972','Update','fgt_model','38',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'3\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C103\', label_model_no=\'123000-5950C101\', model_name=\'T-248TH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A39-1D\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822113848.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:38:48\'\r\n\t\t\t\t\tWHERE id_model=\'38\'','2016-08-22 11:38:48','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (160,'1972','Update','fgt_model','39',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'10\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C104\', label_model_no=\'123000-5950C101\', model_name=\'T-324TH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'ISUZU\', customer_part_no=\'PC600-BZ001-00\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822113859.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:38:59\'\r\n\t\t\t\t\tWHERE id_model=\'39\'','2016-08-22 11:38:59','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (161,'1972','Update','fgt_model','29',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'4\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C152\', label_model_no=\'123000-5950C101\', model_name=\'T-246MY\', \r\n\t\t\t\t\tstd_qty=\'15\', customer=\'GM\', customer_part_no=\'898243 6012\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160822113952.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:39:52\'\r\n\t\t\t\t\tWHERE id_model=\'29\'','2016-08-22 11:39:52','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (162,'1972','Update','fgt_model','28',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'5\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C154\', label_model_no=\'123000-5950C101\', model_name=\'T-277BN\', \r\n\t\t\t\t\tstd_qty=\'15\', customer=\'GM\', customer_part_no=\'898243 6022\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', \r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:39:55\'\r\n\t\t\t\t\tWHERE id_model=\'28\'','2016-08-22 11:39:55','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (163,'1972','Update','fgt_model','28',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'5\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C154\', label_model_no=\'123000-5950C101\', model_name=\'T-277BN\', \r\n\t\t\t\t\tstd_qty=\'15\', customer=\'GM\', customer_part_no=\'898243 6022\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160822114002.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:40:02\'\r\n\t\t\t\t\tWHERE id_model=\'28\'','2016-08-22 11:40:02','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (164,'1972','Update','fgt_model','32',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'7\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C155\', label_model_no=\'123000-5950C101\', model_name=\'T-278IN\', \r\n\t\t\t\t\tstd_qty=\'15\', customer=\'ISUZU\', customer_part_no=\'898241 3572\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114008.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:40:08\'\r\n\t\t\t\t\tWHERE id_model=\'32\'','2016-08-22 11:40:08','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (165,'1972','Update','fgt_model','30',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'6\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C15L\', label_model_no=\'123000-5950C101\', model_name=\'T-277IN\', \r\n\t\t\t\t\tstd_qty=\'15\', customer=\'ISUZU\', customer_part_no=\'898243 6032\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160822114015.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:40:15\'\r\n\t\t\t\t\tWHERE id_model=\'30\'','2016-08-22 11:40:15','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (166,'1972','Update','fgt_model','40',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'23\', \r\n\t\t\t\t\ttag_model_no=\'123001-6080B102\', label_model_no=\'123000-6080B101\', model_name=\'T-262TH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A36-TH\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114023.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:40:23\'\r\n\t\t\t\t\tWHERE id_model=\'40\'','2016-08-22 11:40:23','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (167,'1972','Update','fgt_model','7',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'25\', \r\n\t\t\t\t\ttag_model_no=\'123001-6080B103\', label_model_no=\'123000-6080B101\', model_name=\'T-263TH\', \r\n\t\t\t\t\tstd_qty=\'3\', customer=\'TOYOTA \', customer_part_no=\'86120-0K811\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114036.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:40:36\'\r\n\t\t\t\t\tWHERE id_model=\'7\'','2016-08-22 11:40:36','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (168,'1972','Update','fgt_model','8',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'24\', \r\n\t\t\t\t\ttag_model_no=\'123001-6080B151\', label_model_no=\'123000-6080B101\', model_name=\'T-325JP\', \r\n\t\t\t\t\tstd_qty=\'3\', customer=\'TOYOTA \', customer_part_no=\'86120-0KC11\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114043.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:40:43\'\r\n\t\t\t\t\tWHERE id_model=\'8\'','2016-08-22 11:40:43','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (169,'1972','Update','fgt_model','41',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'15\', \r\n\t\t\t\t\ttag_model_no=\'123001-6090C102\', label_model_no=\'138000-6370E101\', model_name=\'T-251TH\', \r\n\t\t\t\t\tstd_qty=\'1\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A41-TH\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', \r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:40:47\'\r\n\t\t\t\t\tWHERE id_model=\'41\'','2016-08-22 11:40:47','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (170,'1972','Update','fgt_model','41',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'15\', \r\n\t\t\t\t\ttag_model_no=\'123001-6090C102\', label_model_no=\'138000-6370E101\', model_name=\'T-251TH\', \r\n\t\t\t\t\tstd_qty=\'1\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A41-TH\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114055.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:40:55\'\r\n\t\t\t\t\tWHERE id_model=\'41\'','2016-08-22 11:40:55','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (171,'1972','Update','fgt_model','42',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'16\', \r\n\t\t\t\t\ttag_model_no=\'123001-6090C103\', label_model_no=\'138000-6370E101\', model_name=\'T-252TH\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A41-GW\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114103.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:41:03\'\r\n\t\t\t\t\tWHERE id_model=\'42\'','2016-08-22 11:41:03','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (172,'1972','Update','fgt_model','43',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'26\', \r\n\t\t\t\t\ttag_model_no=\'123001-6100B102\', label_model_no=\'123000-6100B101\', model_name=\'T-264TH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A37-GW\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114112.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:41:12\'\r\n\t\t\t\t\tWHERE id_model=\'43\'','2016-08-22 11:41:12','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (173,'1972','Update','fgt_model','44',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'27\', \r\n\t\t\t\t\ttag_model_no=\'123001-6100B103\', label_model_no=\'123000-6100B101\', model_name=\'T-265TH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A37-TH\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114128.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:41:28\'\r\n\t\t\t\t\tWHERE id_model=\'44\'','2016-08-22 11:41:28','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (174,'1972','Update','fgt_model','9',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'28\', \r\n\t\t\t\t\ttag_model_no=\'123001-6100B151\', label_model_no=\'123000-6100B101\', model_name=\'T-266ID\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'TOYOTA \', customer_part_no=\'86120-0KA00\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114136.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:41:36\'\r\n\t\t\t\t\tWHERE id_model=\'9\'','2016-08-22 11:41:36','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (175,'1972','Update','fgt_model','45',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'21\', \r\n\t\t\t\t\ttag_model_no=\'123001-6110B102\', label_model_no=\'123000-6110B101\', model_name=\'T-255TH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A42-00\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114227.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:42:27\'\r\n\t\t\t\t\tWHERE id_model=\'45\'','2016-08-22 11:42:27','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (176,'1972','Update','fgt_model','46',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'22\', \r\n\t\t\t\t\ttag_model_no=\'123001-6110B103\', label_model_no=\'123000-6110B101\', model_name=\'T-256TH\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A42-GW\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114235.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:42:35\'\r\n\t\t\t\t\tWHERE id_model=\'46\'','2016-08-22 11:42:35','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (177,'1972','Update','fgt_model','35',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'17\', \r\n\t\t\t\t\ttag_model_no=\'123001-6110B151\', label_model_no=\'123000-6110B101\', model_name=\'T-253ID\', \r\n\t\t\t\t\tstd_qty=\'16\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A42\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114241.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:42:41\'\r\n\t\t\t\t\tWHERE id_model=\'35\'','2016-08-22 11:42:41','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (178,'1972','Update','fgt_model','33',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'18\', \r\n\t\t\t\t\ttag_model_no=\'123001-6110B152\', label_model_no=\'123000-6110B101\', model_name=\'T-254ID\', \r\n\t\t\t\t\tstd_qty=\'16\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A37\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114248.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:42:48\'\r\n\t\t\t\t\tWHERE id_model=\'33\'','2016-08-22 11:42:48','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (179,'1972','Update','fgt_model','34',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'19\', \r\n\t\t\t\t\ttag_model_no=\'123001-6110B153\', label_model_no=\'123000-6110B101\', model_name=\'T-257ID\', \r\n\t\t\t\t\tstd_qty=\'16\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A37\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114255.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:42:55\'\r\n\t\t\t\t\tWHERE id_model=\'34\'','2016-08-22 11:42:55','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (180,'1972','Update','fgt_model','48',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'35\', \r\n\t\t\t\t\ttag_model_no=\'123001-6130B102\', label_model_no=\'123000-6130B101\', model_name=\'T-271TH\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'ISUZU\', customer_part_no=\'PZ071-00A43-TH\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114304.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:43:04\'\r\n\t\t\t\t\tWHERE id_model=\'48\'','2016-08-22 11:43:04','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (181,'1972','Update','fgt_model','5',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'36\', \r\n\t\t\t\t\ttag_model_no=\'123001-6130B151\', label_model_no=\'123000-6130B101\', model_name=\'T-415MX\', \r\n\t\t\t\t\tstd_qty=\'6\', customer=\'TOYOTA \', customer_part_no=\'86120-0K741\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114314.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:43:14\'\r\n\t\t\t\t\tWHERE id_model=\'5\'','2016-08-22 11:43:14','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (182,'1972','Update','fgt_model','11',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'29\', \r\n\t\t\t\t\ttag_model_no=\'123002-5940B102\', label_model_no=\'123000-5940B101\', model_name=\'T-295PH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'TOYOTA \', customer_part_no=\'86120-0KA20\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114322.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:43:22\'\r\n\t\t\t\t\tWHERE id_model=\'11\'','2016-08-22 11:43:22','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (183,'1972','Update','fgt_model','10',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'30\', \r\n\t\t\t\t\ttag_model_no=\'123002-5940B103\', label_model_no=\'123000-5940B101\', model_name=\'T-296PH\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'TOYOTA \', customer_part_no=\'86120-0KA10\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114329.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:43:29\'\r\n\t\t\t\t\tWHERE id_model=\'10\'','2016-08-22 11:43:29','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (184,'1972','Update','fgt_model','31',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'8\', \r\n\t\t\t\t\ttag_model_no=\'123002-5950C102\', label_model_no=\'123000-5950C101\', model_name=\'T-292PH\', \r\n\t\t\t\t\tstd_qty=\'1\', customer=\'ISUZU\', customer_part_no=\'898241 4242\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160822114342.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:43:42\'\r\n\t\t\t\t\tWHERE id_model=\'31\'','2016-08-22 11:43:42','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (185,'1972','Update','fgt_model','24',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'9\', \r\n\t\t\t\t\ttag_model_no=\'123002-5950C103\', label_model_no=\'123000-5950C101\', model_name=\'T-293TH\', \r\n\t\t\t\t\tstd_qty=\'10\', customer=\'GM\', customer_part_no=\'52029703\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160822114351.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:43:51\'\r\n\t\t\t\t\tWHERE id_model=\'24\'','2016-08-22 11:43:51','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (186,'1972','Update','fgt_model','23',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'11\', \r\n\t\t\t\t\ttag_model_no=\'123002-5950C104\', label_model_no=\'123000-5950C101\', model_name=\'T-294PH\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'GM\', customer_part_no=\'52029703\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', model_picture=\'160822114408.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:44:08\'\r\n\t\t\t\t\tWHERE id_model=\'23\'','2016-08-22 11:44:08','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (187,'1972','Update','fgt_model','3',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'34\', \r\n\t\t\t\t\ttag_model_no=\'123003-5940B102\', label_model_no=\'139001-81200101\', model_name=\'T-302MY\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'TOYOTA \', customer_part_no=\'86120-0K671\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114427.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:44:27\'\r\n\t\t\t\t\tWHERE id_model=\'3\'','2016-08-22 11:44:27','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (188,'1972','Update','fgt_model','13',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'44\', \r\n\t\t\t\t\ttag_model_no=\'139000-67100101\', label_model_no=\'139000-67100101\', model_name=\'T-362TH\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'TOYOTA \', customer_part_no=\'86120-0KA50\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114438.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:44:38\'\r\n\t\t\t\t\tWHERE id_model=\'13\'','2016-08-22 11:44:38','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (189,'1972','Update','fgt_model','14',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'46\', \r\n\t\t\t\t\ttag_model_no=\'139000-67100102\', label_model_no=\'139000-67100101\', model_name=\'T-424MY\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'TOYOTA \', customer_part_no=\'86120-0KA80\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114448.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:44:48\'\r\n\t\t\t\t\tWHERE id_model=\'14\'','2016-08-22 11:44:48','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (190,'1972','Update','fgt_model','12',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'45\', \r\n\t\t\t\t\ttag_model_no=\'139000-67100151\', label_model_no=\'139000-67100101\', model_name=\'T-393SG\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'TOYOTA \', customer_part_no=\'86120-0KA40\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160822114515.jpg\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-22 11:45:15\'\r\n\t\t\t\t\tWHERE id_model=\'12\'','2016-08-22 11:45:15','10.164.214.65',NULL);
INSERT INTO `fgt_log_history` VALUES (191,'1972','Update','fgt_model','18',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'39\', \r\n\t\t\t\t\ttag_model_no=\'123000-72500151\', label_model_no=\'123000-72500101\', model_name=\'T-423SG\', \r\n\t\t\t\t\tstd_qty=\'4\', customer=\'GM\', customer_part_no=\'86120-0KD40\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', \r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-25 16:36:24\'\r\n\t\t\t\t\tWHERE id_model=\'18\'','2016-08-25 16:36:24','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (192,'1972','Update','fgt_model','22',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'41\', \r\n\t\t\t\t\ttag_model_no=\'123000-72500152\', label_model_no=\'123000-72500101\', model_name=\'T-389TH\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'GM\', customer_part_no=\'898052 9354\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', \r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-25 16:36:30\'\r\n\t\t\t\t\tWHERE id_model=\'22\'','2016-08-25 16:36:30','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (193,'1972','Update','fgt_model','22',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'41\', \r\n\t\t\t\t\ttag_model_no=\'123000-72500152\', label_model_no=\'123000-72500101\', model_name=\'T-389TH\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'GM\', customer_part_no=\'898052 9354\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', \r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-25 16:36:35\'\r\n\t\t\t\t\tWHERE id_model=\'22\'','2016-08-25 16:36:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (194,'1972','Update','fgt_model','22',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'41\', \r\n\t\t\t\t\ttag_model_no=\'123000-72500152\', label_model_no=\'123000-72500101\', model_name=\'T-389TH\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'GM\', customer_part_no=\'898052 9354\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', \r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-25 16:36:43\'\r\n\t\t\t\t\tWHERE id_model=\'22\'','2016-08-25 16:36:43','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (195,'1972','Update','fgt_model','22',' UPDATE  prod_fg_tag.fgt_model SET model_code=\'123\',  model_code=\'41\', \r\n\t\t\t\t\ttag_model_no=\'123000-72500152\', label_model_no=\'123000-72500101\', model_name=\'T-389TH\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'GM\', customer_part_no=\'898052 9354\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', status_tag_printing=\'1\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-25 16:38:19\'\r\n\t\t\t\t\tWHERE id_model=\'22\'','2016-08-25 16:38:19','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (196,'1972','Update','fgt_model','25',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'12\', \r\n\t\t\t\t\ttag_model_no=\'123000-6090C101\', label_model_no=\'138000-6370E101\', model_name=\'T-241TH\', \r\n\t\t\t\t\tstd_qty=\'10\', customer=\'GM\', customer_part_no=\'898126 0813\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', status_tag_printing=\'1\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-08-31 11:47:21\'\r\n\t\t\t\t\tWHERE id_model=\'25\'','2016-08-31 11:47:21','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (197,'1','Waiting','fgt_tag','010000017','','2016-08-31 16:15:07','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (198,'1','Waiting','fgt_tag','010000017','','2016-08-31 16:17:31','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (199,'1','Waiting','fgt_tag','010000017','','2016-09-01 09:15:05','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (200,'1','Insert','fgt_serial','BN601311','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000017\', \r\n\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601311\', \r\n\t\t\t\t\t\tdate_scan=\'2016-09-01 09:18:47\'','2016-09-01 09:18:47','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (201,'1','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000017\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-01 09:18:50\'','2016-09-01 09:18:50','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (202,'1','Print Tag','fgt_tag','010000017','','2016-09-01 09:18:50','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (203,'1','Insert','fgt_serial','BN700005','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000018\', \r\n\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700005\', \r\n\t\t\t\t\t\tdate_scan=\'2016-09-01 13:42:40\'','2016-09-01 13:42:40','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (204,'1','Insert','fgt_serial','BN700003','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000018\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700003\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-01 13:42:47\'','2016-09-01 13:42:47','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (205,'1','Insert','fgt_serial','BN700004','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000018\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700004\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-01 13:42:49\'','2016-09-01 13:42:49','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (206,'1','Insert','fgt_serial','BN700005','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000018\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700005\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-01 13:42:50\'','2016-09-01 13:42:50','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (207,'1972','Update','fgt_model','2',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'32\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B151\', label_model_no=\'123000-5940B101\', model_name=\'T-258MY\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'TOYOTA \', customer_part_no=\'86120-0K661\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', model_picture=\'160901172424.jpg\', status_tag_printing=\'1\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-09-01 17:24:25\'\r\n\t\t\t\t\tWHERE id_model=\'2\'','2016-09-01 17:24:25','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (208,'1972','Update','fgt_model','2',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'32\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B151\', label_model_no=\'123000-5940B101\', model_name=\'T-258MY\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'TOYOTA \', customer_part_no=\'86120-0K661\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKERs\', status_tag_printing=\'1\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-09-01 17:26:55\'\r\n\t\t\t\t\tWHERE id_model=\'2\'','2016-09-01 17:26:56','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (209,'1972','Update','fgt_model','2',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'32\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B151\', label_model_no=\'123000-5940B101\', model_name=\'T-258MY\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'TOYOTA \', customer_part_no=\'86120-0K661\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKERs\', model_picture=\'160901172732.jpg\', status_tag_printing=\'1\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-09-01 17:27:33\'\r\n\t\t\t\t\tWHERE id_model=\'2\'','2016-09-01 17:27:33','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (210,'1972','Update','fgt_model','2',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'32\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B151\', label_model_no=\'123000-5940B101\', model_name=\'T-258MY\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'TOYOTA \', customer_part_no=\'86120-0K661\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKERs\', status_tag_printing=\'1\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-09-01 17:28:54\'\r\n\t\t\t\t\tWHERE id_model=\'2\'','2016-09-01 17:28:54','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (211,'1972','Update','fgt_model','2',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'32\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B151\', label_model_no=\'123000-5940B101\', model_name=\'T-258MY\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'TOYOTA \', customer_part_no=\'86120-0K661\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKERs\', status_tag_printing=\'1\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-09-01 17:28:58\'\r\n\t\t\t\t\tWHERE id_model=\'2\'','2016-09-01 17:28:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (212,'1972','Update','fgt_model','2',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'32\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B151\', label_model_no=\'123000-5940B101\', model_name=\'T-258MY\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'TOYOTA \', customer_part_no=\'86120-0K661\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKERs\', status_tag_printing=\'1\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-09-01 17:29:36\'\r\n\t\t\t\t\tWHERE id_model=\'2\'','2016-09-01 17:29:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (213,'1972','Update','fgt_model','2',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'32\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B151\', label_model_no=\'123000-5940B101\', model_name=\'T-258MY\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'TOYOTA \', customer_part_no=\'86120-0K661\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKERs\', status_tag_printing=\'1\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-09-01 17:30:43\'\r\n\t\t\t\t\tWHERE id_model=\'2\'','2016-09-01 17:30:43','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (214,'1972','Update','fgt_model','2',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'32\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B151\', label_model_no=\'123000-5940B101\', model_name=\'T-258MY\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'TOYOTA \', customer_part_no=\'86120-0K661\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKERs\', status_tag_printing=\'1\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-09-01 17:31:18\'\r\n\t\t\t\t\tWHERE id_model=\'2\'','2016-09-01 17:31:18','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (215,'1','Insert','fgt_serial','BN700006','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000018\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700006\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-02 16:11:19\'','2016-09-02 16:11:19','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (216,'1','Insert','fgt_serial','BN700007','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000018\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700007\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-02 16:11:25\'','2016-09-02 16:11:25','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (217,'1','Insert','fgt_serial','BN700011','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000018\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700011\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-02 16:11:29\'','2016-09-02 16:11:29','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (218,'1','Insert','fgt_serial','BN700009','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000018\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700009\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-02 16:11:32\'','2016-09-02 16:11:32','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (219,'1','Insert','fgt_serial','BN700010','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000018\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700010\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-02 16:11:35\'','2016-09-02 16:11:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (220,'1','Insert','fgt_serial','BN700011','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000018\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700011\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-02 16:11:36\'','2016-09-02 16:11:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (221,'1','Print Tag','fgt_tag','010000018','','2016-09-02 16:11:37','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (222,'1','Insert','fgt_serial','BN700008','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000018\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700008\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-02 16:33:52\'','2016-09-02 16:33:52','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (223,'1','Print Tag','fgt_tag','010000018','','2016-09-02 16:33:52','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (224,'1','Insert','fgt_serial','BN700011','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000018\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700011\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-02 16:39:08\'','2016-09-02 16:39:08','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (225,'1','Print Tag','fgt_tag','010000018','','2016-09-02 16:39:08','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (226,'6','Insert','fgt_serial','','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000019\', \r\n\t\t\t\t\t\tmodel_scan_label=\'123000-5940B101\', serial_scan_label=\'\', \r\n\t\t\t\t\t\tdate_scan=\'2016-09-06 10:51:04\'','2016-09-06 10:51:05','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (227,'6','Insert','fgt_serial','BN601310','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000019\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601310\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-06 10:54:15\'','2016-09-06 10:54:15','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (228,'6','Insert','fgt_serial','BN800151','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000019\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'GC\', serial_scan_label=\'BN800151\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-06 13:45:18\'','2016-09-06 13:45:18','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (229,'6','Insert','fgt_serial','BN800152','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000019\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GC\', serial_scan_label=\'BN800152\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-06 13:45:20\'','2016-09-06 13:45:20','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (230,'6','Print Tag','fgt_tag','060000019','','2016-09-06 13:45:20','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (231,'6','Insert','fgt_serial','BN800155','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000019\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GC\', serial_scan_label=\'BN800155\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-06 13:47:39\'','2016-09-06 13:47:39','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (232,'6','Print Tag','fgt_tag','060000019','','2016-09-06 13:47:39','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (233,'6','Insert','fgt_serial','BN800152','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000019\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GC\', serial_scan_label=\'BN800152\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-06 13:48:17\'','2016-09-06 13:48:17','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (234,'6','Print Tag','fgt_tag','060000019','','2016-09-06 13:48:17','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (235,'6','Insert','fgt_serial','BN800152','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000019\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GC\', serial_scan_label=\'BN800152\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-06 14:45:55\'','2016-09-06 14:45:55','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (236,'6','Print Tag','fgt_tag','060000019','','2016-09-06 14:45:55','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (237,'1','Insert','fgt_serial','BN700017','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000020\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700017\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-06 14:47:12\'','2016-09-06 14:47:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (238,'1','Insert','fgt_serial','BN700018','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000020\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700018\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-06 14:47:15\'','2016-09-06 14:47:15','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (239,'1','Insert','fgt_serial','BN700019','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000020\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700019\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-06 14:47:19\'','2016-09-06 14:47:19','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (240,'1','Insert','fgt_serial','BN700020','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000020\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700020\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-06 14:47:22\'','2016-09-06 14:47:22','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (241,'1','Insert','fgt_serial','BN700021','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000020\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700021\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-06 14:47:25\'','2016-09-06 14:47:25','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (242,'1','Insert','fgt_serial','BN700022','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000020\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700022\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-06 14:47:28\'','2016-09-06 14:47:28','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (243,'1','Print Tag','fgt_tag','010000020','','2016-09-06 14:47:28','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (244,'1972','Update','fgt_model','2',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'32\', \r\n\t\t\t\t\ttag_model_no=\'123001-5940B151\', label_model_no=\'123000-5940B101\', model_name=\'T-258MY\', \r\n\t\t\t\t\tstd_qty=\'2\', customer=\'TOYOTA \', customer_part_no=\'86120-0K661\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKERs\', status_tag_printing=\'0\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-09-07 12:33:14\'\r\n\t\t\t\t\tWHERE id_model=\'2\'','2016-09-07 12:33:14','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (245,'1972','Update','fgt_model','27',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'13\', \r\n\t\t\t\t\ttag_model_no=\'123001-6090C151\', label_model_no=\'138000-6370E101\', model_name=\'T-249ID\', \r\n\t\t\t\t\tstd_qty=\'10\', customer=\'GM\', customer_part_no=\'898219 8443\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', status_tag_printing=\'0\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-09-07 12:33:32\'\r\n\t\t\t\t\tWHERE id_model=\'27\'','2016-09-07 12:33:32','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (246,'1972','Update','fgt_model','26',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'14\', \r\n\t\t\t\t\ttag_model_no=\'123001-6090C152\', label_model_no=\'138000-6370E101\', model_name=\'T-250ID\', \r\n\t\t\t\t\tstd_qty=\'10\', customer=\'GM\', customer_part_no=\'898171 4812\', \r\n\t\t\t\t\tcustomer_part_name=\'AUDIO\', status_tag_printing=\'0\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-09-07 12:33:40\'\r\n\t\t\t\t\tWHERE id_model=\'26\'','2016-09-07 12:33:41','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (247,'1972','Update','fgt_model','49',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'1\', \r\n\t\t\t\t\ttag_model_no=\'123001-5950C151\', label_model_no=\'138000-6350F101\', model_name=\'T-245VN\', \r\n\t\t\t\t\tstd_qty=\'6\', customer=\'ISUZU\', customer_part_no=\'812000-2214652\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', status_tag_printing=\'0\',\r\n\t\t\t\t\temp_modify=\'1972\', date_modify=\'2016-09-07 12:34:45\'\r\n\t\t\t\t\tWHERE id_model=\'49\'','2016-09-07 12:34:45','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (248,'6','Insert','fgt_serial','BN700017','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000021\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700017\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:35:00\'','2016-09-07 11:35:00','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (249,'6','Insert','fgt_serial','BN700018','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000021\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700018\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:35:03\'','2016-09-07 11:35:03','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (250,'6','Insert','fgt_serial','BN700019','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000021\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700019\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:35:05\'','2016-09-07 11:35:05','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (251,'6','Insert','fgt_serial','BN700020','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000021\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700020\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:35:07\'','2016-09-07 11:35:07','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (252,'6','Insert','fgt_serial','BN700021','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000021\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700021\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:35:08\'','2016-09-07 11:35:08','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (253,'6','Insert','fgt_serial','BN700022','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000021\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700022\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:35:10\'','2016-09-07 11:35:10','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (254,'6','Printed Tag','fgt_tag','060000021','','2016-09-07 11:35:10','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (255,'6','Insert','fgt_serial','BN700022','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000021\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700022\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:38:26\'','2016-09-07 11:38:26','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (256,'6','Printed Tag','fgt_tag','060000021','','2016-09-07 11:38:26','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (257,'6','Insert','fgt_serial','BN700022','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000021\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700022\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:41:01\'','2016-09-07 11:41:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (258,'6','Printed Tag','fgt_tag','060000021','','2016-09-07 11:41:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (259,'1','Insert','fgt_serial','BN601311','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000022\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601311\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:43:22\'','2016-09-07 11:43:22','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (260,'1','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000022\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:43:24\'','2016-09-07 11:43:24','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (261,'1','Insert','fgt_serial','BN601313','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000022\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601313\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:43:27\'','2016-09-07 11:43:27','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (262,'1','Insert','fgt_serial','BN601314','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000022\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601314\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:43:29\'','2016-09-07 11:43:29','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (263,'1','Printed Tag','fgt_tag','010000022','','2016-09-07 11:43:29','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (264,'1','Waiting','fgt_tag','010000023','','2016-09-07 11:44:44','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (265,'5','Insert','fgt_serial','BN701530','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'050000012\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701530\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:44:57\'','2016-09-07 11:44:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (266,'5','Printed Tag','fgt_tag','050000012','','2016-09-07 11:44:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (267,'4','Insert','fgt_serial','BN700005','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000024\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700005\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:46:11\'','2016-09-07 11:46:11','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (268,'4','Insert','fgt_serial','BN700003','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000024\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700003\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:46:13\'','2016-09-07 11:46:13','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (269,'4','Insert','fgt_serial','BN700004','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000024\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700004\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:46:15\'','2016-09-07 11:46:15','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (270,'4','Insert','fgt_serial','BN700005','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000024\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700005\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:46:17\'','2016-09-07 11:46:17','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (271,'4','Insert','fgt_serial','BN700006','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000024\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700006\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:46:18\'','2016-09-07 11:46:18','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (272,'4','Insert','fgt_serial','BN700007','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000024\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700007\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:46:19\'','2016-09-07 11:46:19','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (273,'4','Insert','fgt_serial','BN700008','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000024\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700008\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:46:20\'','2016-09-07 11:46:20','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (274,'4','Insert','fgt_serial','BN700009','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000024\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700009\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:46:21\'','2016-09-07 11:46:21','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (275,'4','Insert','fgt_serial','BN700010','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000024\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700010\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:46:22\'','2016-09-07 11:46:22','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (276,'4','Insert','fgt_serial','BN700011','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000024\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700011\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:46:57\'','2016-09-07 11:46:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (277,'4','Printed Tag','fgt_tag','040000024','','2016-09-07 11:46:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (278,'4','Insert','fgt_serial','BN904524','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000025\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'GD\', serial_scan_label=\'BN904524\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:49:44\'','2016-09-07 11:49:44','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (279,'4','Insert','fgt_serial','BN904525','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000025\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'GD\', serial_scan_label=\'BN904525\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:49:46\'','2016-09-07 11:49:46','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (280,'4','Insert','fgt_serial','BN904526','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000025\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'GD\', serial_scan_label=\'BN904526\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:49:46\'','2016-09-07 11:49:47','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (281,'4','Insert','fgt_serial','BN904527','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000025\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GD\', serial_scan_label=\'BN904527\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 11:49:48\'','2016-09-07 11:49:48','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (282,'4','Printed Tag','fgt_tag','040000025','','2016-09-07 11:49:48','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (283,'1','Insert','fgt_serial','BN700022','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000002\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6350F101\', serial_scan_label=\'BN700022\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-07 13:30:05\'','2016-09-07 13:30:05','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (284,'1','Printed Tag','fgt_tag','010000002','','2016-09-07 13:30:05','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (285,'1','Insert','fgt_serial','BN700002','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000023\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700002\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-08 11:33:28\'','2016-09-08 11:33:28','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (286,'1','Insert','fgt_serial','BN700003','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000023\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700003\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:02:14\'','2016-09-09 14:02:14','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (287,'1','Insert','fgt_serial','BN700004','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000023\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700004\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:02:35\'','2016-09-09 14:02:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (288,'1','Insert','fgt_serial','BN700005','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000023\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700005\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:02:36\'','2016-09-09 14:02:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (289,'1','Insert','fgt_serial','BN700006','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000023\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700006\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:02:38\'','2016-09-09 14:02:38','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (290,'1','Insert','fgt_serial','BN700007','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000023\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700007\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:02:39\'','2016-09-09 14:02:39','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (291,'1','Insert','fgt_serial','BN700008','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000023\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700008\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:02:40\'','2016-09-09 14:02:40','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (292,'1','Insert','fgt_serial','BN700009','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000023\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700009\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:02:42\'','2016-09-09 14:02:42','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (293,'1','Insert','fgt_serial','BN700010','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000023\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700010\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:02:44\'','2016-09-09 14:02:44','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (294,'1','Insert','fgt_serial','BN700011','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000023\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'138000-6370E101\', serial_scan_label=\'BN700011\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:02:48\'','2016-09-09 14:02:48','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (295,'1','Printed Tag','fgt_tag','010000023','','2016-09-09 14:02:48','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (296,'3','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000026\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:13:27\'','2016-09-09 14:13:27','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (297,'3','Insert','fgt_serial','BN601313','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000026\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601313\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:13:30\'','2016-09-09 14:13:30','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (298,'3','Insert','fgt_serial','BN601314','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000026\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601314\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:13:31\'','2016-09-09 14:13:31','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (299,'3','Insert','fgt_serial','BN601315','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000026\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601315\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:13:32\'','2016-09-09 14:13:32','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (300,'3','Printed Tag','fgt_tag','030000026','','2016-09-09 14:13:32','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (301,'4','Update','fgt_model','36',' UPDATE  prod_fg_tag.fgt_model SET   model_code=\'20\', \r\n\t\t\t\t\ttag_model_no=\'123000-6110B101\', label_model_no=\'123000-6110B101\', model_name=\'T-242TH\', \r\n\t\t\t\t\tstd_qty=\'5\', customer=\'ISUZU\', customer_part_no=\'898340 5000\', \r\n\t\t\t\t\tcustomer_part_name=\'SPEAKER\', status_tag_printing=\'0\',\r\n\t\t\t\t\temp_modify=\'4\', date_modify=\'2016-09-09 15:38:46\'\r\n\t\t\t\t\tWHERE id_model=\'36\'','2016-09-09 15:38:46','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (302,'4','Insert','fgt_serial','BN701529','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000027\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701529\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:40:10\'','2016-09-09 14:40:10','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (303,'4','Insert','fgt_serial','BN701530','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000027\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701530\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:40:12\'','2016-09-09 14:40:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (304,'4','Insert','fgt_serial','BN701531','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000027\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701531\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:40:13\'','2016-09-09 14:40:13','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (305,'4','Insert','fgt_serial','BN701532','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000027\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701532\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:40:13\'','2016-09-09 14:40:13','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (306,'4','Insert','fgt_serial','BN701533','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000027\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701533\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:40:14\'','2016-09-09 14:40:14','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (307,'4','Printed Tag','fgt_tag','040000027','','2016-09-09 14:40:14','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (308,'4','Waiting','fgt_tag','040000028','','2016-09-09 14:45:00','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (309,'4','Insert','fgt_serial','BN701529','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'040000028\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701529\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-09 14:45:14\'','2016-09-09 14:45:14','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (310,'4','Waiting','fgt_tag','040000028','','2016-09-09 14:45:17','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (311,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:22:48','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (312,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:22:50','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (313,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:22:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (314,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:23:26','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (315,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:23:27','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (316,'4','Reprinted Tag','fgt_tag','040000024','','2016-09-09 16:23:31','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (317,'4','Reprinted Tag','fgt_tag','040000025','','2016-09-09 16:23:33','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (318,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:23:34','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (319,'4','Reprinted Tag','fgt_tag','040000024','','2016-09-09 16:23:50','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (320,'4','Reprinted Tag','fgt_tag','040000025','','2016-09-09 16:23:51','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (321,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:23:53','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (322,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:24:15','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (323,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:24:17','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (324,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:24:18','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (325,'4','Reprinted Tag','fgt_tag','040000024','','2016-09-09 16:24:19','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (326,'4','Reprinted Tag','fgt_tag','040000024','','2016-09-09 16:24:26','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (327,'4','Reprinted Tag','fgt_tag','040000024','','2016-09-09 16:24:45','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (328,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:24:47','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (329,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:25:11','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (330,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:25:17','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (331,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:25:19','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (332,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:25:20','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (333,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:25:20','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (334,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:25:20','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (335,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:25:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (336,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:25:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (337,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:25:37','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (338,'4','Reprinted Tag','fgt_tag','040000025','','2016-09-09 16:25:37','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (339,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:25:38','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (340,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:25:39','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (341,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:25:39','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (342,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:25:55','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (343,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:25:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (344,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:25:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (345,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:25:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (346,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:26:07','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (347,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:28:03','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (348,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:28:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (349,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:29:08','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (350,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:29:23','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (351,'4','Reprinted Tag','fgt_tag','040000024','','2016-09-09 16:29:25','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (352,'4','Reprinted Tag','fgt_tag','040000025','','2016-09-09 16:29:26','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (353,'4','Reprinted Tag','fgt_tag','040000025','','2016-09-09 16:29:27','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (354,'4','Reprinted Tag','fgt_tag','040000025','','2016-09-09 16:29:28','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (355,'4','Reprinted Tag','fgt_tag','040000025','','2016-09-09 16:29:29','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (356,'4','Reprinted Tag','fgt_tag','040000024','','2016-09-09 16:29:29','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (357,'4','Reprinted Tag','fgt_tag','040000024','','2016-09-09 16:29:30','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (358,'4','Reprinted Tag','fgt_tag','040000024','','2016-09-09 16:51:25','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (359,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:51:26','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (360,'4','Reprinted Tag','fgt_tag','040000025','','2016-09-09 16:51:27','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (361,'4','Reprinted Tag','fgt_tag','040000027','','2016-09-09 16:51:28','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (362,'4','Reprinted Tag','fgt_tag','040000025','','2016-09-09 16:51:29','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (363,'4','Reprinted Tag','fgt_tag','040000024','','2016-09-09 16:51:30','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (364,'4','Reprinted Tag','fgt_tag','040000013','','2016-09-09 16:51:30','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (365,'2','Reprinted Tag','fgt_tag','020000009','','2016-09-12 08:33:51','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (366,'2','Reprinted Tag','fgt_tag','020000014','','2016-09-12 08:35:25','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (367,'2','Reprinted Tag','fgt_tag','020000014','','2016-09-12 10:28:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (368,'2','Reprinted Tag','fgt_tag','020000014','','2016-09-12 10:28:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (369,'2','Reprinted Tag','fgt_tag','020000014','','2016-09-12 10:28:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (370,'6','Reprinted Tag','fgt_tag','060000019','','2016-09-12 11:37:43','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (371,'6','Reprinted Tag','fgt_tag','060000021','','2016-09-12 11:42:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (372,'1972','Reprinted Tag','fgt_tag','060000021','','2016-09-12 11:45:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (373,'1972','Reprinted Tag','fgt_tag','060000021','','2016-09-12 11:46:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (374,'1972','Reprinted Tag','fgt_tag','060000021','','2016-09-12 11:46:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (375,'1972','Reprinted Tag','fgt_tag','060000021','','2016-09-12 11:46:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (376,'1972','Reprinted Tag','fgt_tag','060000021','','2016-09-12 11:46:02','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (377,'3','Reprinted Tag','fgt_tag','26','','2016-09-12 13:51:42','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (378,'3','Insert','fgt_serial','BN601311','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000029\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601311\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-09-12 13:53:10\'','2016-09-12 13:53:10','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (379,'3','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000029\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-12 13:53:11\'','2016-09-12 13:53:11','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (380,'3','Insert','fgt_serial','BN601313','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000029\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601313\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-12 13:53:12\'','2016-09-12 13:53:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (381,'3','Insert','fgt_serial','BN601314','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000029\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601314\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-09-12 13:53:12\'','2016-09-12 13:53:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (382,'3','Insert','fgt_serial','BN601315','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000029\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601315\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-09-12 13:53:13\'','2016-09-12 13:53:13','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (383,'3','Printed Tag','fgt_tag','030000029','','2016-09-12 13:53:13','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (384,'3','Reprinted Tag','fgt_tag','29','','2016-09-12 13:53:46','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (385,'3','Reprinted Tag','fgt_tag','29','','2016-09-12 13:54:43','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (386,'3','Reprinted Tag','fgt_tag','26','','2016-09-12 13:55:08','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (387,'1','Reprinted Tag','fgt_tag','3','','2016-09-26 15:43:39','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (388,'1','Reprinted Tag','fgt_tag','4','','2016-09-26 15:44:50','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (389,'1','Reprinted Tag','fgt_tag','8','','2016-09-26 15:45:43','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (390,'1','Reprinted Tag','fgt_tag','8','','2016-09-26 15:45:45','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (391,'1','Reprinted Tag','fgt_tag','8','','2016-09-26 15:45:46','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (392,'1','Reprinted Tag','fgt_tag','7','','2016-09-26 15:46:20','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (393,'1','Reprinted Tag','fgt_tag','7','','2016-09-26 15:46:34','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (394,'1','Reprinted Tag','fgt_tag','7','','2016-09-26 15:47:39','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (395,'1','Reprinted Tag','fgt_tag','4','','2016-09-26 15:47:40','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (396,'1','Reprinted Tag','fgt_tag','7','','2016-09-26 15:47:52','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (397,'1','Reprinted Tag','fgt_tag','8','','2016-09-26 15:47:59','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (398,'1','Reprinted Tag','fgt_tag','17','','2016-09-26 15:48:04','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (399,'1','Reprinted Tag','fgt_tag','17','','2016-09-26 15:50:32','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (400,'1','Reprinted Tag','fgt_tag','17','','2016-09-26 16:01:51','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (401,'1','Reprinted Tag','fgt_tag','17','','2016-09-26 16:04:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (402,'1','Reprinted Tag','fgt_tag','17','','2016-09-26 16:04:28','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (403,'1','Reprinted Tag','fgt_tag','23','','2016-09-26 16:15:29','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (404,'1','Reprinted Tag','fgt_tag','5','','2016-09-26 16:16:07','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (405,'2','Reprinted Tag','fgt_tag','14','','2016-10-05 16:18:42','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (406,'2','Reprinted Tag','fgt_tag','9','','2016-10-05 16:19:32','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (407,'1','Reprinted Tag','fgt_tag','1','','2016-10-05 16:20:45','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (408,'1','Reprinted Tag','fgt_tag','22','','2016-10-05 16:20:51','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (409,'1','Reprinted Tag','fgt_tag','20','','2016-10-05 16:20:53','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (410,'1','Reprinted Tag','fgt_tag','18','','2016-10-05 16:20:55','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (411,'1','Reprinted Tag','fgt_tag','6','','2016-10-05 16:20:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (412,'1','Reprinted Tag','fgt_tag','1','','2016-10-05 16:22:11','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (413,'1','Reprinted Tag','fgt_tag','2','','2016-10-05 16:22:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (414,'1','Reprinted Tag','fgt_tag','3','','2016-10-05 16:22:14','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (415,'1','Reprinted Tag','fgt_tag','4','','2016-10-05 16:22:16','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (416,'1','Reprinted Tag','fgt_tag','6','','2016-10-05 16:22:19','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (417,'1','Reprinted Tag','fgt_tag','7','','2016-10-05 16:22:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (418,'1','Reprinted Tag','fgt_tag','8','','2016-10-05 16:22:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (419,'1','Reprinted Tag','fgt_tag','8','','2016-10-05 16:22:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (420,'1','Reprinted Tag','fgt_tag','22','','2016-10-05 16:22:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (421,'1','Reprinted Tag','fgt_tag','23','','2016-10-05 16:22:59','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (422,'3','Reprinted Tag','fgt_tag','26','','2016-10-05 16:23:09','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (423,'3','Reprinted Tag','fgt_tag','29','','2016-10-05 16:23:11','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (424,'4','Reprinted Tag','fgt_tag','13','','2016-10-05 16:23:23','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (425,'4','Reprinted Tag','fgt_tag','24','','2016-10-05 16:23:25','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (426,'4','Reprinted Tag','fgt_tag','25','','2016-10-05 16:23:26','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (427,'4','Reprinted Tag','fgt_tag','27','','2016-10-05 16:23:28','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (428,'5','Reprinted Tag','fgt_tag','10','','2016-10-05 16:23:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (429,'5','Reprinted Tag','fgt_tag','11','','2016-10-05 16:23:37','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (430,'5','Reprinted Tag','fgt_tag','12','','2016-10-05 16:23:39','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (431,'3','Insert','fgt_serial','BN600377','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000030\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'139000-67300101\', serial_scan_label=\'BN600377\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-10-07 08:59:49\'','2016-10-07 08:59:49','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (432,'3','Insert','fgt_serial','BN600378','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000030\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'139000-67300101\', serial_scan_label=\'BN600378\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-07 08:59:54\'','2016-10-07 08:59:54','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (433,'3','Insert','fgt_serial','BN600379','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000030\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'139000-67300101\', serial_scan_label=\'BN600379\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-07 09:03:35\'','2016-10-07 09:03:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (434,'3','Insert','fgt_serial','BN600380','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'030000030\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'139000-67300101\', serial_scan_label=\'BN600380\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-07 09:04:43\'','2016-10-07 09:04:43','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (435,'3','Printed Tag','fgt_tag','030000030','','2016-10-07 09:04:43','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (436,'1972','Print','fgt_supplier_tag_spl','6','','2016-10-11 14:19:26','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (437,'1972','Print','fgt_supplier_tag_spl','6','','2016-10-11 14:19:41','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (438,'1972','Print','fgt_supplier_tag','6','','2016-10-11 14:45:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (439,'1972','Print','fgt_supplier_tag','6','','2016-10-11 14:51:16','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (440,'1972','Print','fgt_supplier_tag','6','','2016-10-11 14:52:08','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (441,'1972','Print','fgt_supplier_tag','6','','2016-10-11 14:56:23','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (442,'1972','Print','fgt_supplier_tag','6','','2016-10-11 14:56:45','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (443,'1972','Print','fgt_supplier_tag','6','','2016-10-11 14:56:50','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (444,'1972','Print','fgt_supplier_tag','6','','2016-10-11 14:58:48','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (445,'1972','Print','fgt_supplier_tag','6','','2016-10-11 15:17:23','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (446,'1972','Print','fgt_supplier_tag','7','','2016-10-11 15:20:15','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (447,'1972','Print','fgt_supplier_tag','5','','2016-10-11 15:42:56','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (448,'1972','Print','fgt_supplier_tag','8','','2016-10-11 16:09:21','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (449,'1972','Print','fgt_supplier_tag','9','','2016-10-11 16:10:00','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (450,'1972','Print','fgt_supplier_tag','1','','2016-10-11 16:13:57','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (451,'6','Waiting','fgt_tag','060000031','','2016-10-11 16:40:34','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (452,'6','Insert','fgt_serial','BN800148','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000032\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'GC\', serial_scan_label=\'BN800148\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-10-11 16:40:52\'','2016-10-11 16:40:52','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (453,'6','Print Tag','fgt_tag','060000032','','2016-10-11 16:41:05','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (454,'6','Insert','fgt_serial','BN701533','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000033\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701533\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-10-11 17:17:58\'','2016-10-11 17:17:58','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (455,'6','Print Tag','fgt_tag','060000033','','2016-10-11 17:18:06','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (456,'6','Insert','fgt_serial','BN800150','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000034\', \r\n\t\t\t\t\t\t\tmodel_scan_label=\'GC\', serial_scan_label=\'BN800150\', \r\n\t\t\t\t\t\t\tdate_scan=\'2016-10-12 08:57:21\'','2016-10-12 08:57:21','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (457,'6','Insert','fgt_serial','BN800150','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000034\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'GC\', serial_scan_label=\'BN800150\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 09:56:11\'','2016-10-12 09:56:11','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (458,'6','Printed Tag','fgt_tag','060000034','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000034\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'Print\',tag_qty=\'1\' \r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'34\' ','2016-10-12 10:30:22','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (459,'6','Printed Tag','fgt_tag','060000034','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000034\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'Print\',tag_qty=\'1\' , date_print=\'2016-10-12 10:31:48\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'34\' ','2016-10-12 10:31:48','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (460,'6','Printed Tag','fgt_tag','060000034','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000034\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'Print\',tag_qty=\'1\' , date_print=\'2016-10-12 10:33:15\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'34\' ','2016-10-12 10:33:15','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (461,'6','Printed Tag','fgt_tag','060000034','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000034\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'Print\',tag_qty=\'1\' , date_print=\'2016-10-12 10:33:40\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'34\' ','2016-10-12 10:33:41','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (462,'6','Printed Tag','fgt_tag','060000034','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000034\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'Print\',tag_qty=\'1\' , date_print=\'2016-10-12 10:34:06\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'34\' ','2016-10-12 10:34:06','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (463,'6','Printed Tag','fgt_tag','060000034','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000034\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'Print\',tag_qty=\'1\' , date_print=\'2016-10-12 10:36:02\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'34\' ','2016-10-12 10:36:02','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (464,'6','Printed Tag','fgt_tag','060000034','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000034\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'Print\',tag_qty=\'1\' , date_print=\'2016-10-12 10:44:09\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'34\' ','2016-10-12 10:44:09','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (465,'6','Printed Tag','fgt_tag','060000034','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000034\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'ddd\',tag_qty=\'1\' , date_print=\'2016-10-12 10:44:33\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'34\' ','2016-10-12 10:44:33','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (466,'6','Printed Tag','fgt_tag','060000034','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000034\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'ddd\',tag_qty=\'1\' , date_print=\'2016-10-12 10:44:44\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'34\' ','2016-10-12 10:44:44','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (467,'6','Printed Tag','fgt_tag','060000034','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000034\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'Print\',tag_qty=\'1\' , date_print=\'2016-10-12 10:45:34\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'34\' ','2016-10-12 10:45:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (468,'6','Printed Tag','fgt_tag','060000034','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000034\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'Print\',tag_qty=\'1\' , date_print=\'2016-10-12 10:46:36\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'34\' ','2016-10-12 10:46:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (469,'6','Printed Tag','fgt_tag','060000034','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000034\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'Print\',tag_qty=\'1\' , date_print=\'2016-10-12 10:46:40\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'34\' ','2016-10-12 10:46:40','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (470,'6','Insert','fgt_serial','BN601311','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000031\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601311\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 10:47:43\'','2016-10-12 10:47:43','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (471,'6','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000031\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 10:47:43\'','2016-10-12 10:47:43','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (472,'6','Printed Tag','fgt_tag','060000031','','2016-10-12 10:47:43','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (473,'6','Insert','fgt_serial','BN601311','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000031\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601311\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 10:49:11\'','2016-10-12 10:49:11','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (474,'6','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000031\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 10:49:12\'','2016-10-12 10:49:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (475,'6','Printed Tag','fgt_tag','060000031','','2016-10-12 10:49:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (476,'6','Insert','fgt_serial','BN701526','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000035\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701526\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 11:56:47\'','2016-10-12 11:56:47','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (477,'6','Printed Tag','fgt_tag','060000035','','2016-10-12 11:56:47','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (478,'6','Insert','fgt_serial','BN701526','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000035\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701526\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 11:56:47\'','2016-10-12 11:56:47','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (479,'6','Insert','fgt_serial','BN701529','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000036\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701529\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 11:57:37\'','2016-10-12 11:57:37','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (480,'6','Printed Tag','fgt_tag','060000036','','2016-10-12 11:57:37','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (481,'6','Insert','fgt_serial','BN701529','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000036\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701529\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 11:57:37\'','2016-10-12 11:57:37','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (482,'6','Insert','fgt_serial','BN701534','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000037\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701534\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 11:59:35\'','2016-10-12 11:59:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (483,'6','Printed Tag','fgt_tag','060000037','','2016-10-12 11:59:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (484,'6','Insert','fgt_serial','BN701534','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000037\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701534\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 11:59:35\'','2016-10-12 11:59:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (485,'6','Insert','fgt_serial','BN701532','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000038\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701532\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 12:00:22\'','2016-10-12 12:00:22','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (486,'6','Printed Tag','fgt_tag','060000038','','2016-10-12 12:00:22','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (487,'6','Insert','fgt_serial','BN701532','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000038\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701532\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 12:00:22\'','2016-10-12 12:00:22','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (488,'6','Insert','fgt_serial','BN701532','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000039\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701532\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 12:00:50\'','2016-10-12 12:00:50','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (489,'6','Printed Tag','fgt_tag','060000039','','2016-10-12 12:00:50','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (490,'6','Insert','fgt_serial','BN701532','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000039\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701532\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 12:00:50\'','2016-10-12 12:00:50','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (491,'6','Insert','fgt_serial','BN601319','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000040\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601319\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 12:02:12\'','2016-10-12 12:02:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (492,'6','Printed Tag','fgt_tag','060000040','','2016-10-12 12:02:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (493,'6','Insert','fgt_serial','BN601319','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000040\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601319\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 12:02:12\'','2016-10-12 12:02:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (494,'6','Insert','fgt_serial','BN701526','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000041\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701526\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 12:03:04\'','2016-10-12 12:03:04','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (495,'6','Printed Tag','fgt_tag','060000041','','2016-10-12 12:03:04','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (496,'6','Insert','fgt_serial','BN701526','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000041\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701526\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 12:03:04\'','2016-10-12 12:03:04','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (497,'6','Insert','fgt_serial','BN601316','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000042\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601316\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 12:03:22\'','2016-10-12 12:03:22','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (498,'6','Printed Tag','fgt_tag','060000042','','2016-10-12 12:03:22','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (499,'6','Insert','fgt_serial','BN601316','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000042\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601316\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 12:03:22\'','2016-10-12 12:03:22','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (500,'6','Insert','fgt_serial','BN601319','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000043\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601319\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 12:04:03\'','2016-10-12 12:04:03','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (501,'6','Printed Tag','fgt_tag','060000043','','2016-10-12 12:04:03','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (502,'6','Insert','fgt_serial','BN601319','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000043\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601319\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 12:04:03\'','2016-10-12 12:04:03','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (503,'6','Insert','fgt_serial','BN701526','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000044\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701526\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:11:36\'','2016-10-12 13:11:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (504,'6','Printed Tag','fgt_tag','060000044','','2016-10-12 13:11:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (505,'6','Insert','fgt_serial','BN701526','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000044\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701526\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:11:36\'','2016-10-12 13:11:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (506,'6','Insert','fgt_serial','BN601316','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000045\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601316\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:12:01\'','2016-10-12 13:12:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (507,'6','Printed Tag','fgt_tag','060000045','','2016-10-12 13:12:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (508,'6','Insert','fgt_serial','BN601316','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000045\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601316\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:12:01\'','2016-10-12 13:12:01','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (509,'6','Printed Tag','fgt_tag','060000045','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000045\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'Print\',tag_qty=\'1\' , date_print=\'2016-10-12 13:12:37\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'45\' ','2016-10-12 13:12:37','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (510,'6','Insert','fgt_serial','BN601319','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000046\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601319\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:13:09\'','2016-10-12 13:13:09','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (511,'6','Printed Tag','fgt_tag','060000046','','2016-10-12 13:13:09','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (512,'6','Insert','fgt_serial','BN601319','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000046\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601319\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:13:09\'','2016-10-12 13:13:09','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (513,'6','Insert','fgt_serial','BN601316','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000047\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601316\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:14:25\'','2016-10-12 13:14:25','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (514,'6','Printed Tag','fgt_tag','060000047','','2016-10-12 13:14:25','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (515,'6','Insert','fgt_serial','BN601316','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000047\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601316\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:14:25\'','2016-10-12 13:14:25','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (516,'6','Insert','fgt_serial','BN601311','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000048\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601311\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:20:53\'','2016-10-12 13:20:53','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (517,'6','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000048\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:20:54\'','2016-10-12 13:20:54','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (518,'6','Insert','fgt_serial','BN601313','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000048\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601313\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:20:55\'','2016-10-12 13:20:55','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (519,'6','Insert','fgt_serial','BN601314','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000048\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601314\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:20:56\'','2016-10-12 13:20:56','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (520,'6','Printed Tag','fgt_tag','060000048','','2016-10-12 13:20:56','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (521,'6','Insert','fgt_serial','BN601315','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000049\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601315\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:22:35\'','2016-10-12 13:22:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (522,'6','Insert','fgt_serial','BN601316','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000049\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601316\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:22:36\'','2016-10-12 13:22:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (523,'6','Printed Tag','fgt_tag','060000049','UPDATE prod_fg_tag.fgt_tag SET sn_end=(SELECT serial_scan_label FROM prod_fg_tag.fgt_serial \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tWHERE tag_no = \'060000049\' ORDER BY id_serial DESC LIMIT 1) , \r\n\t\t\t\t\t\t\t\t\tstatus_print=\'Print\',tag_qty=\'2\' , date_print=\'2016-10-12 13:22:40\'\r\n\t\t\t\t\t\t\t\t\tWHERE id_tag=\'49\' ','2016-10-12 13:22:41','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (524,'6','Insert','fgt_serial','BN701531','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000050\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701531\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:24:33\'','2016-10-12 13:24:33','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (525,'6','Insert','fgt_serial','BN701532','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000050\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701532\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:24:34\'','2016-10-12 13:24:34','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (526,'6','Insert','fgt_serial','BN701533','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000050\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701533\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:24:35\'','2016-10-12 13:24:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (527,'6','Insert','fgt_serial','BN701534','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000050\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701534\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:24:36\'','2016-10-12 13:24:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (528,'6','Waiting','fgt_tag','060000050','','2016-10-12 13:24:39','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (529,'6','Insert','fgt_serial','BN701525','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000050\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701525\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:25:23\'','2016-10-12 13:25:23','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (530,'6','Printed Tag','fgt_tag','060000050','','2016-10-12 13:25:23','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (531,'6','Insert','fgt_serial','BN701535','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000050\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'GB\', serial_scan_label=\'BN701535\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:29:15\'','2016-10-12 13:29:15','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (532,'6','Printed Tag','fgt_tag','060000050','','2016-10-12 13:29:16','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (533,'6','Insert','fgt_serial','BN601311','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000051\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601311\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:38:34\'','2016-10-12 13:38:34','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (534,'6','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000051\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 13:38:36\'','2016-10-12 13:38:36','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (535,'6','Insert','fgt_serial','BN601313','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000051\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601313\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 14:22:12\'','2016-10-12 14:22:12','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (536,'6','Insert','fgt_serial','BN601314','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000051\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601314\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 14:22:14\'','2016-10-12 14:22:14','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (537,'6','Insert','fgt_serial','BN601315','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'060000051\', \r\n\t\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601315\', \r\n\t\t\t\t\t\t\t\t\tdate_scan=\'2016-10-12 14:22:16\'','2016-10-12 14:22:16','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (538,'6','Printed Tag','fgt_tag','060000051','','2016-10-12 14:22:16','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (539,'1972','Print','fgt_supplier_tag','2','','2016-10-20 09:27:51','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (540,'1','Insert','fgt_serial','BN601311','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000052\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601311\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-21 10:29:04\'','2016-10-21 10:29:04','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (541,'1','Insert','fgt_serial','BN601312','INSERT INTO prod_fg_tag.fgt_serial SET  tag_no=\'010000052\', \r\n\t\t\t\t\t\t\t\tmodel_scan_label=\'EW\', serial_scan_label=\'BN601312\', \r\n\t\t\t\t\t\t\t\tdate_scan=\'2016-10-21 10:29:07\'','2016-10-21 10:29:07','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (542,'1972','LGT RePrint','fgt_supplier_tag_spl','7','','2016-10-21 11:28:26','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (543,'1972','LGT RePrint','fgt_supplier_tag_spl','6','','2016-10-21 11:29:42','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (544,'1','Reprinted Tag','fgt_tag','1','','2016-10-21 11:30:55','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (545,'1972','LGT RePrint','fgt_supplier_tag_spl','7','','2016-10-21 11:31:35','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (546,'1972','LGT RePrint','fgt_supplier_tag_spl','6','','2016-10-21 11:35:03','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (547,'1972','LGT RePrint','fgt_supplier_tag_spl','5','','2016-10-21 11:51:11','10.164.214.49',NULL);
INSERT INTO `fgt_log_history` VALUES (548,'1972','LGT RePrint','fgt_supplier_tag_spl','4','','2016-10-21 11:52:05','10.164.214.49',NULL);

#
# Table structure for table fgt_model
#

CREATE TABLE `fgt_model` (
  `id_model` int(4) NOT NULL AUTO_INCREMENT,
  `model_code` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag_model_no` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `label_model_no` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_name` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `std_qty` int(2) DEFAULT NULL,
  `customer` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_part_no` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_part_name` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_picture` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status_tag_printing` int(1) NOT NULL DEFAULT '0' COMMENT '0=both,1=only fg Tag',
  `emp_insert` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_insert` datetime DEFAULT NULL,
  `emp_modify` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id_model`),
  UNIQUE KEY `tag_model_no` (`tag_model_no`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# Dumping data for table fgt_model
#

INSERT INTO `fgt_model` VALUES (1,'33','123001-5940B152','123000-5940B101','T-259MY',1,'TOYOTA ','86120-0K641','SPEAKER','160822113812.jpg',1,NULL,NULL,'1972','2016-08-22 11:38:12');
INSERT INTO `fgt_model` VALUES (2,'32','123001-5940B151','123000-5940B101','T-258MY',2,'TOYOTA ','86120-0K661','SPEAKERs','160901172732.jpg',0,NULL,NULL,'1972','2016-09-07 12:33:14');
INSERT INTO `fgt_model` VALUES (3,'34','123003-5940B102','139001-81200101','T-302MY',4,'TOYOTA ','86120-0K671','SPEAKER','160822114427.jpg',1,NULL,NULL,'1972','2016-08-22 11:44:27');
INSERT INTO `fgt_model` VALUES (4,'37','123000-72500101','123000-72500101','T-361TH',5,'TOYOTA ','86120-0K821','SPEAKER','160822113047.jpg',0,NULL,NULL,'1972','2016-08-22 11:30:47');
INSERT INTO `fgt_model` VALUES (5,'36','123001-6130B151','123000-6130B101','T-415MX',6,'TOYOTA ','86120-0K741','SPEAKER','160822114314.jpg',1,NULL,NULL,'1972','2016-08-22 11:43:14');
INSERT INTO `fgt_model` VALUES (6,'31','123001-5940B154','123000-5940B101','T-261IN',4,'TOYOTA ','86120-0K781','SPEAKER','160822113824.jpg',1,NULL,NULL,'1972','2016-08-22 11:38:24');
INSERT INTO `fgt_model` VALUES (7,'25','123001-6080B103','123000-6080B101','T-263TH',3,'TOYOTA ','86120-0K811','SPEAKER','160822114036.jpg',0,NULL,NULL,'1972','2016-08-22 11:40:36');
INSERT INTO `fgt_model` VALUES (8,'24','123001-6080B151','123000-6080B101','T-325JP',3,'TOYOTA ','86120-0KC11','SPEAKER','160822114043.jpg',1,NULL,NULL,'1972','2016-08-22 11:40:43');
INSERT INTO `fgt_model` VALUES (9,'28','123001-6100B151','123000-6100B101','T-266ID',2,'TOYOTA ','86120-0KA00','SPEAKER','160822114136.jpg',1,NULL,NULL,'1972','2016-08-22 11:41:36');
INSERT INTO `fgt_model` VALUES (10,'30','123002-5940B103','123000-5940B101','T-296PH',4,'TOYOTA ','86120-0KA10','SPEAKER','160822114329.jpg',1,NULL,NULL,'1972','2016-08-22 11:43:29');
INSERT INTO `fgt_model` VALUES (11,'29','123002-5940B102','123000-5940B101','T-295PH',4,'TOYOTA ','86120-0KA20','SPEAKER','160822114322.jpg',1,NULL,NULL,'1972','2016-08-22 11:43:22');
INSERT INTO `fgt_model` VALUES (12,'45','139000-67100151','139000-67100101','T-393SG',4,'TOYOTA ','86120-0KA40','SPEAKER','160822114515.jpg',1,NULL,NULL,'1972','2016-08-22 11:45:15');
INSERT INTO `fgt_model` VALUES (13,'44','139000-67100101','139000-67100101','T-362TH',5,'TOYOTA ','86120-0KA50','SPEAKER','160822114438.jpg',0,NULL,NULL,'1972','2016-08-22 11:44:38');
INSERT INTO `fgt_model` VALUES (14,'46','139000-67100102','139000-67100101','T-424MY',5,'TOYOTA ','86120-0KA80','SPEAKER','160822114448.jpg',1,NULL,NULL,'1972','2016-08-22 11:44:48');
INSERT INTO `fgt_model` VALUES (15,'48','139000-67300151','123001-4870C101','T-426TW',5,'TOYOTA ','86120-0KC40','SPEAKER','160819152847.jpg',1,NULL,NULL,'1972','2016-08-19 15:28:47');
INSERT INTO `fgt_model` VALUES (16,'47','139000-67300101','139000-67300101','T-425TH',4,'GM','86120-0KD20','AUDIO','160819152932.jpg',0,NULL,NULL,'1972','2016-08-19 15:29:32');
INSERT INTO `fgt_model` VALUES (17,'43','123000-72700151','123000-72700101','T-390TW',5,'GM','86120-0KD30','AUDIO','160822113802.jpg',1,NULL,NULL,'1972','2016-08-22 11:38:02');
INSERT INTO `fgt_model` VALUES (18,'39','123000-72500151','123000-72500101','T-423SG',4,'GM','86120-0KD40','AUDIO','160822113334.jpg',1,NULL,NULL,'1972','2016-08-25 16:36:24');
INSERT INTO `fgt_model` VALUES (19,'38','123000-72500102','123000-72500101','T-388TH',4,'GM','PC600-00001','AUDIO','160822113242.jpg',0,NULL,NULL,'1972','2016-08-22 11:32:42');
INSERT INTO `fgt_model` VALUES (20,'40','123000-72500103','123000-72500103','T-422MY',4,'GM','PC600-0D00B','AUDIO','160819152922.jpg',1,NULL,NULL,'1972','2016-08-19 15:29:23');
INSERT INTO `fgt_model` VALUES (21,'42','123000-72700102','123000-72700101','T-427TH',5,'GM','PC600-0D00H','AUDIO','160822113632.jpg',0,NULL,NULL,'1972','2016-08-22 11:36:32');
INSERT INTO `fgt_model` VALUES (22,'41','123000-72500152','123000-72500101','T-389TH',5,'GM','898052 9354','AUDIO','160822113510.jpg',1,NULL,NULL,'1972','2016-08-25 16:38:19');
INSERT INTO `fgt_model` VALUES (23,'11','123002-5950C104','123000-5950C101','T-294PH',5,'GM','52029703','AUDIO','160822114408.jpg',1,NULL,NULL,'1972','2016-08-22 11:44:08');
INSERT INTO `fgt_model` VALUES (24,'9','123002-5950C103','123000-5950C101','T-293TH',10,'GM','52029703','AUDIO','160822114351.jpg',0,NULL,NULL,'1972','2016-08-22 11:43:51');
INSERT INTO `fgt_model` VALUES (25,'12','123000-6090C101','138000-6370E101','T-241TH',10,'GM','898126 0813','AUDIO','160822112721.jpg',1,NULL,NULL,'1972','2016-08-31 11:47:21');
INSERT INTO `fgt_model` VALUES (26,'14','123001-6090C152','138000-6370E101','T-250ID',10,'GM','898171 4812','AUDIO','160819145640.jpg',0,NULL,NULL,'1972','2016-09-07 12:33:40');
INSERT INTO `fgt_model` VALUES (27,'13','123001-6090C151','138000-6370E101','T-249ID',10,'GM','898219 8443','AUDIO','160819153005.jpg',0,NULL,NULL,'1972','2016-09-07 12:33:32');
INSERT INTO `fgt_model` VALUES (28,'5','123001-5950C154','123000-5950C101','T-277BN',15,'GM','898243 6022','AUDIO','160822114002.jpg',1,NULL,NULL,'1972','2016-08-22 11:40:02');
INSERT INTO `fgt_model` VALUES (29,'4','123001-5950C152','123000-5950C101','T-246MY',15,'GM','898243 6012','AUDIO','160822113952.jpg',1,NULL,NULL,'1972','2016-08-22 11:39:52');
INSERT INTO `fgt_model` VALUES (30,'6','123001-5950C15L','123000-5950C101','T-277IN',15,'ISUZU','898243 6032','AUDIO','160822114015.jpg',1,NULL,NULL,'1972','2016-08-22 11:40:15');
INSERT INTO `fgt_model` VALUES (31,'8','123002-5950C102','123000-5950C101','T-292PH',1,'ISUZU','898241 4242','AUDIO','160822114342.jpg',1,NULL,NULL,'1972','2016-08-22 11:43:42');
INSERT INTO `fgt_model` VALUES (32,'7','123001-5950C155','123000-5950C101','T-278IN',15,'ISUZU','898241 3572','SPEAKER','160822114008.jpg',1,NULL,NULL,'1972','2016-08-22 11:40:08');
INSERT INTO `fgt_model` VALUES (33,'18','123001-6110B152','123000-6110B101','T-254ID',16,'ISUZU','PZ071-00A37','SPEAKER','160822114248.jpg',1,NULL,NULL,'1972','2016-08-22 11:42:48');
INSERT INTO `fgt_model` VALUES (34,'19','123001-6110B153','123000-6110B101','T-257ID',16,'ISUZU','PZ071-00A37','SPEAKER','160822114255.jpg',1,NULL,NULL,'1972','2016-08-22 11:42:55');
INSERT INTO `fgt_model` VALUES (35,'17','123001-6110B151','123000-6110B101','T-253ID',16,'ISUZU','PZ071-00A42','SPEAKER','160822114241.jpg',1,NULL,NULL,'1972','2016-08-22 11:42:41');
INSERT INTO `fgt_model` VALUES (36,'20','123000-6110B101','123000-6110B101','T-242TH',5,'ISUZU','898340 5000','SPEAKER','160822112933.jpg',0,NULL,NULL,'4','2016-09-09 15:38:46');
INSERT INTO `fgt_model` VALUES (37,'2','123001-5950C102','123000-5950C101','T-247TH',4,'ISUZU','PZ071-00A39-1C','SPEAKER','160822113833.jpg',0,NULL,NULL,'1972','2016-08-22 11:38:33');
INSERT INTO `fgt_model` VALUES (38,'3','123001-5950C103','123000-5950C101','T-248TH',4,'ISUZU','PZ071-00A39-1D','SPEAKER','160822113848.jpg',0,NULL,NULL,'1972','2016-08-22 11:38:48');
INSERT INTO `fgt_model` VALUES (39,'10','123001-5950C104','123000-5950C101','T-324TH',4,'ISUZU','PC600-BZ001-00','SPEAKER','160822113859.jpg',0,NULL,NULL,'1972','2016-08-22 11:38:59');
INSERT INTO `fgt_model` VALUES (40,'23','123001-6080B102','123000-6080B101','T-262TH',4,'ISUZU','PZ071-00A36-TH','SPEAKER','160822114023.jpg',0,NULL,NULL,'1972','2016-08-22 11:40:23');
INSERT INTO `fgt_model` VALUES (41,'15','123001-6090C102','138000-6370E101','T-251TH',1,'ISUZU','PZ071-00A41-TH','SPEAKER','160822114055.jpg',0,NULL,NULL,'1972','2016-08-22 11:40:55');
INSERT INTO `fgt_model` VALUES (42,'16','123001-6090C103','138000-6370E101','T-252TH',2,'ISUZU','PZ071-00A41-GW','SPEAKER','160822114103.jpg',0,NULL,NULL,'1972','2016-08-22 11:41:03');
INSERT INTO `fgt_model` VALUES (43,'26','123001-6100B102','123000-6100B101','T-264TH',4,'ISUZU','PZ071-00A37-GW','SPEAKER','160822114112.jpg',0,NULL,NULL,'1972','2016-08-22 11:41:12');
INSERT INTO `fgt_model` VALUES (44,'27','123001-6100B103','123000-6100B101','T-265TH',4,'ISUZU','PZ071-00A37-TH','SPEAKER','160822114128.jpg',0,NULL,NULL,'1972','2016-08-22 11:41:28');
INSERT INTO `fgt_model` VALUES (45,'21','123001-6110B102','123000-6110B101','T-255TH',4,'ISUZU','PZ071-00A42-00','SPEAKER','160822114227.jpg',0,NULL,NULL,'1972','2016-08-22 11:42:27');
INSERT INTO `fgt_model` VALUES (46,'22','123001-6110B103','123000-6110B101','T-256TH',5,'ISUZU','PZ071-00A42-GW','SPEAKER','160822114235.jpg',0,NULL,NULL,'1972','2016-08-22 11:42:35');
INSERT INTO `fgt_model` VALUES (48,'35','123001-6130B102','123000-6130B101','T-271TH',5,'ISUZU','PZ071-00A43-TH','SPEAKER','160822114304.jpg',0,NULL,NULL,'1972','2016-08-22 11:43:04');
INSERT INTO `fgt_model` VALUES (49,'1','123001-5950C151','138000-6350F101','T-245VN',6,'ISUZU','812000-2214652','SPEAKER','160819152940.jpg',0,NULL,NULL,'1972','2016-09-07 12:34:45');

#
# Table structure for table fgt_serial
#

CREATE TABLE `fgt_serial` (
  `id_serial` int(11) NOT NULL AUTO_INCREMENT,
  `tag_no` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_scan_label` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial_scan_label` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_scan` datetime DEFAULT NULL,
  PRIMARY KEY (`id_serial`),
  KEY `tag_no` (`tag_no`)
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# Dumping data for table fgt_serial
#

INSERT INTO `fgt_serial` VALUES (1,'010000001','123001-4870C101','BN600331','2016-07-26 13:22:51');
INSERT INTO `fgt_serial` VALUES (2,'010000001','123001-4870C101','BN600332','2016-07-26 13:22:53');
INSERT INTO `fgt_serial` VALUES (3,'010000001','123001-4870C101','BN600333','2016-07-26 13:22:54');
INSERT INTO `fgt_serial` VALUES (4,'010000001','123001-4870C101','BN600334','2016-07-26 13:22:58');
INSERT INTO `fgt_serial` VALUES (5,'010000001','123001-4870C101','BN600335','2016-07-26 13:22:59');
INSERT INTO `fgt_serial` VALUES (6,'010000002','138000-6350F101','BN700017','2016-07-26 13:29:30');
INSERT INTO `fgt_serial` VALUES (7,'010000002','138000-6350F101','BN700018','2016-07-26 13:29:34');
INSERT INTO `fgt_serial` VALUES (8,'010000002','138000-6350F101','BN700019','2016-07-26 13:29:41');
INSERT INTO `fgt_serial` VALUES (9,'010000002','138000-6350F101','BN700020','2016-07-26 13:29:43');
INSERT INTO `fgt_serial` VALUES (10,'010000002','138000-6350F101','BN700021','2016-07-26 13:29:45');
INSERT INTO `fgt_serial` VALUES (12,'010000003','','BN601311','2016-07-26 13:33:39');
INSERT INTO `fgt_serial` VALUES (13,'010000003','','BN601312','2016-07-26 13:33:41');
INSERT INTO `fgt_serial` VALUES (14,'010000003','','BN601313','2016-07-26 13:33:42');
INSERT INTO `fgt_serial` VALUES (15,'010000003','','BN601314','2016-07-26 13:33:46');
INSERT INTO `fgt_serial` VALUES (16,'010000004','139000-67300101','BN600377','2016-07-26 14:01:54');
INSERT INTO `fgt_serial` VALUES (17,'010000004','139000-67300101','BN600378','2016-07-26 14:01:55');
INSERT INTO `fgt_serial` VALUES (18,'010000004','139000-67300101','BN600379','2016-07-26 14:01:57');
INSERT INTO `fgt_serial` VALUES (19,'010000004','139000-67300101','BN600380','2016-07-26 14:02:00');
INSERT INTO `fgt_serial` VALUES (20,'010000005','138000-6350F101','BN700021','2016-07-26 14:59:52');
INSERT INTO `fgt_serial` VALUES (21,'010000005','138000-6350F101','BN700022','2016-07-27 15:00:12');
INSERT INTO `fgt_serial` VALUES (22,'010000006','138000-6350F101','BN700016','2016-07-27 15:10:59');
INSERT INTO `fgt_serial` VALUES (23,'010000006','138000-6350F101','BN700017','2016-07-27 15:11:01');
INSERT INTO `fgt_serial` VALUES (24,'010000006','138000-6350F101','BN700018','2016-07-27 15:11:04');
INSERT INTO `fgt_serial` VALUES (25,'010000006','138000-6350F101','BN700019','2016-07-27 15:11:08');
INSERT INTO `fgt_serial` VALUES (26,'010000006','138000-6350F101','BN700020','2016-07-27 15:11:10');
INSERT INTO `fgt_serial` VALUES (27,'010000006','138000-6350F101','BN700021','2016-07-27 15:11:13');
INSERT INTO `fgt_serial` VALUES (28,'010000007','123001-4870C101','BN600331','2016-07-27 15:12:23');
INSERT INTO `fgt_serial` VALUES (29,'010000007','123001-4870C101','BN600332','2016-07-27 15:12:25');
INSERT INTO `fgt_serial` VALUES (30,'010000007','123001-4870C101','BN600333','2016-07-27 15:12:26');
INSERT INTO `fgt_serial` VALUES (31,'010000008','139000-67300101','BN600377','2016-07-27 16:06:13');
INSERT INTO `fgt_serial` VALUES (32,'010000008','139000-67300101','BN600378','2016-07-27 16:06:15');
INSERT INTO `fgt_serial` VALUES (33,'010000008','139000-67300101','BN600379','2016-07-27 16:06:16');
INSERT INTO `fgt_serial` VALUES (34,'020000009','EW','BN601311','2016-07-28 08:22:09');
INSERT INTO `fgt_serial` VALUES (35,'020000009','EW','BN601312','2016-07-28 08:22:11');
INSERT INTO `fgt_serial` VALUES (36,'020000009','EW','BN601313','2016-07-28 08:22:13');
INSERT INTO `fgt_serial` VALUES (37,'020000009','EW','BN601314','2016-07-28 08:22:14');
INSERT INTO `fgt_serial` VALUES (38,'020000009','EW','BN601315','2016-07-28 08:22:15');
INSERT INTO `fgt_serial` VALUES (39,'020000009','EW','BN601316','2016-07-28 08:22:18');
INSERT INTO `fgt_serial` VALUES (40,'020000009','EW','BN601317','2016-07-28 08:22:19');
INSERT INTO `fgt_serial` VALUES (41,'020000009','EW','BN601318','2016-07-28 08:22:21');
INSERT INTO `fgt_serial` VALUES (42,'020000009','EW','BN601319','2016-07-28 08:22:21');
INSERT INTO `fgt_serial` VALUES (44,'020000009','EW','BN601320','2016-07-28 09:02:42');
INSERT INTO `fgt_serial` VALUES (45,'010000005','138000-6350F101','BN700023','2016-07-28 09:42:51');
INSERT INTO `fgt_serial` VALUES (46,'010000005','138000-6350F101','BN700024','2016-07-28 09:42:54');
INSERT INTO `fgt_serial` VALUES (47,'010000005','138000-6350F101','BN700025','2016-07-28 09:42:56');
INSERT INTO `fgt_serial` VALUES (48,'010000005','138000-6350F101','BN700026','2016-07-28 09:42:58');
INSERT INTO `fgt_serial` VALUES (49,'050000010','EW','BN601311','2016-08-01 09:18:46');
INSERT INTO `fgt_serial` VALUES (50,'050000010','EW','BN601312','2016-08-01 09:18:47');
INSERT INTO `fgt_serial` VALUES (51,'050000010','EW','BN601313','2016-08-01 09:18:49');
INSERT INTO `fgt_serial` VALUES (52,'050000010','EW','BN601314','2016-08-01 09:18:52');
INSERT INTO `fgt_serial` VALUES (53,'050000011','138000-6370E101','BN700002','2016-08-01 11:23:44');
INSERT INTO `fgt_serial` VALUES (54,'050000011','138000-6370E101','BN700003','2016-08-01 11:23:48');
INSERT INTO `fgt_serial` VALUES (55,'050000011','138000-6370E101','BN700004','2016-08-01 11:24:19');
INSERT INTO `fgt_serial` VALUES (56,'050000011','138000-6370E101','BN700005','2016-08-01 11:24:23');
INSERT INTO `fgt_serial` VALUES (57,'050000012','GB','BN701529','2016-08-01 11:25:36');
INSERT INTO `fgt_serial` VALUES (59,'050000010','EW','BN601315','2016-08-08 16:33:10');
INSERT INTO `fgt_serial` VALUES (60,'050000010','EW','BN601316','2016-08-08 16:33:18');
INSERT INTO `fgt_serial` VALUES (61,'050000011','138000-6370E101','BN700003','2016-08-17 16:07:50');
INSERT INTO `fgt_serial` VALUES (62,'050000011','138000-6370E101','BN700007','2016-08-17 16:07:57');
INSERT INTO `fgt_serial` VALUES (63,'050000011','138000-6370E101','BN700008','2016-08-17 16:07:59');
INSERT INTO `fgt_serial` VALUES (66,'050000011','138000-6370E101','BN700009','2016-08-17 16:08:58');
INSERT INTO `fgt_serial` VALUES (69,'050000011','138000-6370E101','BN700010','2016-08-17 16:20:01');
INSERT INTO `fgt_serial` VALUES (72,'050000011','EW','BN601310','2016-08-17 16:41:39');
INSERT INTO `fgt_serial` VALUES (73,'040000013','138000-6350F101','BN700017','2016-08-18 13:40:14');
INSERT INTO `fgt_serial` VALUES (74,'040000013','138000-6350F101','BN700018','2016-08-18 13:40:17');
INSERT INTO `fgt_serial` VALUES (75,'040000013','138000-6350F101','BN700019','2016-08-18 13:40:19');
INSERT INTO `fgt_serial` VALUES (77,'040000013','138000-6350F101','BN700020','2016-08-18 13:40:48');
INSERT INTO `fgt_serial` VALUES (78,'040000013','138000-6350F101','BN700021','2016-08-18 13:40:52');
INSERT INTO `fgt_serial` VALUES (79,'040000013','138000-6350F101','BN700022','2016-08-18 13:40:54');
INSERT INTO `fgt_serial` VALUES (80,'020000014','138000-6350F101','BN700017','2016-08-19 14:33:56');
INSERT INTO `fgt_serial` VALUES (81,'020000014','138000-6350F101','BN700018','2016-08-19 14:33:58');
INSERT INTO `fgt_serial` VALUES (82,'020000014','138000-6350F101','BN700019','2016-08-19 14:33:59');
INSERT INTO `fgt_serial` VALUES (83,'020000014','138000-6350F101','BN700020','2016-08-19 14:34:01');
INSERT INTO `fgt_serial` VALUES (84,'020000014','138000-6350F101','BN700021','2016-08-19 14:34:03');
INSERT INTO `fgt_serial` VALUES (85,'020000014','138000-6350F101','BN700022','2016-08-19 14:34:04');
INSERT INTO `fgt_serial` VALUES (86,'010000017','EW','BN601311','2016-09-01 09:18:47');
INSERT INTO `fgt_serial` VALUES (87,'010000017','EW','BN601312','2016-09-01 09:18:50');
INSERT INTO `fgt_serial` VALUES (88,'010000018','138000-6370E101','BN700002','2016-09-01 13:42:40');
INSERT INTO `fgt_serial` VALUES (89,'010000018','138000-6370E101','BN700003','2016-09-01 13:42:47');
INSERT INTO `fgt_serial` VALUES (90,'010000018','138000-6370E101','BN700004','2016-09-01 13:42:49');
INSERT INTO `fgt_serial` VALUES (91,'010000018','138000-6370E101','BN700005','2016-09-01 13:42:50');
INSERT INTO `fgt_serial` VALUES (92,'010000018','138000-6370E101','BN700006','2016-09-02 16:11:19');
INSERT INTO `fgt_serial` VALUES (93,'010000018','138000-6370E101','BN700007','2016-09-02 16:11:25');
INSERT INTO `fgt_serial` VALUES (94,'010000018','138000-6370E101','BN700008','2016-09-02 16:11:29');
INSERT INTO `fgt_serial` VALUES (95,'010000018','138000-6370E101','BN700009','2016-09-02 16:11:32');
INSERT INTO `fgt_serial` VALUES (96,'010000018','138000-6370E101','BN700010','2016-09-02 16:11:35');
INSERT INTO `fgt_serial` VALUES (99,'010000018','138000-6370E101','BN700011','2016-09-02 16:39:08');
INSERT INTO `fgt_serial` VALUES (102,'060000019','GC','BN800151','2016-09-06 13:45:18');
INSERT INTO `fgt_serial` VALUES (106,'060000019','GC','BN800152','2016-09-06 14:45:55');
INSERT INTO `fgt_serial` VALUES (107,'010000020','138000-6350F101','BN700017','2016-09-06 14:47:12');
INSERT INTO `fgt_serial` VALUES (108,'010000020','138000-6350F101','BN700018','2016-09-06 14:47:15');
INSERT INTO `fgt_serial` VALUES (109,'010000020','138000-6350F101','BN700019','2016-09-06 14:47:19');
INSERT INTO `fgt_serial` VALUES (110,'010000020','138000-6350F101','BN700020','2016-09-06 14:47:22');
INSERT INTO `fgt_serial` VALUES (111,'010000020','138000-6350F101','BN700021','2016-09-06 14:47:25');
INSERT INTO `fgt_serial` VALUES (112,'010000020','138000-6350F101','BN700022','2016-09-06 14:47:28');
INSERT INTO `fgt_serial` VALUES (113,'060000021','138000-6350F101','BN700017','2016-09-07 11:35:00');
INSERT INTO `fgt_serial` VALUES (114,'060000021','138000-6350F101','BN700018','2016-09-07 11:35:03');
INSERT INTO `fgt_serial` VALUES (115,'060000021','138000-6350F101','BN700019','2016-09-07 11:35:05');
INSERT INTO `fgt_serial` VALUES (116,'060000021','138000-6350F101','BN700020','2016-09-07 11:35:07');
INSERT INTO `fgt_serial` VALUES (117,'060000021','138000-6350F101','BN700021','2016-09-07 11:35:08');
INSERT INTO `fgt_serial` VALUES (120,'060000021','138000-6350F101','BN700022','2016-09-07 11:41:01');
INSERT INTO `fgt_serial` VALUES (121,'010000022','EW','BN601311','2016-09-07 11:43:22');
INSERT INTO `fgt_serial` VALUES (122,'010000022','EW','BN601312','2016-09-07 11:43:24');
INSERT INTO `fgt_serial` VALUES (123,'010000022','EW','BN601313','2016-09-07 11:43:27');
INSERT INTO `fgt_serial` VALUES (124,'010000022','EW','BN601314','2016-09-07 11:43:29');
INSERT INTO `fgt_serial` VALUES (125,'050000012','GB','BN701530','2016-09-07 11:44:57');
INSERT INTO `fgt_serial` VALUES (126,'040000024','138000-6370E101','BN700005','2016-09-07 11:46:11');
INSERT INTO `fgt_serial` VALUES (127,'040000024','138000-6370E101','BN700003','2016-09-07 11:46:13');
INSERT INTO `fgt_serial` VALUES (128,'040000024','138000-6370E101','BN700004','2016-09-07 11:46:15');
INSERT INTO `fgt_serial` VALUES (129,'040000024','138000-6370E101','BN700005','2016-09-07 11:46:17');
INSERT INTO `fgt_serial` VALUES (130,'040000024','138000-6370E101','BN700006','2016-09-07 11:46:18');
INSERT INTO `fgt_serial` VALUES (131,'040000024','138000-6370E101','BN700007','2016-09-07 11:46:19');
INSERT INTO `fgt_serial` VALUES (132,'040000024','138000-6370E101','BN700008','2016-09-07 11:46:20');
INSERT INTO `fgt_serial` VALUES (133,'040000024','138000-6370E101','BN700009','2016-09-07 11:46:21');
INSERT INTO `fgt_serial` VALUES (134,'040000024','138000-6370E101','BN700010','2016-09-07 11:46:22');
INSERT INTO `fgt_serial` VALUES (135,'040000024','138000-6370E101','BN700011','2016-09-07 11:46:57');
INSERT INTO `fgt_serial` VALUES (136,'040000025','GD','BN904524','2016-09-07 11:49:44');
INSERT INTO `fgt_serial` VALUES (137,'040000025','GD','BN904525','2016-09-07 11:49:46');
INSERT INTO `fgt_serial` VALUES (138,'040000025','GD','BN904526','2016-09-07 11:49:46');
INSERT INTO `fgt_serial` VALUES (139,'040000025','GD','BN904527','2016-09-07 11:49:48');
INSERT INTO `fgt_serial` VALUES (140,'010000002','138000-6350F101','BN700022','2016-09-07 13:30:05');
INSERT INTO `fgt_serial` VALUES (141,'010000023','138000-6370E101','BN700002','2016-09-08 11:33:28');
INSERT INTO `fgt_serial` VALUES (142,'010000023','138000-6370E101','BN700003','2016-09-09 14:02:14');
INSERT INTO `fgt_serial` VALUES (143,'010000023','138000-6370E101','BN700004','2016-09-09 14:02:35');
INSERT INTO `fgt_serial` VALUES (144,'010000023','138000-6370E101','BN700005','2016-09-09 14:02:36');
INSERT INTO `fgt_serial` VALUES (145,'010000023','138000-6370E101','BN700006','2016-09-09 14:02:38');
INSERT INTO `fgt_serial` VALUES (146,'010000023','138000-6370E101','BN700007','2016-09-09 14:02:39');
INSERT INTO `fgt_serial` VALUES (147,'010000023','138000-6370E101','BN700008','2016-09-09 14:02:40');
INSERT INTO `fgt_serial` VALUES (148,'010000023','138000-6370E101','BN700009','2016-09-09 14:02:42');
INSERT INTO `fgt_serial` VALUES (149,'010000023','138000-6370E101','BN700010','2016-09-09 14:02:44');
INSERT INTO `fgt_serial` VALUES (150,'010000023','138000-6370E101','BN700011','2016-09-09 14:02:48');
INSERT INTO `fgt_serial` VALUES (151,'030000026','EW','BN601312','2016-09-09 14:13:27');
INSERT INTO `fgt_serial` VALUES (152,'030000026','EW','BN601313','2016-09-09 14:13:30');
INSERT INTO `fgt_serial` VALUES (153,'030000026','EW','BN601314','2016-09-09 14:13:31');
INSERT INTO `fgt_serial` VALUES (154,'030000026','EW','BN601315','2016-09-09 14:13:32');
INSERT INTO `fgt_serial` VALUES (155,'040000027','GB','BN701529','2016-09-09 14:40:10');
INSERT INTO `fgt_serial` VALUES (156,'040000027','GB','BN701530','2016-09-09 14:40:12');
INSERT INTO `fgt_serial` VALUES (157,'040000027','GB','BN701531','2016-09-09 14:40:13');
INSERT INTO `fgt_serial` VALUES (158,'040000027','GB','BN701532','2016-09-09 14:40:13');
INSERT INTO `fgt_serial` VALUES (159,'040000027','GB','BN701533','2016-09-09 14:40:14');
INSERT INTO `fgt_serial` VALUES (160,'040000028','GB','BN701529','2016-09-09 14:45:14');
INSERT INTO `fgt_serial` VALUES (161,'030000029','EW','BN601311','2016-09-12 13:53:10');
INSERT INTO `fgt_serial` VALUES (162,'030000029','EW','BN601312','2016-09-12 13:53:11');
INSERT INTO `fgt_serial` VALUES (163,'030000029','EW','BN601313','2016-09-12 13:53:12');
INSERT INTO `fgt_serial` VALUES (164,'030000029','EW','BN601314','2016-09-12 13:53:12');
INSERT INTO `fgt_serial` VALUES (165,'030000029','EW','BN601315','2016-09-12 13:53:13');
INSERT INTO `fgt_serial` VALUES (166,'030000030','139000-67300101','BN600377','2016-10-07 08:59:49');
INSERT INTO `fgt_serial` VALUES (167,'030000030','139000-67300101','BN600378','2016-10-07 08:59:54');
INSERT INTO `fgt_serial` VALUES (168,'030000030','139000-67300101','BN600379','2016-10-07 09:03:35');
INSERT INTO `fgt_serial` VALUES (169,'030000030','139000-67300101','BN600380','2016-10-07 09:04:43');
INSERT INTO `fgt_serial` VALUES (170,'060000032','GC','BN800148','2016-10-11 16:40:52');
INSERT INTO `fgt_serial` VALUES (171,'060000033','GB','BN701533','2016-10-11 17:17:58');
INSERT INTO `fgt_serial` VALUES (172,'060000034','GC','BN800150','2016-10-12 08:57:21');
INSERT INTO `fgt_serial` VALUES (175,'060000031','EW','BN601311','2016-10-12 10:49:11');
INSERT INTO `fgt_serial` VALUES (176,'060000031','EW','BN601312','2016-10-12 10:49:12');
INSERT INTO `fgt_serial` VALUES (177,'060000035','GB','BN701526','2016-10-12 11:56:47');
INSERT INTO `fgt_serial` VALUES (178,'060000036','GB','BN701529','2016-10-12 11:57:37');
INSERT INTO `fgt_serial` VALUES (179,'060000037','GB','BN701534','2016-10-12 11:59:35');
INSERT INTO `fgt_serial` VALUES (180,'060000038','GB','BN701532','2016-10-12 12:00:22');
INSERT INTO `fgt_serial` VALUES (181,'060000039','GB','BN701532','2016-10-12 12:00:50');
INSERT INTO `fgt_serial` VALUES (182,'060000040','EW','BN601319','2016-10-12 12:02:12');
INSERT INTO `fgt_serial` VALUES (183,'060000041','GB','BN701526','2016-10-12 12:03:04');
INSERT INTO `fgt_serial` VALUES (184,'060000042','EW','BN601316','2016-10-12 12:03:22');
INSERT INTO `fgt_serial` VALUES (185,'060000043','EW','BN601319','2016-10-12 12:04:03');
INSERT INTO `fgt_serial` VALUES (186,'060000044','GB','BN701526','2016-10-12 13:11:36');
INSERT INTO `fgt_serial` VALUES (187,'060000045','EW','BN601316','2016-10-12 13:12:01');
INSERT INTO `fgt_serial` VALUES (188,'060000046','EW','BN601319','2016-10-12 13:13:09');
INSERT INTO `fgt_serial` VALUES (189,'060000047','EW','BN601316','2016-10-12 13:14:25');
INSERT INTO `fgt_serial` VALUES (190,'060000048','EW','BN601311','2016-10-12 13:20:53');
INSERT INTO `fgt_serial` VALUES (191,'060000048','EW','BN601312','2016-10-12 13:20:54');
INSERT INTO `fgt_serial` VALUES (192,'060000048','EW','BN601313','2016-10-12 13:20:55');
INSERT INTO `fgt_serial` VALUES (193,'060000048','EW','BN601314','2016-10-12 13:20:56');
INSERT INTO `fgt_serial` VALUES (194,'060000049','EW','BN601315','2016-10-12 13:22:35');
INSERT INTO `fgt_serial` VALUES (195,'060000049','EW','BN601316','2016-10-12 13:22:36');
INSERT INTO `fgt_serial` VALUES (196,'060000050','GB','BN701531','2016-10-12 13:24:33');
INSERT INTO `fgt_serial` VALUES (197,'060000050','GB','BN701532','2016-10-12 13:24:34');
INSERT INTO `fgt_serial` VALUES (198,'060000050','GB','BN701533','2016-10-12 13:24:35');
INSERT INTO `fgt_serial` VALUES (199,'060000050','GB','BN701534','2016-10-12 13:24:36');
INSERT INTO `fgt_serial` VALUES (201,'060000050','GB','BN701535','2016-10-12 13:29:15');
INSERT INTO `fgt_serial` VALUES (202,'060000051','EW','BN601311','2016-10-12 13:38:34');
INSERT INTO `fgt_serial` VALUES (203,'060000051','EW','BN601312','2016-10-12 13:38:36');
INSERT INTO `fgt_serial` VALUES (204,'060000051','EW','BN601313','2016-10-12 14:22:12');
INSERT INTO `fgt_serial` VALUES (205,'060000051','EW','BN601314','2016-10-12 14:22:14');
INSERT INTO `fgt_serial` VALUES (206,'060000051','EW','BN601315','2016-10-12 14:22:16');
INSERT INTO `fgt_serial` VALUES (207,'010000052','EW','BN601311','2016-10-21 10:29:04');
INSERT INTO `fgt_serial` VALUES (208,'010000052','EW','BN601312','2016-10-21 10:29:07');

#
# Table structure for table fgt_srv_serial
#

CREATE TABLE `fgt_srv_serial` (
  `id_serial` int(11) NOT NULL AUTO_INCREMENT,
  `tag_no` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_scan_label` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial_scan_label` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_scan` datetime DEFAULT NULL,
  PRIMARY KEY (`id_serial`),
  KEY `tag_no` (`tag_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# Dumping data for table fgt_srv_serial
#


#
# Table structure for table fgt_srv_tag
#

CREATE TABLE `fgt_srv_tag` (
  `id_tag` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(2) DEFAULT NULL,
  `tag_no` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_model` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_kanban` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shift` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sn_start` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sn_end` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag_qty` int(2) DEFAULT NULL,
  `fg_tag_barcode` varchar(24) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status_print` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Not yet,Print,Reprint,Wait',
  `date_insert` datetime DEFAULT NULL,
  `date_print` datetime DEFAULT NULL,
  `who_reprint` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_reprint` datetime DEFAULT NULL,
  `status_fg_reprint` int(1) NOT NULL DEFAULT '0',
  `date_fg_reprint` datetime DEFAULT NULL,
  `who_upload` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_upload` datetime DEFAULT NULL,
  PRIMARY KEY (`id_tag`),
  UNIQUE KEY `tag_no` (`tag_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# Dumping data for table fgt_srv_tag
#

INSERT INTO `fgt_srv_tag` VALUES (1,1,'201111','1','2121','Day','121','125',4,'121212151','1','2011-11-11','2011-11-11','A-1','2011-11-11',0,NULL,'A-1','2011-11-11');

#
# Table structure for table fgt_srv_update
#

CREATE TABLE `fgt_srv_update` (
  `id_update` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_action` int(4) DEFAULT NULL,
  `type_data` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'model or btw',
  `path` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'data or file or picture etc.',
  `fname` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'path or folder',
  `version` int(3) NOT NULL DEFAULT '0',
  `emp_insert` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_insert` datetime DEFAULT NULL,
  PRIMARY KEY (`id_update`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# Dumping data for table fgt_srv_update
#

INSERT INTO `fgt_srv_update` VALUES (1,'Insert',5,'Model','Picture','picmodel',1,'1972','2011-11-11');
INSERT INTO `fgt_srv_update` VALUES (2,'Update',25,'Model','Data','',0,'1972','2016-08-31 11:47:21');
INSERT INTO `fgt_srv_update` VALUES (3,'Update',2,'Model','Picture','picmodel',0,'1972','2016-09-01 17:24:25');
INSERT INTO `fgt_srv_update` VALUES (4,'Update',2,'Model','data','',0,'1972','2016-09-01 17:26:55');
INSERT INTO `fgt_srv_update` VALUES (5,'Update',2,'Model','picmodel','160901172732.jpg',0,'1972','2016-09-01 17:27:33');
INSERT INTO `fgt_srv_update` VALUES (6,'Update',2,'Model','data','',0,'1972','2016-09-01 17:28:54');
INSERT INTO `fgt_srv_update` VALUES (7,'Update',2,'Model','data','',0,'1972','2016-09-01 17:28:58');
INSERT INTO `fgt_srv_update` VALUES (8,'Update',2,'Model','data','',0,'1972','2016-09-01 17:29:36');
INSERT INTO `fgt_srv_update` VALUES (9,'Update',2,'Model','data','',0,'1972','2016-09-01 17:30:43');
INSERT INTO `fgt_srv_update` VALUES (10,'Update',2,'Model','data','',2,'1972','2016-09-01 17:31:18');
INSERT INTO `fgt_srv_update` VALUES (11,'Update',1,'Model','picmodel','picmodel.jpg',0,'1972','2014-11-11');
INSERT INTO `fgt_srv_update` VALUES (12,'Update',2,'Model','data','',3,'1972','2016-09-07 12:33:14');
INSERT INTO `fgt_srv_update` VALUES (13,'Update',27,'Model','data','',4,'1972','2016-09-07 12:33:32');
INSERT INTO `fgt_srv_update` VALUES (14,'Update',26,'Model','data','',5,'1972','2016-09-07 12:33:40');
INSERT INTO `fgt_srv_update` VALUES (15,'Update',49,'Model','data','',6,'1972','2016-09-07 12:34:45');
INSERT INTO `fgt_srv_update` VALUES (16,'Update',36,'Model','data','',7,'4','2016-09-09 15:38:46');

#
# Table structure for table fgt_supplier_tag
#

CREATE TABLE `fgt_supplier_tag` (
  `id_print_tag` int(11) NOT NULL AUTO_INCREMENT,
  `id_model` int(4) DEFAULT NULL,
  `tag_qty` int(2) DEFAULT NULL,
  `separate_qty` int(2) DEFAULT NULL,
  `emp_insert` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_insert` datetime DEFAULT NULL,
  `print_status` int(1) NOT NULL DEFAULT '0' COMMENT '0=not yet, 1 = print , 2 = reprint',
  `emp_print` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_print` datetime DEFAULT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0' COMMENT 'cancel',
  PRIMARY KEY (`id_print_tag`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# Dumping data for table fgt_supplier_tag
#

INSERT INTO `fgt_supplier_tag` VALUES (1,36,2,2,'1972','2016-10-11 16:12:18',1,'1972','2016-10-11 16:13:57',0);
INSERT INTO `fgt_supplier_tag` VALUES (2,21,3,3,'1972','2016-10-20 09:27:33',1,'1972','2016-10-20 09:27:51',0);
INSERT INTO `fgt_supplier_tag` VALUES (3,2,1,1,'1972','2016-10-20 10:47:44',0,NULL,NULL,0);

#
# Table structure for table fgt_supplier_tag_split
#

CREATE TABLE `fgt_supplier_tag_split` (
  `id_split` int(11) NOT NULL AUTO_INCREMENT,
  `id_print_tag` int(11) DEFAULT NULL,
  `tag_no` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sn_start` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sn_end` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stag_qty` int(2) DEFAULT NULL,
  `emp_print` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_print` datetime DEFAULT NULL,
  `emp_reprint` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_reprint` datetime DEFAULT NULL,
  PRIMARY KEY (`id_split`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# Dumping data for table fgt_supplier_tag_split
#

INSERT INTO `fgt_supplier_tag_split` VALUES (1,1,'030000029','BN601311','BN601312',2,'1972','2016-10-20 09:27:33',NULL,NULL);
INSERT INTO `fgt_supplier_tag_split` VALUES (2,1,'030000029','BN601313','BN601314',2,'1972','2016-10-20 09:27:33',NULL,NULL);
INSERT INTO `fgt_supplier_tag_split` VALUES (3,1,'030000029','BN601315','BN601315',1,'1972','2016-10-20 09:27:33',NULL,NULL);
INSERT INTO `fgt_supplier_tag_split` VALUES (4,2,'060000051','BN601311','BN601313',3,'1972','2016-10-20 09:27:33','1972','2016-10-21 11:52:05');
INSERT INTO `fgt_supplier_tag_split` VALUES (5,2,'060000051','BN601314','BN601315',2,'1972','2016-10-20 09:27:33','1972','2016-10-21 11:51:11');
INSERT INTO `fgt_supplier_tag_split` VALUES (6,2,'060000050','BN701531','BN701533',3,'1972','2016-10-20 09:27:33','1972','2016-10-21 11:35:03');
INSERT INTO `fgt_supplier_tag_split` VALUES (7,2,'060000050','BN701534','BN701535',2,'1972','2016-10-20 09:27:33','1972','2016-10-21 11:31:35');
INSERT INTO `fgt_supplier_tag_split` VALUES (8,3,'060000031','BN601311','BN601311',1,NULL,NULL,NULL,NULL);
INSERT INTO `fgt_supplier_tag_split` VALUES (9,3,'060000031','BN601312','BN601312',1,NULL,NULL,NULL,NULL);

#
# Table structure for table fgt_tag
#

CREATE TABLE `fgt_tag` (
  `id_tag` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(2) DEFAULT NULL,
  `tag_no` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_model` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_kanban` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shift` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sn_start` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sn_end` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag_qty` int(2) DEFAULT NULL,
  `fg_tag_barcode` varchar(24) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status_print` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Not yet,Print,Reprint,Wait',
  `date_insert` datetime DEFAULT NULL,
  `date_print` datetime DEFAULT NULL,
  `who_reprint` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_reprint` datetime DEFAULT NULL,
  `status_fg_reprint` int(1) NOT NULL DEFAULT '0',
  `date_fg_reprint` datetime DEFAULT NULL,
  `upload_status` int(1) NOT NULL DEFAULT '0',
  `who_upload` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_upload` datetime DEFAULT NULL,
  PRIMARY KEY (`id_tag`),
  UNIQUE KEY `tag_no` (`tag_no`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# Dumping data for table fgt_tag
#

INSERT INTO `fgt_tag` VALUES (1,1,'010000001','15','139000-67300151','Day','BN600331','BN600335',5,'20160726010000001','Reprinted','2016-07-26 13:22:48','2016-07-26 13:22:48','A-1','2016-10-21 11:30:55',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (2,1,'010000002','49','123001-5950C151','Day','BN700017','BN700022',6,'20160726010000002','Reprinted','2016-07-26 13:29:23','2016-09-07 13:30:05','A-1','2016-10-05 16:22:12',0,'2016-10-11 15:17:23',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (3,1,'010000003','20','123000-72500103','Day','BN601311','BN601314',4,'20160726010000003','Reprinted','2016-07-26 13:33:36',NULL,'A-1','2016-10-05 16:22:14',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (4,1,'010000004','16','139000-67300101','Day','BN600377','BN600380',4,'20160726010000004','Reprinted','2016-07-26 14:01:50',NULL,'A-1','2016-10-05 16:22:16',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (5,1,'010000005','49','123001-5950C151','Day','BN700021','BN700026',6,'20160726010000005','Reprinted','2016-07-26 14:59:27',NULL,'A-1','2016-09-26 16:16:07',0,'2016-10-11 15:17:23',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (6,1,'010000006','49','123001-5950C151','Day','BN700017','BN700021',6,'20160727010000006','Reprinted','2016-07-27 15:10:43',NULL,'A-1','2016-10-05 16:22:19',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (7,1,'010000007','15','139000-67300151','Day','BN600331','BN700021',3,'20160727010000007','Reprinted','2016-07-27 15:12:20',NULL,'A-1','2016-10-05 16:22:21',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (8,1,'010000008','16','139000-67300101','Day','BN600377','BN600379',3,'20160727010000008','Reprinted','2016-07-27 16:05:58',NULL,'A-1','2016-10-05 16:22:58',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (9,2,'020000009','26','123001-6090C152','Day','BN601311','BN601320',10,'20160728020000009','Reprinted','2016-07-28 08:16:48','2016-07-28 08:16:48','FA-1','2016-10-05 16:19:32',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (10,5,'050000010','49','123001-5950C151','Day','BN601311','BN601316',6,'20160801050000010','Reprinted','2016-08-01 09:18:03','2016-08-08 16:33:18','A-2','2016-10-05 16:23:35',0,'2016-10-11 15:17:23',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (11,5,'050000011','27','123001-6090C151','Day','BN700002','BN601310',10,'20160801050000011','Reprinted','2016-08-01 11:23:34','2016-08-17 16:41:39','A-2','2016-10-05 16:23:37',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (12,5,'050000012','2','123001-5940B151','Day','BN701529','BN701530',2,'20160801050000012','Reprinted','2016-08-01 11:25:21','2016-09-07 11:44:57','A-2','2016-10-05 16:23:39',0,'2016-10-11 16:09:21',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (13,4,'040000013','49','123001-5950C151','Day','BN700017','BN700022',6,'20160818040000013','Reprinted','2016-08-18 13:39:31','2016-08-18 13:40:53','FA-9','2016-10-05 16:23:23',0,'2016-10-11 15:17:23',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (14,2,'020000014','49','123001-5950C151','Day','BN700017','BN700022',6,'20160819020000014','Reprinted','2016-08-19 14:32:09','2016-08-19 14:34:04','FA-1','2016-10-05 16:18:42',0,'2016-10-11 15:17:23',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (16,2,'020000016','2','123001-5940B151','Day',NULL,NULL,NULL,'20160831020000016','Not yet','2016-08-31 11:14:54',NULL,NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (17,1,'010000017','2','123001-5940B151','Day','BN601311','BN601312',2,'20160831010000017','Reprinted','2016-08-31 11:16:04','2016-09-01 09:18:50','A-1','2016-09-26 16:04:28',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (18,1,'010000018','26','123001-6090C152','Day','BN700002','BN700011',10,'20160901010000018','Reprinted','2016-09-01 13:41:57','2016-09-02 16:39:08','A-1','2016-10-05 16:20:55',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (19,6,'060000019','2','123001-5940B151','Day','BN800151','BN800152',2,'20160906060000019','Reprinted','2016-09-06 10:41:17','2016-09-06 14:45:55',NULL,'2016-09-12 11:37:43',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (20,1,'010000020','49','123001-5950C151','Day','BN700017','BN700022',6,'20160906010000020','Reprinted','2016-09-06 14:46:37','2016-09-06 14:47:28','A-1','2016-10-05 16:20:53',0,'2016-10-11 15:17:23',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (21,6,'060000021','49','123001-5950C151','Day','BN700017','BN700022',6,'20160907060000021','Reprinted','2016-09-07 11:34:13','2016-09-07 11:41:01',NULL,'2016-09-12 11:46:02',0,'2011-11-11',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (22,1,'010000022','20','123000-72500103','Day','BN601311','BN601314',4,'20160907010000022','Reprinted','2016-09-07 11:42:51','2016-09-07 11:43:29','A-1','2016-10-05 16:22:58',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (23,1,'010000023','26','123001-6090C152','Day','BN700002','BN700011',10,'20160907010000023','Reprinted','2016-09-07 11:44:42','2016-09-09 14:02:48','A-1','2016-10-05 16:22:59',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (24,4,'040000024','26','123001-6090C152','Day','BN700002','BN700011',10,'20160907040000024','Reprinted','2016-09-07 11:45:04','2016-09-07 11:46:57','FA-9','2016-10-05 16:23:25',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (25,4,'040000025','16','139000-67300101','Day','BN904524','BN904527',4,'20160907040000025','Reprinted','2016-09-07 11:49:22','2016-09-07 11:49:47','FA-9','2016-10-05 16:23:26',0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (26,3,'030000026','19','123000-72500102','Day','BN601312','BN601315',4,'20160909030000026','Reprinted','2016-09-09 14:13:00','2016-09-09 14:13:32','A-6','2016-10-05 16:23:09',0,'2016-10-11 15:42:56',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (27,4,'040000027','36','123000-6110B101','Day','BN701529','BN701533',5,'20160909040000027','Reprinted','2016-09-09 14:38:30','2016-09-09 14:40:14','FA-9','2016-10-05 16:23:28',0,'2016-10-11 16:10:00',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (28,4,'040000028','17','123000-72700151','Day','BN701529',NULL,NULL,'20160909040000028','Not yet','2016-09-09 14:44:59',NULL,NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (29,3,'030000029','36','123000-6110B101','Day','BN601311','BN601315',5,'20160912030000029','Reprinted','2016-09-12 13:52:55','2016-09-12 13:53:13','A-6','2016-10-05 16:23:11',1,'2016-10-11 16:13:57',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (30,3,'030000030','16','139000-67300101','Day','BN600377','BN600380',4,'20161007030000030','Printed','2016-10-07 08:59:22','2016-10-07 09:04:43',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (31,6,'060000031','2','123001-5940B151','Day','BN601311','BN601312',2,'20161011060000031','Printed','2016-10-11 16:38:28','2016-10-12 10:49:12',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (32,6,'060000032','1','123001-5940B152','Day','BN800148','BN800148',1,'20161011060000032','Printed','2016-10-11 16:40:47',NULL,NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (33,6,'060000033','1','123001-5940B152','Day','BN701533','BN701533',1,'20161011060000033','Printed','2016-10-11 16:41:18',NULL,NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (34,6,'060000034','1','123001-5940B152','Day','BN800150','BN800150',1,'20161012060000034','Printed','2016-10-12 08:57:15','2016-10-12 10:46:40',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (35,6,'060000035','1','123001-5940B152','Day','BN701526','BN701526',1,'20161012060000035','Printed','2016-10-12 11:56:43','2016-10-12 11:56:47',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (36,6,'060000036','1','123001-5940B152','Day','BN701529','BN701529',1,'20161012060000036','Printed','2016-10-12 11:57:35','2016-10-12 11:57:37',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (37,6,'060000037','1','123001-5940B152','Day','BN701534','BN701534',1,'20161012060000037','Printed','2016-10-12 11:59:34','2016-10-12 11:59:35',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (38,6,'060000038','1','123001-5940B152','Day','BN701532','BN701532',1,'20161012060000038','Printed','2016-10-12 12:00:20','2016-10-12 12:00:22',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (39,6,'060000039','1','123001-5940B152','Day','BN701532','BN701532',1,'20161012060000039','Printed','2016-10-12 12:00:49','2016-10-12 12:00:50',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (40,6,'060000040','1','123001-5940B152','Day','BN601319','BN601319',1,'20161012060000040','Printed','2016-10-12 12:02:11','2016-10-12 12:02:12',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (41,6,'060000041','1','123001-5940B152','Day','BN701526','BN701526',1,'20161012060000041','Printed','2016-10-12 12:03:03','2016-10-12 12:03:04',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (42,6,'060000042','1','123001-5940B152','Day','BN601316','BN601316',1,'20161012060000042','Printed','2016-10-12 12:03:21','2016-10-12 12:03:22',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (43,6,'060000043','1','123001-5940B152','Day','BN601319','BN601319',1,'20161012060000043','Printed','2016-10-12 12:04:02','2016-10-12 12:04:03',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (44,6,'060000044','1','123001-5940B152','Day','BN701526','BN701526',1,'20161012060000044','Printed','2016-10-12 13:11:35','2016-10-12 13:11:36',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (45,6,'060000045','1','123001-5940B152','Day',NULL,'BN601316',1,'20161012060000045','Printed','2016-10-12 13:12:00','2016-10-12 13:12:37',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (46,6,'060000046','1','123001-5940B152','Day','BN601319','BN601319',1,'20161012060000046','Printed','2016-10-12 13:13:07','2016-10-12 13:13:09',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (47,6,'060000047','1','123001-5940B152','Day','BN601316','BN601316',1,'20161012060000047','Printed','2016-10-12 13:14:21','2016-10-12 13:14:25',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (48,6,'060000048','18','123000-72500151','Day','BN601311','BN601314',4,'20161012060000048','Printed','2016-10-12 13:20:41','2016-10-12 13:20:56',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (49,6,'060000049','19','123000-72500102','Day','BN601315','BN601316',2,'20161012060000049','Printed','2016-10-12 13:21:34','2016-10-12 13:22:40',NULL,NULL,0,NULL,0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (50,6,'060000050','21','123000-72700102','Day','BN701531','BN701535',5,'20161012060000050','Printed','2016-10-12 13:24:24','2016-10-12 13:29:15',NULL,NULL,1,'2016-10-20 09:27:51',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (51,6,'060000051','21','123000-72700102','Day','BN601311','BN601315',5,'20161012060000051','Printed','2016-10-12 13:37:44','2016-10-12 14:22:16',NULL,NULL,1,'2016-10-20 09:27:51',0,NULL,NULL);
INSERT INTO `fgt_tag` VALUES (52,1,'010000052','21','123000-72700102','Day','BN601311',NULL,NULL,'20161021010000052','Not yet','2016-10-21 10:25:06',NULL,NULL,NULL,0,NULL,0,NULL,NULL);

#
# Table structure for table fgt_update_tag
#

CREATE TABLE `fgt_update_tag` (
  `id_update` int(4) NOT NULL DEFAULT '0',
  `last_id` int(11) DEFAULT NULL,
  `line_id` int(4) DEFAULT NULL,
  `status_update` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Server or Line Name',
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_update`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# Dumping data for table fgt_update_tag
#

INSERT INTO `fgt_update_tag` VALUES (0,1,212,'A-1','2011-11-11');

#
# View structure for view view_line
#

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `view_line` AS select `target_board`.`tb_line`.`line_id` AS `line_id`,`target_board`.`tb_line`.`line_name` AS `line_name`,`target_board`.`tb_line`.`person` AS `person`,`target_board`.`tb_line`.`leader_day` AS `leader_day`,`target_board`.`tb_line`.`leader_night` AS `leader_night`,`target_board`.`tb_line`.`floater_day` AS `floater_day`,`target_board`.`tb_line`.`floater_night` AS `floater_night` from `target_board`.`tb_line` where (`target_board`.`tb_line`.`active` = '0');

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
