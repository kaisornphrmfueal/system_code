<?php
session_start();
date_default_timezone_set('Asia/Bangkok');

require_once '../includes/configure_host.php';
require_once '../includes/chk_session.php';
require_once '../functions/function.php';
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<title>FG Transfer Tag RealTime Printing</title>
	<link href="<?= HTTP_SERVER . DIR_PAGE . DIR_INCLUDES . DIR_CSS ?>style.css" rel="stylesheet" type="text/css" />
	<link href="<?= HTTP_SERVER . DIR_PAGE . DIR_INCLUDES . DIR_CSS ?>txt.css" rel="stylesheet" type="text/css" />
	<!-- Menu CSS -->
	<link href="<?= HTTP_SERVER . DIR_PAGE . DIR_INCLUDES . DIR_CSS ?>dropdown/dropdown.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="<?= HTTP_SERVER . DIR_PAGE . DIR_INCLUDES . DIR_CSS ?>dropdown/dropdown.vertical.rtl.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="<?= HTTP_SERVER . DIR_PAGE . DIR_INCLUDES . DIR_CSS ?>dropdown/default/default.ultimate.css" rel="stylesheet" type="text/css" media="screen" />
	<!-- JavaScript -->
	<script src="<?= HTTP_SERVER . DIR_PAGE . DIR_JAVA ?>all.js"></script>
	<script src="<?= HTTP_SERVER . DIR_PAGE . DIR_JAVA ?>java.js"></script>
	<script src="<?= HTTP_SERVER . DIR_PAGE . DIR_JAVA ?>date-picker2.js"></script>
	<script src="<?= HTTP_SERVER . DIR_PAGE . DIR_JAVA ?>jquery-3.3.1.slim.min.js"></script>
		<script src="<?= HTTP_SERVER . DIR_PAGE . DIR_JAVA ?>jquery-3.5.1.min.js"></script> 
<!--	<script src="<?= HTTP_SERVER . DIR_PAGE . DIR_JAVA ?>jquery.min.js"></script>
	<script src="<?= HTTP_SERVER . DIR_PAGE . DIR_JAVA ?>jquery-ui.min.js"></script>-->
	
</head>
<body id="page1">
<div id="main">
	<!-- HEADER -->
	<div id="header">
		<div class="row-1">
			<div class="fleft">
				<a href="#"><img src="../<?= DIR_IMAGES ?>logo_fg.png" alt="Logo" /></a>
			</div>
			<!-- MENU -->
			<div class="menu">
				<?php require_once(DIR_MENU . "menu_fg.php"); ?>
			</div>
			<!-- MENU -->
			<div class="wellcome">
				Welcome, <?php
				$user_log_name=selectName($user_login);
			echo  htmlspecialchars(selectName($user_login)) ;
				?> ||
				<a href="<?= HTTP_SERVER_TRUE . SSO ?>/logout.php">Logout</a>
			</div>
		</div>
		<div class="row-3"></div>
	</div>
	<div style="margin: 20px 0; text-align: left;">
		<span style="font-size: 1.2em; color: #333; font-weight: bold;">
			คุณอยู่ในจุดทำงาน: 
			<span style="color: #007bff;">
				<?php
				$current_page = $_GET['id'] ;
				// Update station from GET parameter if provided
				if (!empty($_GET['station'])) {
					$_SESSION['station'] = $_GET['station'];
				}
				if (!empty($_SESSION['station']) && !empty($current_page)) {
					$ss_fgidline=$_SESSION['station'];
					$station_name = selectStationName($_SESSION['station']);
					echo htmlspecialchars($station_name);

				} else {
					echo 'ยังไม่ได้เลือก Station';
					
					if ($current_page !== base64_encode('fg_station')) {
						// Redirect to fg_station selection page
						gotopage("index_fg.php?id=" . base64_encode('fg_station'));
					}
				}
				?>
			</span>
			<!-- Change Station Button -->
			<?php if (!empty($current_page ) !== base64_encode('fg_station')){ ?>
				<a href="index_fg.php?id=<?php echo base64_encode('fg_station') ;?>" style="margin-left: 20px; padding: 5px 12px; background: #007bff; color: #fff; border-radius: 4px; text-decoration: none; font-size: 0.95em;">
					เปลี่ยน Station
				</a>
			<?php }//endif; ?>
		</span>
	</div>
	<!-- CONTENT -->
	<div id="content">
