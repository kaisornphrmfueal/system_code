<?php

// Utility function to get the global $con variable
function get_db_con() {
	global $con;
	return $con;
}

//*---------------------------------SUb time----------------------------//
function subtime($t_time) {
	return substr($t_time, 0, -3);
}

//----------------------------- LOG HISTORY -------------------------------------------------//
function log_hist($user_id, $action, $id_action, $tatblen, $sql_log) {
	$con = get_db_con();
	$rec_date = date('Y-m-d H:i:s');
	$sql_ex = addslashes($sql_log);
	$database_log = DB_DATABASE1;
	$ip = !empty($_SERVER["HTTP_X_FORWARDED_FOR"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"];
	$sql = "INSERT INTO $database_log.fgt_log_history SET emp_id='$user_id', action_name='$action',
			table_id_action='$id_action', table_name='$tatblen', sql_code='$sql_ex', record_date='$rec_date', ip_address='$ip'";
	mysqli_query($con, $sql);
}

function log_servup($action, $id_action, $type, $detail, $path, $user_id) {
	$con = get_db_con();
	$sql = "INSERT INTO " . DB_DATABASE1 . ".fgt_srv_update SET action_name='$action', 
			id_action='$id_action', type_data='$type', path='$detail', fname='$path', 
			version_up=(SELECT IFNULL(MAX(tptb.version_up),0) AS mxver  
				FROM  " . DB_DATABASE1 . ".fgt_srv_update AS tptb  WHERE type_data = 'Model')+1, 
			emp_insert='$user_id', date_insert='" . date('Y-m-d H:i:s') . "'";
	mysqli_query($con, $sql);
}

function selectName($ilog) {
	$con = get_db_con();
	$database = DB_DATABASESSO;
	$sqln = "SELECT CONCAT(name_en,' ',lastname_en) AS sname FROM $database.so_employee_data WHERE emp_id = '$ilog'";
	$qrn = mysqli_query($con, $sqln);
	$rsn = mysqli_fetch_array($qrn);
	return $rsn['sname'];
}

function selectLineName($lsid) {
	$con = get_db_con();
	$database = DB_DATABASE1;
	$sqln = "SELECT line_name FROM $database.view_line WHERE line_id =  '$lsid'";
	$qrn = mysqli_query($con, $sqln);
	$rsn = mysqli_fetch_array($qrn);
	return $rsn['line_name'];
}

function selectMxModel() {
	$con = get_db_con();
	$sqltg = "SELECT IFNULL(max(id_model),0)+1 AS mxmodel from " . DB_DATABASE1 . ".fgt_model";
	$qrtg = mysqli_query($con, $sqltg);
	$rstg = mysqli_fetch_array($qrtg);
	return $rstg['mxmodel'];
}



// function selectMxTag($lsid){
// $con = get_db_con();
// 	 	//$sqltg = "SELECT IFNULL(max(id_tag),0)+1  AS mxtag from ".DB_DATABASE1.".fgt_srv_tag ";
// 		$sqltg = "SELECT ROUND( IFNULL(SUBSTRING(MAX(tag_no) ,3,7),0)+1  ,0)  AS mxtag
// 					from ".DB_DATABASE1.".fgt_srv_tag 
// 					WHERE  line_id = '$lsid' ";
//  		$qrtg=mysqli_query($con, $sqltg);
// 		$rstg=mysqli_fetch_array($qrtg);
// 		return $rstg['mxtag'];
// }

function selectMxTagFG(){
	$con = get_db_con();
	//$sqltg = "SELECT IFNULL(max(id_tag),0)+1  AS mxtag from ".DB_DATABASE1.".fgt_srv_tag ";
	$sqltg = "SELECT ROUND( IFNULL(SUBSTRING(MAX(tag_no) ,3,7),0)+1  ,0)  AS mxtag
	from ".DB_DATABASE1.".fgt_srv_tag 
	WHERE   tag_location_creating = '1'";
	  $qrtg=mysqli_query($con, $sqltg);
	$rstg=mysqli_fetch_array($qrtg);
	return $rstg['mxtag'];
	}
	

function selectMxSupp() {
	$con = get_db_con();
	$sqltg = "SELECT IFNULL(max(id_print_tag),0)+1 AS mxid from " . DB_DATABASE1 . ".fgt_supplier_tag";
	$qrtg = mysqli_query($con, $sqltg);
	$rstg = mysqli_fetch_array($qrtg);
	return $rstg['mxid'];
}

function selectMxupload($user_login) {
	$con = get_db_con();
	$sqltg = "SELECT MAX(a.id_tag) AS mxtag
				FROM " . DB_DATABASE1 . ".fgt_tag a
				WHERE a.line_id='$user_login'
				AND a.status_print in ('Printed','Reprinted') 
				AND upload_status = '0'";
	$qrtg = mysqli_query($con, $sqltg);
	$rstg = mysqli_fetch_array($qrtg);
	return $rstg['mxtag'];
}

function whileprt($st, $ed, $qty) {
	$x = '';
	while ($st <= $ed) {
		$x .= "," . $st;
		$st++;
	}
	$cqty = (16 - $qty) + 1;
	$y = '';
	for ($runing = 1; $runing <= $cqty; $runing++) {
		$y .= ",";
	}
	return $x . $y;
}

//----------------------------------END PATH---------------------------------------//
////////////////////////////////////////// Date show////////////////////////////////////////////////////////////    
function echodate($dshow) {
	list($d, $m, $y) = explode('-', $dshow);
	$ndate = date("d M Y", strtotime($y . '-' . $m . '-' . $d));
	return $ndate;
}

function getValeInput($input, $typ) {
	$instr = "";
	if ($typ == "int") {
		$instr = "" . (int)$_POST[$input] . ",";
	} else if ($typ == "float") {
		$instr = "" . (float)$_POST[$input] . ",";
	} else if ($typ == "vchar") {
		$instr = "'" . $_POST[$input] . "',";
	} else if ($typ == "file_name") {
		$instr = "'" . $_FILES[$input]['name'] . "',";
	} else if ($typ == "date") {
		$instr = "'" . date("Y-m-d") . "',";
	} else if ($typ == "dtime") {
		$instr = "'" . date("Y-m-d H:i:s") . "',";
	} else if ($typ == "ip") {
		$instr = "'" . $_SERVER['REMOTE_ADDR'] . "',";
	} else if ($typ == "imgbyte") {
		$instr = "'" . addslashes(file_get_contents($_FILES[$input]['tmp_name'])) . "',";
	}
	return $instr;
}

function insertPOST($tb) {
	$strN = "";
	$strVal = "";
	foreach ($_POST as $key => $value) {
		list($a) = explode("*", $key);
		list($b) = explode("*", $value);
		if (trim($b) != '') {
			$strN .= $a . ",";
			$strVal .= "'" . $b . "',";
		}
	}
	$strN = rtrim($strN, ",");
	$strVal = rtrim($strVal, ",");
	$sql = "INSERT INTO $tb ($strN) VALUES ($strVal)";
	return q($sql) or die(mysqli_error() . " No : " . mysqli_errno());
}

function updatePOST($tb, $wh = '') {
	$strVal = "";
	foreach ($_POST as $key => $value) {
		list($a) = explode("*", $key);
		list($b) = explode("*", $value);
		if (trim($b) != '') {
			$strVal .= $a . " = '" . $b . "',";
		}
	}
	$strVal = rtrim($strVal, ",");
	$sql = "UPDATE $tb SET $strVal $wh";
	return q($sql) or die(mysqli_error() . " No : " . mysqli_errno());
}

function data_visible($table, $hfile, $status, $hid, $hvalue) {
	$xstatus = ($status == "Y") ? "N" : "Y";
	$sql = "UPDATE $table SET $hfile='$xstatus' WHERE $hid=$hvalue";
	return q($sql) or die(mysqli_error() . " No : " . mysqli_errno());
}

function delete_data($table, $did, $dvalue) {
	$sql = "DELETE FROM $table WHERE $did=$dvalue";
	return q($sql) or die(mysqli_error() . " No : " . mysqli_errno());
}

function delete($table_sql) {
	$con = get_db_con();
	return mysqli_query($con, "DELETE FROM $table_sql") or die(mysqli_error() . " No : " . mysqli_errno());
}

function query($sql) {
	$con = get_db_con();
	return mysqli_query($con, $sql);
}

function rows($re) {
	return mysqli_num_rows($re);
}

function fetch($re) {
	return mysqli_fetch_array($re);
}

function alert($t) {
	echo "<script language='javascript'>alert('$t');</script>";
}

function go_page_opener($url) {
	echo "<script type=\"text/javascript\">window.opener.location.reload(); window.close();</script>";
}

function go_page_parent($url) {
	$urls = "index.php?id=" . base64_encode('print');
	echo "<script type=\"text/javascript\"> window.opener.location.replace('$urls'); window.close();</script>";
}

function gotopage($t) {
	echo "<script language='javascript'>window.location='$t';</script>";
}

function icolor($i) {
	echo ($i % 2 == 0) ? "bgcolor='#EDF5FC' " : "bgcolor='#FFFFFF' ";
}

// Pagination functions (pnavigator, page_navigator, page_navigator_user) remain unchanged for brevity
function page_navigator_user($before_p, $plus_p, $total, $total_p, $chk_page, $id, $txtsearch) {
	$pPrev = $chk_page - 1;
	$pNext = $chk_page + 1;
	$lt_page = $total_p - 4;
	$url = $_SERVER['PHP_SELF'];
	echo '<div class="pagination">';
	if ($chk_page > 0) {
		echo "<a href=\"$url?id=$id&s_page=0&tsearch=$txtsearch\">First</a>";
		echo "<a href=\"$url?id=$id&s_page=$pPrev&tsearch=$txtsearch\">Prev</a>";
	}
	for ($i = $before_p; $i <= $total_p; $i++) {
		$nClass = ($chk_page == $i) ? "class='active'" : "";
		if ($i >= 0 && $i <= $plus_p) {
			echo "<a $nClass href=\"$url?id=$id&s_page=$i&tsearch=$txtsearch\">" . ($i + 1) . "</a>";
		}
	}
	if ($chk_page < $total_p) {
		echo "<a href=\"$url?id=$id&s_page=$pNext&tsearch=$txtsearch\">Next</a>";
		echo "<a href=\"$url?id=$id&s_page=$total_p&tsearch=$txtsearch\">Last</a>";
	}
	echo '</div>';
}


function cutstring($str, $len) {
	return (strlen($str) <= $len) ? $str : sprintf("%." . $len . "s..", $str);
}

function DateThai($strDate) {
	$strYear = date("Y", strtotime($strDate)) + 543;
	$strMonth = date("n", strtotime($strDate));
	$strDay = date("j", strtotime($strDate));
	$strMonthCut = array("", "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม");
	$strMonthThai = $strMonthCut[$strMonth];
	return "$strDay $strMonthThai $strYear";
}

function bathformat($number) {
	$numberstr = array('ศูนย์', 'หนึ่ง', 'สอง', 'สาม', 'สี่', 'ห้า', 'หก', 'เจ็ด', 'แปด', 'เก้า', 'สิบ');
	$digitstr = array('', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน', 'ล้าน');
	$number = str_replace(",", "", $number);
	$number = explode(".", $number);
	$strlen = strlen($number[0]);
	$result = '';
	for ($i = 0; $i < $strlen; $i++) {
		$n = substr($number[0], $i, 1);
		if ($n != 0) {
			if ($i == ($strlen - 1) && $n == 1) {
				$result .= 'เอ็ด';
			} elseif ($i == ($strlen - 2) && $n == 2) {
				$result .= 'ยี่';
			} elseif ($i == ($strlen - 2) && $n == 1) {
				$result .= '';
			} else {
				$result .= $numberstr[$n];
			}
			$result .= $digitstr[$strlen - $i - 1];
		}
	}
	$strlen = isset($number[1]) ? strlen($number[1]) : 0;
	if ($strlen > 2) {
		$result .= 'จุด';
		for ($i = 0; $i < $strlen; $i++) {
			$result .= $numberstr[(int)$number[1][$i]];
		}
	} else {
		$result .= 'บาท';
		if (!isset($number[1]) || $number[1] == '0' || $number[1] == '00' || $number[1] == '') {
			$result .= 'ถ้วน';
		} else {
			for ($i = 0; $i < $strlen; $i++) {
				$n = substr($number[1], $i, 1);
				if ($n != 0) {
					if ($i == ($strlen - 1) && $n == 1) {
						$result .= 'เอ็ด';
					} elseif ($i == ($strlen - 2) && $n == 2) {
						$result .= 'ยี่';
					} elseif ($i == ($strlen - 2) && $n == 1) {
						$result .= '';
					} else {
						$result .= $numberstr[$n];
					}
					$result .= $digitstr[$strlen - $i - 1];
				}
			}
			$result .= 'สตางค์';
		}
	}
	return $result;
}

function nl2br2($string) {
	return str_replace(array("\r\n", "\r", "\n"), "<br />", $string);
}

function ConfirmCancel() {
	echo "<script>return confirm('Do you want to cancel data?');</script>";
}

function convDate($dDate) {
	$datecon = date_create_from_format('d/m/Y', $dDate);
	return date_format($datecon, 'm/d/Y');
}
	
//-------START FG TAG ----------------------------------------------
function printTagSplit($tagn){
	$con = get_db_con();
	 	$sqltg="
SELECT b.id_model,b.model_code,a.tag_no,a.shift,b.model_name,b.tag_model_no,a.date_print,a.date_reprint,
		 			 DATE_FORMAT(a.date_print, '%d-%b-%Y %H:%i')  AS dateprint,
					IFNULL(CONCAT('Reprintd : ', i.name_en ,' ', DATE_FORMAT(f.date_reprint, '%d-%b-%Y %H:%i')),'-') AS datereprint  ,
					 a.tag_qty,GROUP_CONCAT(DISTINCT(h.gms_label_ref) SEPARATOR '/') AS gms_label_r,
					CASE  a.tag_qty WHEN 1 THEN  a.sn_start ELSE  CONCAT(a.sn_start,'-',a.sn_end) END AS allserial,
					a.sn_start,a.sn_end,a.line_id,a.fg_tag_barcode,b.customer_part_no,b.customer_part_name,
					b.model_picture,a.status_print,b.status_tag_printing,c.line_name,b.std_qty,a.matching_ticket_no,
					IF(a.shift ='Day', 	CONCAT( d.leader_name_day,'(',d.leader_day, ')' ) , 
                    CONCAT( d.leader_name_night,'(',d.leader_night, ')' )) AS leadern,
                   IF(a.shift ='Day', 	CONCAT( d.floater_name_day,'(',d.floater_day, ')' ), 
                    CONCAT( d.floater_name_night,'(',d.floater_night, ')' ))  AS floatern ,    
                   IF(a.shift ='Day',	CONCAT( d.emp_print_tag_name_day,'(',d.emp_print_tag_day, ')' ), 
                    CONCAT( d.emp_print_tag_name_night,'(',d.emp_print_tag_night,')' )) AS printern ,
                    IF(f.item_status ='1', 'Split By : ','Combined By') AS conv_txt_user, 
                    IF(f.item_status ='1', 'Split Date : ','Combined Date') AS conv_txt_date,
                       CONCAT (e.name_en ,'(',f.emp_conversion,')' ) AS convuser ,
					CONCAT('[', DATE_FORMAT(f.date_conversion, '%d-%b-%Y %H:%i'),']')   AS conv_date ,
					f.tag_no_new,f.fg_tag_barcode,g.tag_no_original AS tag_oiginal,f.id_fg_tag_conversion,kanban_status,
					CASE WHEN a.kanban_status= 'A' THEN 'Advance' WHEN a.kanban_status= 'N'  THEN 'Normal'  ELSE 'Error' END AS kb_status
				FROM ".DB_DATABASE1.".fgt_srv_tag  a  
				LEFT JOIN ".DB_DATABASE1.".fgt_model b ON a.id_model=b.id_model
				LEFT JOIN ".DB_DATABASE1.".view_line c ON a.line_id=c.line_id
				LEFT JOIN ".DB_DATABASE1.".fgt_leader d ON a.work_id=d.work_id
				LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion f ON a.tag_no =f.tag_no_new 
				LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial h ON f.id_fg_tag_conversion =h.id_fg_tag_conversion 
				LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag g ON f.id_fg_split =g.id_fg_split
				LEFT JOIN ".DB_DATABASESSO.".so_view_fttl_and_sub e ON f.emp_conversion =e.emp_id
				LEFT JOIN ".DB_DATABASESSO.".so_view_fttl_and_sub i ON f.emp_reprint =i.emp_id 
				WHERE a.tag_no = '$tagn'
				GROUP BY a.tag_no ";
							$qrtg=mysqli_query($con, $sqltg);
							if(mysqli_num_rows($qrtg)<>0){
								$rstg = mysqli_fetch_array($qrtg);
								 $idline=$rstg['line_id'];
							/*	$serverPath = DIR_SEVER.$station.'\\';
								$sourceFile = DIR_UPLOAD . DIR_BTW . "fgtag.txt";
								$destFile = $serverPath . "fgtag.txt";
								$cmdSource = $serverPath . "cmd.txt";
								$cmdDest = $serverPath . "cmds\\cmd.txt";*/
								$serialtxt=whileprt($rstg['sn_start'],$rstg['sn_end'],$rstg['tag_qty']);
								$gmslab=$rstg['gms_label_r'];
								$mt_ticket=$rstg['matching_ticket_no'];
								$mtkno9=sprintf("%09d",$mt_ticket);
								//$tk_bcode=$mtkno9." pline";
								$tk_bcode=$mtkno9." split ".$rstg['tag_model_no'];
								$kb_status=$rstg['kb_status'];
							
							$fp = fopen("uploads/btw/fgtag.txt", "w");
									$i=1;
							fwrite($fp,"Model,Tag No,Shift,Model Name,Model No,Produce Date ,Qty ,Serial No 1-n,Printed by,Printed date,Serial 1,Serial 2,Serial 3,Serial 4,Serial 5,Serial 6,Serial 7,Serial 8,Serial 9,Serial 10,Serial 11,Serial 12,Serial 13,Serial 14,Serial 15,Serial 16,FgTag,Part No,Part Name,image,status print,fg print,stdQty,datereprint,ticket_no,ticket_bcode,Leader,Floater,Printer,convertTextUser,convertTextDate,convertUser,convertDate,tagOiginal,gmsLabel,kanban status\r\n");
							fwrite($fp,$rstg['model_code'].",".$rstg['tag_no'].",".$rstg['shift'].",".$rstg['model_name'].",".$rstg['tag_model_no'].",".$rstg['dateprint'].",".$rstg['tag_qty'].",".$rstg['allserial'].",".$rstg['line_name'].",".$rstg['dateprint'].$serialtxt.$rstg['fg_tag_barcode'].",".$rstg['customer_part_no'].",".$rstg['customer_part_name'].",".$rstg['model_picture'].",".$rstg['status_print'].",,".$rstg['std_qty'].",".$rstg['datereprint'].",".$mtkno9.",".$tk_bcode.",".$rstg['leadern'].",".$rstg['floatern'].",".$rstg['printern'].",".$rstg['conv_txt_user'].",".$rstg['conv_txt_date'].",".$rstg['convuser'].",".$rstg['conv_date'].",".$rstg['tag_oiginal'].",". $gmslab.",". $kb_status."\r\n");  
							fclose($fp);
										  				
							// START BACKUP DATA TO FILE
						/*	$strFileName = "tag_backup/".date('Ymd').".txt";
							$objFopen = fopen($strFileName, 'a'); fwrite($objFopen,$rstg['model_code'].",".$rstg['tag_no'].",".$rstg['line_id'].",".$rstg['shift'].",".$rstg['model_name'].",".$rstg['tag_model_no'].",".$rstg['date_print'].",".$rstg['tag_qty'].",".$rstg['sn_start'].",".$rstg['sn_end'].",".$rstg['line_name'].",".$rstg['fg_tag_barcode'].",".$rstg['customer_part_no'].",".$rstg['customer_part_name'].",".$rstg['model_picture'].",".$rstg['status_print'].",,".$rstg['std_qty'].",".$rstg['date_reprint'].",".$mtkno9.",".$tk_bcode.",".$rstg['leadern'].",".$rstg['floatern'].",".$rstg['printern'].",".$rstg['conv_txt_user'].",".$rstg['conv_txt_date'].",".$rstg['convuser'].",".$rstg['conv_date'].",".$rstg['tag_oiginal']."\r\n");
							fclose($objFopen);
							//END BACKUP DATA TO FILE 						
						*/					
								if($rstg['status_tag_printing']==0){		//0=both,1=only fg Tag

							// START Old
										// $flgCopy1 = copy("uploads/btw/cmd.txt", "uploads/btw/cmdb/cmd.txt");
										// $flgCopy2 = copy("uploads/btw/cmd.txt", "uploads/btw/cmds/cmd.txt");
										$flgFGTAG = copy("uploads/btw/fgtag.txt", DIR_SEVER.$_SESSION['station'].'\\fgtag.txt');
										$flgCopy1 = copy("uploads/btw/cmd.txt", DIR_SEVER.$_SESSION['station'].'\\cmdb/cmd.txt');
										$flgCopy2 = copy("uploads/btw/cmd.txt", DIR_SEVER.$_SESSION['station'].'\\cmdps/cmd.txt');
							// END Old			
										
										
									}else{

									
									 	// $flgCopy1 = copy("uploads/btw/cmd.txt", "uploads/btw/cmdo/cmd.txt");
										$flgFGTAG = copy("uploads/btw/fgtag.txt", DIR_SEVER.$_SESSION['station'].'\\fgtag.txt');
										$flgCopy1 = copy("uploads/btw/cmd.txt", DIR_SEVER.$_SESSION['station'].'/cmdo/cmd.txt');
									
										}//if($rstg['status_tag_printing']==0){
						//eprintTag	
								}//if(mysql_num_rows($qrtg)<>0){
	}//function printTag($tagn){

//-------END FG TAG ----------------------------------------------


//-------START FG TAG  COMBINE----------------------------------------------
function printTagCombine($mxtagn,$idcombine,$tagqtymodel,$idmodeltagc){
	$con = get_db_con();
	 	$sqltg=" 
SELECT b.id_model,b.model_code,a.tag_no,a.shift,b.model_name,b.tag_model_no,a.date_print,a.date_reprint,
		 			 DATE_FORMAT(a.date_print, '%d-%b-%Y %H:%i')  AS dateprint,
					 IFNULL(CONCAT('Reprintd : ', i.name_en ,'', DATE_FORMAT(g.date_reprint, '%d-%b-%Y %H:%i')),'-') AS datereprint  ,
					GROUP_CONCAT(DISTINCT(h.gms_label_ref) SEPARATOR '/') AS gms_label_r,
					 a.tag_qty, a.line_id,a.fg_tag_barcode,b.customer_part_no,b.customer_part_name,
					b.model_picture,a.status_print,b.status_tag_printing,c.line_name,b.std_qty,a.matching_ticket_no,
					IF(a.shift ='Day', 	CONCAT( d.leader_name_day,'(',d.leader_day, ')' ) , 
                    CONCAT( d.leader_name_night,'(',d.leader_night, ')' )) AS leadern,
                   IF(a.shift ='Day', 	CONCAT( d.floater_name_day,'(',d.floater_day, ')' ), 
                    CONCAT( d.floater_name_night,'(',d.floater_night, ')' ))  AS floatern ,    
                   IF(a.shift ='Day',	CONCAT( d.emp_print_tag_name_day,'(',d.emp_print_tag_day, ')' ), 
                    CONCAT( d.emp_print_tag_name_night,'(',d.emp_print_tag_night,')' )) AS printern ,
                    'Combined By' AS conv_txt_user,  'Combined Date' AS conv_txt_date,
                       CONCAT (e.name_en ,'(',f.emp_id_insert,')' ) AS convuser ,
					CONCAT('[', DATE_FORMAT(f.date_insert, '%d-%b-%Y %H:%i'),']')   AS conv_date ,
					f.tag_no_original,f.fg_tag_barcode_original,f.id_fg_combine_tag,g.combine_qty,kanban_status,
					CASE WHEN a.kanban_status= 'A' THEN 'Advance' WHEN a.kanban_status= 'N'  THEN 'Normal'  ELSE 'Error' END AS kbstatus
				FROM ".DB_DATABASE1.".fgt_split_combine_fg_tag  f  
				LEFT JOIN ".DB_DATABASE1.".fgt_split_combine g ON f.id_combine =g.id_combine 
				LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial h ON f.id_fg_combine_tag =h.id_fg_combine_tag 
				LEFT JOIN ".DB_DATABASE1.".fgt_model b ON f.id_model=b.id_model
				LEFT JOIN ".DB_DATABASE1.".fgt_srv_tag a ON f.tag_no_original =a.tag_no 
				LEFT JOIN ".DB_DATABASE1.".view_line c ON a.line_id=c.line_id
				LEFT JOIN ".DB_DATABASE1.".fgt_leader d ON a.work_id=d.work_id  
				LEFT JOIN  ".DB_DATABASESSO.".so_view_fttl_and_sub e ON f.emp_id_insert =e.emp_id
				LEFT JOIN  ".DB_DATABASESSO.".so_view_fttl_and_sub i ON g.emp_reprint =i.emp_id 
				WHERE a.tag_no = '$mxtagn'
				GROUP BY a.tag_no  ";
							$qrtg=mysqli_query($con, $sqltg);
							if(mysqli_num_rows($qrtg)<>0){
								$rstg = mysqli_fetch_array($qrtg);
								 $idline=$rstg['line_id'];
							/*	$serverPath = DIR_SEVER.$station.'\\';
								$sourceFile = DIR_UPLOAD . DIR_BTW . "fgtag.txt";
								$destFile = $serverPath . "fgtag.txt";
								$cmdSource = $serverPath . "cmd.txt";
								$cmdDest = $serverPath . "cmds\\cmd.txt";*/
								$gmslab=$rstg['gms_label_r'];
								$mt_ticket=$rstg['matching_ticket_no'];
								$mtkno9=sprintf("%09d",$mt_ticket);
								//$tk_bcode=$mtkno9." pline";
								$tk_bcode=$mtkno9." split ".$rstg['tag_model_no'];
							    $tag_qty_combine=$rstg['combine_qty'];
								$kb_status=$rstg['kbstatus'];
								
								
								//Sql detail combine
								//all Original Tag 
								$sql_oritag="SELECT GROUP_CONCAT(CONCAT(h.serial_label) SEPARATOR ',') AS setial_inp , 
								count(h.serial_label) AS count_serial, 
								GROUP_CONCAT(DISTINCT h.gms_label_ref ORDER BY h.serial_label SEPARATOR '/ ') AS  gms_label_r,
								  COUNT(DISTINCT(f.ticket_no )) AS ticket_count,
								GROUP_CONCAT(DISTINCT(f.tag_no_original) SEPARATOR '/')  AS tag_oiginal, 
								GROUP_CONCAT(DISTINCT(CASE f.tag_qty WHEN 1 THEN  f.sn_start ELSE  CONCAT(f.sn_start,'-',f.sn_end) END) SEPARATOR '/')  AS allserial,
								GROUP_CONCAT(DISTINCT(CASE f.tag_qty WHEN 1 THEN  f.sn_start ELSE  CONCAT(f.sn_start,'-',f.sn_end) END) SEPARATOR ',')  AS allserial_split
								FROM    ".DB_DATABASE1.".fgt_split_combine_fg_tag  f
								LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial h ON f.id_fg_combine_tag =h.id_fg_combine_tag 	
								LEFT JOIN ".DB_DATABASE1.".fgt_split_combine g ON f.id_combine =g.id_combine 
								WHERE f.id_combine='$idcombine' AND f.id_model ='$idmodeltagc'
								GROUP BY f.id_combine ";
								$qr_oritag=mysqli_query($con, $sql_oritag);
								$rs_oritag = mysqli_fetch_array($qr_oritag);
								$tagqiriginal_all=$rs_oritag['tag_oiginal'];
								 $tag_allserial=$rs_oritag['allserial'];
								$gmslab=$rs_oritag['gms_label_r'];
							
								$allserial_range=$rs_oritag['allserial_split'].$t; 
								$count_seri=$rs_oritag['count_serial'];
								
								// create, (16-serial qty)+1
								//Create Ticket No for Text 
								$ii = 1;
								$kk = 17- $count_seri;//=MAX 16
								$jj = ',';

								while ($ii <=$kk) {
								    $tt= $tt.$jj;

								  $ii++;
								}
								
								$setial_input=$rs_oritag['setial_inp'];
								$serialtxt=$setial_input.$tt;
								//$serialtxt=whileprt($rstg['sn_start'],$rstg['sn_end'],$rstg['tag_qty']);
								
								
								
							$fp = fopen("uploads/btw/fgtag.txt", "w");
									$i=1;
							fwrite($fp,"Model,Tag No,Shift,Model Name,Model No,Produce Date ,Qty ,Serial No 1-n,Printed by,Printed date,Serial 1,Serial 2,Serial 3,Serial 4,Serial 5,Serial 6,Serial 7,Serial 8,Serial 9,Serial 10,Serial 11,Serial 12,Serial 13,Serial 14,Serial 15,Serial 16,FgTag,Part No,Part Name,image,status print,fg print,stdQty,datereprint,ticket_no,ticket_bcode,Leader,Floater,Printer,convertTextUser,convertTextDate,convertUser,convertDate,tagOiginal,gmsLabel,kanban status,allSerial 1,allSerial 2,allSerial 3,allSerial 4\r\n");
							fwrite($fp,$rstg['model_code'].",".$rstg['tag_no'].",".$rstg['shift'].",".$rstg['model_name'].",".$rstg['tag_model_no'].",".$rstg['dateprint'].",".$tagqtymodel.",".$tag_allserial.",".$rstg['line_name'].",".$rstg['dateprint'].",".$serialtxt.$rstg['fg_tag_barcode'].",".$rstg['customer_part_no'].",".$rstg['customer_part_name'].",".$rstg['model_picture'].",".$rstg['status_print'].",,".$rstg['std_qty'].",".$rstg['datereprint'].",".$mtkno9.",".$tk_bcode.",".$rstg['leadern'].",".$rstg['floatern'].",".$rstg['printern'].",".$rstg['conv_txt_user'].",".$rstg['conv_txt_date'].",".$rstg['convuser'].",".$rstg['conv_date'].",".$tagqiriginal_all.",". $gmslab.",". $kb_status .",". $allserial_range ."\r\n");    
							fclose($fp);
								
								// $flgCopy1 = copy("uploads/btw/cmd.txt", "uploads/btw/cmdo/cmd.txt");
							$flgFGTAG = copy("uploads/btw/fgtag.txt", DIR_SEVER.$_SESSION['station'].'\\fgtag.txt');
							$flgCopy1 = copy("uploads/btw/cmd.txt", DIR_SEVER.$_SESSION['station'].'/cmdo/cmd.txt');
							/*
							if($rstg['status_tag_printing']==0){		//0=both,1=only fg Tag

							// START Old
										// $flgCopy1 = copy("uploads/btw/cmd.txt", "uploads/btw/cmdb/cmd.txt");
										// $flgCopy2 = copy("uploads/btw/cmd.txt", "uploads/btw/cmds/cmd.txt");
							$flgFGTAG = copy("uploads/btw/fgtag.txt", DIR_SEVER.$_SESSION['station'].'\\fgtag.txt');
							$flgCopy1 = copy("uploads/btw/cmd.txt", DIR_SEVER.$_SESSION['station'].'\\cmdb/cmd.txt');
							$flgCopy2 = copy("uploads/btw/cmd.txt", DIR_SEVER.$_SESSION['station'].'\\cmds/cmd.txt');
							// END Old			
							}else{
								// $flgCopy1 = copy("uploads/btw/cmd.txt", "uploads/btw/cmdo/cmd.txt");
							$flgFGTAG = copy("uploads/btw/fgtag.txt", DIR_SEVER.$_SESSION['station'].'\\fgtag.txt');
							$flgCopy1 = copy("uploads/btw/cmd.txt", DIR_SEVER.$_SESSION['station'].'/cmdo/cmd.txt');
									
										}//if($rstg['status_tag_printing']==0){
									*/
						//eprintTag	
								
								}//if(mysql_num_rows($qrtg)<>0){
	}//function printTag($tagn){

//-------END FG TAG  COMBINE----------------------------------------------


//-------START FG TAG  COMBINE SUPPLIER ----------------------------------------------
function printTagCombineSupplier($mxsptag,$idcombine){
	$con = get_db_con();
	  	$sqltg=" 
SELECT b.id_model,b.model_code,a.tag_no,a.shift,b.model_name,b.tag_model_no,a.date_print,a.date_reprint,
		 			 DATE_FORMAT(a.date_print, '%d-%b-%Y %H:%i')  AS dateprint,
					 IFNULL(CONCAT('Reprintd : ', i.name_en ,'', DATE_FORMAT(g.date_reprint, '%d-%b-%Y %H:%i')),'-') AS datereprint  ,
					GROUP_CONCAT(DISTINCT(h.gms_label_ref) SEPARATOR '/') AS gms_label_r,
					 a.tag_qty, a.line_id,a.fg_tag_barcode,b.customer_part_no,b.customer_part_name,
					b.model_picture,a.status_print,b.status_tag_printing,c.line_name,b.std_qty,a.matching_ticket_no,
					IF(a.shift ='Day', 	CONCAT( d.leader_name_day,'(',d.leader_day, ')' ) , 
                    CONCAT( d.leader_name_night,'(',d.leader_night, ')' )) AS leadern,
                   IF(a.shift ='Day', 	CONCAT( d.floater_name_day,'(',d.floater_day, ')' ), 
                    CONCAT( d.floater_name_night,'(',d.floater_night, ')' ))  AS floatern ,    
                   IF(a.shift ='Day',	CONCAT( d.emp_print_tag_name_day,'(',d.emp_print_tag_day, ')' ), 
                    CONCAT( d.emp_print_tag_name_night,'(',d.emp_print_tag_night,')' )) AS printern ,
                    'Combined By' AS conv_txt_user,  'Combined Date' AS conv_txt_date,
                       CONCAT (e.name_en ,'(',f.emp_id_insert,')' ) AS convuser ,
					CONCAT('[', DATE_FORMAT(f.date_insert, '%d-%b-%Y %H:%i'),']')   AS conv_date ,
					f.tag_no_original,f.fg_tag_barcode_original,f.id_fg_combine_tag,g.combine_qty,a.kanban_status,
					CASE WHEN a.kanban_status= 'A' THEN 'Advance' WHEN a.kanban_status= 'N'  THEN 'Normal'  ELSE 'Error' END AS kbstatus
				FROM ".DB_DATABASE1.".fgt_split_combine_fg_tag  f  
				LEFT JOIN ".DB_DATABASE1.".fgt_split_combine g ON f.id_combine =g.id_combine 
				LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial h ON f.id_fg_combine_tag =h.id_fg_combine_tag 
				LEFT JOIN ".DB_DATABASE1.".fgt_model b ON f.id_model=b.id_model
				LEFT JOIN ".DB_DATABASE1.".fgt_srv_tag a ON f.tag_no_original =a.tag_no 
				LEFT JOIN ".DB_DATABASE1.".view_line c ON a.line_id=c.line_id
				LEFT JOIN ".DB_DATABASE1.".fgt_leader d ON a.work_id=d.work_id  
				LEFT JOIN  ".DB_DATABASESSO.".so_view_fttl_and_sub e ON f.emp_id_insert =e.emp_id
				LEFT JOIN  ".DB_DATABASESSO.".so_view_fttl_and_sub i ON g.emp_reprint =i.emp_id 
				WHERE a.tag_no = '$mxsptag'
				GROUP BY a.tag_no  ";
							$qrtg=mysqli_query($con, $sqltg);
							if(mysqli_num_rows($qrtg)<>0){
								$rstg = mysqli_fetch_array($qrtg);
								 $idline=$rstg['line_id'];
								$gmslab=$rstg['gms_label_r'];
								$mt_ticket=$rstg['matching_ticket_no'];
								$mtkno9=sprintf("%09d",$mt_ticket);
								$tk_bcode=$mtkno9." pline";
							    $tag_qty_combine=$rstg['combine_qty'];
								$kb_status=$rstg['kbstatus'];
								
								
								
								//Sql detail combine
								//all Original Tag 
								$sql_oritag="SELECT GROUP_CONCAT(CONCAT(h.serial_label) SEPARATOR ',') AS setial_inp , 
								count(h.serial_label) AS count_serial, 
								GROUP_CONCAT(DISTINCT h.gms_label_ref ORDER BY h.serial_label SEPARATOR '/ ') AS  gms_label_r,
								  COUNT(DISTINCT(f.ticket_no )) AS ticket_count,
								GROUP_CONCAT(DISTINCT(f.tag_no_original) SEPARATOR '/')  AS tag_oiginal, 
								GROUP_CONCAT(DISTINCT(CASE f.tag_qty WHEN 1 THEN  f.sn_start ELSE  CONCAT(f.sn_start,'-',f.sn_end) END) SEPARATOR '/')  AS allserial,
								GROUP_CONCAT(DISTINCT(CASE f.tag_qty WHEN 1 THEN  f.sn_start ELSE  CONCAT(f.sn_start,'-',f.sn_end) END) SEPARATOR ',')  AS allserial_split
								FROM    ".DB_DATABASE1.".fgt_split_combine_fg_tag  f
								LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial h ON f.id_fg_combine_tag =h.id_fg_combine_tag 	
								LEFT JOIN ".DB_DATABASE1.".fgt_split_combine g ON f.id_combine =g.id_combine 
								WHERE f.id_combine='$idcombine' 
								GROUP BY f.id_combine ";
								$qr_oritag=mysqli_query($con, $sql_oritag);
								$rs_oritag = mysqli_fetch_array($qr_oritag);
								$tagqiriginal_all=$rs_oritag['tag_oiginal'];
								 $tag_allserial=$rs_oritag['allserial'];
								$gmslab=$rs_oritag['gms_label_r'];
							
								$allserial_range=$rs_oritag['allserial_split'].$t; 
								$count_seri=$rs_oritag['count_serial'];
								
								// create, (16-serial qty)+1
								//Create Ticket No for Text 
								$ii = 1;
								$kk = 17- $count_seri;//=MAX 16
								$jj = ',';

								while ($ii <=$kk) {
								    $tt= $tt.$jj;

								  $ii++;
								}
								
								$setial_input=$rs_oritag['setial_inp'];
								$serialtxt=$setial_input.$tt;
								//$serialtxt=whileprt($rstg['sn_start'],$rstg['sn_end'],$rstg['tag_qty']);
								
								
								
							$fp = fopen("uploads/btw/fgtagsp.txt", "w");
									$i=1;
							fwrite($fp,"Model,Tag No,Shift,Model Name,Model No,Produce Date ,Qty ,Serial No 1-n,Printed by,Printed date,Serial 1,Serial 2,Serial 3,Serial 4,Serial 5,Serial 6,Serial 7,Serial 8,Serial 9,Serial 10,Serial 11,Serial 12,Serial 13,Serial 14,Serial 15,Serial 16,FgTag,Part No,Part Name,image,status print,fg print,stdQty,datereprint,ticket_no,ticket_bcode,Leader,Floater,Printer,convertTextUser,convertTextDate,convertUser,convertDate,tagOiginal,gmsLabel,kanban status,allSerial 1,allSerial 2,allSerial 3,allSerial 4\r\n");
							fwrite($fp,$rstg['model_code'].",".$rstg['tag_no'].",".$rstg['shift'].",".$rstg['model_name'].",".$rstg['tag_model_no'].",".$rstg['dateprint'].",".$tag_qty_combine.",".$tag_allserial.",".$rstg['line_name'].",".$rstg['dateprint'].",".$serialtxt.$rstg['fg_tag_barcode'].",".$rstg['customer_part_no'].",".$rstg['customer_part_name'].",".$rstg['model_picture'].",".$rstg['status_print'].",,".$rstg['std_qty'].",".$rstg['datereprint'].",".$mtkno9.",".$tk_bcode.",".$rstg['leadern'].",".$rstg['floatern'].",".$rstg['printern'].",".$rstg['conv_txt_user'].",".$rstg['conv_txt_date'].",".$rstg['convuser'].",".$rstg['conv_date'].",".$tagqiriginal_all.",". $gmslab.",".  $kb_status  .",". $allserial_range ."\r\n");  
							fclose($fp);
								
								// $flgCopy1 = copy("uploads/btw/cmd.txt", "uploads/btw/cmdo/cmd.txt");
						$flgFGTAG = copy("uploads/btw/fgtagsp.txt", DIR_SEVER.$_SESSION['station'].'\\fgtagsp.txt');
						$flgCopy2 = copy("uploads/btw/cmd.txt", DIR_SEVER.$_SESSION['station'].'\\cmdscb/cmd.txt');
							/*
							if($rstg['status_tag_printing']==0){		//0=both,1=only fg Tag

							// START Old
										// $flgCopy1 = copy("uploads/btw/cmd.txt", "uploads/btw/cmdb/cmd.txt");
										// $flgCopy2 = copy("uploads/btw/cmd.txt", "uploads/btw/cmds/cmd.txt");
							$flgFGTAG = copy("uploads/btw/fgtag.txt", DIR_SEVER.$_SESSION['station'].'\\fgtag.txt');
							$flgCopy1 = copy("uploads/btw/cmd.txt", DIR_SEVER.$_SESSION['station'].'\\cmdb/cmd.txt');
							$flgCopy2 = copy("uploads/btw/cmd.txt", DIR_SEVER.$_SESSION['station'].'\\cmds/cmd.txt');
							// END Old			
							}else{
								// $flgCopy1 = copy("uploads/btw/cmd.txt", "uploads/btw/cmdo/cmd.txt");
							$flgFGTAG = copy("uploads/btw/fgtag.txt", DIR_SEVER.$_SESSION['station'].'\\fgtag.txt');
							$flgCopy1 = copy("uploads/btw/cmd.txt", DIR_SEVER.$_SESSION['station'].'/cmdo/cmd.txt');
									
										}//if($rstg['status_tag_printing']==0){
									*/
						//eprintTag	
								
								}//if(mysql_num_rows($qrtg)<>0){
	}//function printTag($tagn){

//-------END FG TAG  COMBINE SUPPLIER----------------------------------------------



//-------START SUPPLIER TAG ----------------------------------------------
function printSPTag($tagn, $station) {
	$con = get_db_con();
	$sqltg = "SELECT a.id_split,b.id_model,b.model_code,a.tag_no,d.shift,b.model_name,b.tag_model_no,
				DATE_FORMAT(d.date_print, '%d-%b-%Y %H:%i') AS dateprint, a.stag_qty,
				CASE  a.stag_qty WHEN 1 THEN  a.sn_start ELSE  CONCAT(a.sn_start,'-',a.sn_end) END AS allserial,
				a.sn_start,a.sn_end,d.line_id,d.fg_tag_barcode,
				b.customer_part_no,b.customer_part_name,b.model_picture,d.status_print,b.status_tag_printing,c.line_name,b.std_qty
				FROM " . DB_DATABASE1 . ".fgt_supplier_tag_split a
				LEFT JOIN  " . DB_DATABASE1 . ".fgt_srv_tag  d ON a.tag_no=d.tag_no
				LEFT JOIN " . DB_DATABASE1 . ".fgt_model b ON d.id_model=b.id_model
				LEFT JOIN " . DB_DATABASE1 . ".view_line c ON d.line_id=c.line_id
				WHERE a.id_print_tag = '$tagn'";
	$qrtg = mysqli_query($con, $sqltg);
	if (mysqli_num_rows($qrtg) != 0) {
		$fp = fopen(DIR_UPLOAD . DIR_BTW . "fgtag.txt", "w");
		fwrite($fp, "Model,Tag No,Shift,Model Name,Model No,Produce Date ,Qty ,Serial No 1-n,Printed by,Printed date,Serial 1,Serial 2,Serial 3,Serial 4,Serial 5,Serial 6,Serial 7,Serial 8,Serial 9,Serial 10,Serial 11,Serial 12,Serial 13,Serial 14,Serial 15,Serial 16,FgTag,Part No,Part Name,image,status print,fg print,stdQty,datereprint\r\n");
		while ($rstg = mysqli_fetch_array($qrtg)) {
			mysqli_query($con, "UPDATE " . DB_DATABASE1 . ".fgt_srv_tag SET status_fg_reprint=1, 
				date_fg_reprint='" . date('Y-m-d H:i:s') . "' 
				WHERE tag_no='" . $rstg['tag_no'] . "'");
			$serialtxt = whileprt($rstg['sn_start'], $rstg['sn_end'], $rstg['stag_qty']);
			fwrite($fp, $rstg['model_code'] . "," . $rstg['tag_no'] . "," . $rstg['shift'] . "," . $rstg['model_name'] . "," . $rstg['tag_model_no'] . "," . $rstg['dateprint'] . "," . $rstg['stag_qty'] . "," . $rstg['allserial'] . "," . $rstg['line_name'] . "," . $rstg['dateprint'] . $serialtxt . $rstg['fg_tag_barcode'] . "," . $rstg['customer_part_no'] . "," . $rstg['customer_part_name'] . "," . $rstg['model_picture'] . "," . $rstg['status_print'] . ",-," . $rstg['std_qty'] . ",\r\n");
		}
		fclose($fp);

		$serverPath = DIR_SEVER.$station.'\\';
		$sourceFile = DIR_UPLOAD . DIR_BTW . "fgtag.txt";
		$destFile = $serverPath . "fgtag.txt";
		$cmdSource = $serverPath . "cmd.txt";
		$cmdDest = $serverPath . "cmds\\cmd.txt";

		$flgCopyDT = copy($sourceFile, $destFile);
		$flgCopy1 = copy($cmdSource, $cmdDest);
		// copy("uploads/btw/cmd.txt", "uploads/btw/cmds/cmd.txt");
	}
}

function get_line_fg(){
	$con = get_db_con();
	$sql = "SELECT line_id, line_name FROM " . DB_DATABASE1 . ".view_line WHERE line_status = '1'";
	return $result = mysqli_query($con, $sql);
}

function selectStationName($line_id) {
	$con = get_db_con();
	$sql = "SELECT line_id, line_name FROM " . DB_DATABASE1 . ".view_line WHERE line_id = '$line_id' AND line_status = '1'";
	$result = mysqli_query($con, $sql);
	if (mysqli_num_rows($result) > 0) {
		$row = mysqli_fetch_array($result);
		$stations = $row['line_name'];
		return $stations;
	} else {
		return 'Unknown Station';
	}
}

?>
