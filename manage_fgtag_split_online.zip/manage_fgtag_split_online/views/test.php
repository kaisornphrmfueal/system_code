
<?php
echo "<br/>--". $_POST['button2'];

printTagSplit("440000001");
?>