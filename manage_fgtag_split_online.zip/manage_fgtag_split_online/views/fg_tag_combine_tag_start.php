<?php
//echo "--".$_POST['scan2']; 
//		echo "</br>--".$_POST['button2'];
if(!empty($_POST['scan2']) && $_POST['scan2'] =="Submit"){
$idmodel= $_POST['tagmodl'];
	$combine_qty= $_POST['tqty'];
$start_tag=$_POST['tsearch'];
$start_tagno=substr($_POST['tsearch'],-9); 
$start_ticket=sprintf("%09d", $_POST['sticket']); 
$stag_qty=$_POST['tagqtys'];
$pstatusnew=$_POST['statusnew'];
	
	
	
	//gotopage("index_fg.php?id=" . base64_encode('fg_tag_combine_tag_serial')."&scmb=$mxicmb&stag=$start_tag&stk=$start_ticket");
	
	//0= start, 1= combine,  2= finished, 3=cancel
	$sqlckh = "SELECT a.id_combine,a.combine_qty,a.item_status
		  			FROM ".DB_DATABASE1.".fgt_split_combine AS a
					LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag AS b  ON a.id_combine=b.id_combine
					WHERE b.fg_tag_barcode_original ='".$start_tag."' 
		  			AND  a.item_status in (0,1)  "; 
      $qrckh = mysqli_query($con, $sqlckh);
      $rsckh = mysqli_fetch_array($qrckh);
      $totalck = mysqli_num_rows($qrckh); 
		
	
	if($totalck != 0){  
		$item_id=$rsckh['id_combine'];
	//	echo "gotopage split".$item_status;
				gotopage("index_fg.php?id=".base64_encode('fg_tag_combine_tag_start')."&combid=$item_id&tagor=$start_tagno");
		 // 0= start, 1= combine,  2= finished, 3=cancel,4= Accept duplicate
		
	}else{	
		
		$sql_st = "SELECT a.id_combine,a.combine_qty,a.item_status AS its,
		 b.id_fg_combine_tag,b.id_combine,b.id_model,b.fg_tag_barcode_original,b.ticket_no,b.tag_no_original,
		 b.tag_qty,  c.id_model,c.model_code,c.model_name,c.tag_model_no 
		  			FROM ".DB_DATABASE1.".fgt_split_combine AS a
					LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag AS b  ON a.id_combine=b.id_combine
					LEFT JOIN ".DB_DATABASE1.".fgt_model c ON b.id_model =c.id_model
					WHERE b.fg_tag_barcode_original ='".$start_tag."'     ";
     		$qr_st = mysqli_query($con, $sql_st);
					$rs_st = mysqli_fetch_array($qr_st);
		 $item_st=$rs_st['its'];
		
		//0= start, 1= combine,  2= finished, 3=cancel, 4= Accept duplicate
		if(is_null($item_st) || $item_st == '3' || $item_st == '4'){ 	 
			 if($pstatusnew=="new"){
				 $fieldnm="";
				 $fielddt="";
				 	 $sqltg = "SELECT IFNULL(max(id_combine),0)+1 AS mxsp 
					from " . DB_DATABASE1 . ".fgt_split_combine";
					$qrtg = mysqli_query($con, $sqltg);
					$rstg = mysqli_fetch_array($qrtg);
					$mxicmb=$rstg['mxsp'];

					  $sqldl = "INSERT INTO ". DB_DATABASE1 .".fgt_split_combine(id_combine,combine_qty,item_status,
					 emp_id_insert,date_insert)
					VALUES ('$mxicmb','".$combine_qty."','0',
					'$user_login','". date('Y-m-d H:i:s'). "')  ";
					$qrdl = mysqli_query($con, $sqldl);
				 
			 }elseif($pstatusnew=="conf"){
				 $mxicmb=$_POST['cmid'];
				 $fieldnm=",emp_id_confirm_version,date_confirm_version";
				 $fielddt=",'". $_POST['usern']."','". date('Y-m-d H:i:s')."'";
				 
			 }else{
				 $mxicmb=$_POST['cmid'];
				 $fieldnm="";
				 $fielddt="";
			 }// if($_POST['statusnew']=="new"){
			
	$sqlmxcon = "SELECT IFNULL(max(id_fg_combine_tag),0)+1 AS mxcomb
				 				from " . DB_DATABASE1 . ".fgt_split_combine_fg_tag";
				$qrmxcon = mysqli_query($con, $sqlmxcon);
				$rsmxcon = mysqli_fetch_array($qrmxcon);
					$mxcon=$rsmxcon['mxcomb'];
			
			$qserial = "SELECT   b.serial_scan_label ,a.sn_start , a.sn_end 
						 FROM   ". DB_DATABASE1 .".fgt_srv_tag a
						 LEFT JOIN  ". DB_DATABASE1 .".fgt_srv_serial  b ON a.tag_no =b.tag_no 
						WHERE a.tag_no = '$start_tagno' ";

			$qrserial_sn = mysqli_query($con, $qserial);	
			$rsserial_sn = mysqli_fetch_array($qrserial_sn);
		   $sqlcbtg = "INSERT INTO ". DB_DATABASE1 .".fgt_split_combine_fg_tag (id_fg_combine_tag,id_combine,id_model,fg_tag_barcode_original,ticket_no,tag_no_original,tag_qty,emp_id_insert,date_insert,sn_start , sn_end  $fieldnm)
	VALUES ('$mxcon','$mxicmb','$idmodel','$start_tag','$start_ticket','$start_tagno',$stag_qty,
	'$user_login','". date('Y-m-d H:i:s')."','".$rsserial_sn['sn_start']."','".$rsserial_sn['sn_end']."' $fielddt)    ";
		$qrcbtg= mysqli_query($con, $sqlcbtg);

			//Start add Serial to fgt_split_combine_fg_tag_serial 
			
			$qrserial = mysqli_query($con, $qserial);
			$totalsr = mysqli_num_rows($qrserial);	
		if ($totalsr != 0) {
			while ($rsserial = mysqli_fetch_array($qrserial)) {
					$sql_serial =  "INSERT INTO ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial 
									(id_fg_combine_tag,serial_label)
									VALUES ('$mxcon','" .$rsserial['serial_scan_label']. "') " ;
						mysqli_query($con, $sql_serial);
				
				
			}
			// END add Serial to fgt_split_combine_fg_tag_serial 
			
			
			
			 
		 gotopage("index_fg.php?id=".base64_encode('fg_tag_combine_tag_serial')."&combid=$mxicmb&tagid=$mxcon");
			
			
		}//if ($totalsr != 0) {
			
			
			
	  
		}//	if(is_null($item_status) || $item_status == '2'){ 	
	
	}//if($totalck != 0){ 
	
	
}//if(!empty(postbtn))

?>

<?php

if (!empty($_GET['idcanc']) && $_GET['idcanc'] == "cncl") {

	
	$sqldl = "UPDATE " . DB_DATABASE1 . ".fgt_split_combine
			SET item_status=3,emp_id_delete='$user_login',date_delete='" . date('Y-m-d H:i:s') . "'
			WHERE id_combine='" . $_GET['reqid'] . "' ";
	$qrdl = mysqli_query($con, $sqldl);
	gotopage("index_fg.php?id=" . base64_encode('fg_tag_combine_tag'));
	
	
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">

	function deleteRequest(reqid){//(reqid)
  if(confirm('Do you want to cancel Combine Tag?')) { 
 //	alert(reqid);
	  
    let linkenc =  btoa(unescape(encodeURIComponent("fg_tag_combine_tag_start")));
 window.location.href="index_fg.php?id="+ linkenc +"&reqid="+ reqid + "&idcanc=cncl"; 
  }
  else {
     //'Cancel' is clicked
  }
}
	
	
	window.onload = function() {
//alert("s");
	document.getElementById("button2").disabled = true;

	  document.getElementById("tsearch").focus();
	  document.getElementById("tsearch").select();
		//document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน  FG TAG  for Combine </span>';

	 
}
	
	
	
	//START ckNext
 function ckNext(e) {
	  // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
        let tagbc=document.getElementById("tsearch").value.toString();
	 let lenbc = tagbc.length;
//alert(lenbc);
	if(lenbc == 17){
		 	 //----- START CHECK  FG TAG 
		
			let currentmodel=document.getElementById("currentagmodl").value;
			 let tagsp=document.getElementById("tsearch").value;
		
		// alert(currentmodel);
		 
			     $.ajax({
				url: "chkltagcomb_add.php?gdata="+ tagsp + "&gcurrentml="+ currentmodel ,
				method: 'GET', 
				success: function (datap) {
					//	alert(datap)
			var rqrTxtlb= datap.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '')
				
			//	alert(rqrTxtlb);
	
				if(rqrTxtlb == "No"){
					//Duplicate
						document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >ไม่พบข้อมูล  FG TAG No. ในระบบ หรือมีการแสกนไปแล้ว<br/>   กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("button2").disabled = true;
				
					
				}else if(rqrTxtlb == "Nom"){
						//Different model
						document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >Model ที่แสกนไม่ตรงกับ Model ที่กำลัง Combine<br/>   กรุณาแสกนใหม่   </span>';
						const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("button2").disabled = true;
				
					}else{
						
					//	alert("+"+rqrTxtlb);
						let combqty=Number(document.getElementById("tqty").value);
						let text = rqrTxtlb;
						const myArray = text.split("--&&--");	
						var gticket = myArray[0];
						var gqty = Number(myArray[1]);	
						var gmol = Number(myArray[2]);	
						var gstatusmodel = myArray[3];
						var statusbsi = myArray[4];	
						if(statusbsi=="NG"){
							document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >NG ยังไม่มีการสแกนข้อมูล FG tag นี้จาก BSI,<br/> กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("button2").disabled = true;
				
						}else{
						//alert(combqty+ "+"+gqty);
						if(combqty<gqty){
						//	alert("<<<<");
							document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >Combine Qty. น้อยกว่า F/G Treansfer Tag Qty.<br/>  กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("button2").disabled = true;
							 return false;
						}else{
						//	alert(">>>");
							if(gstatusmodel=="sver"){ 
							document.getElementById("txtStatus").innerHTML  = '<span class="txt-green-b-s" ><img src="../../images/yes.gif"  /><br/>ข้อมูลถูกต้อง ระบบกำลังบันทึกข้อมูล...</span>';
							document.getElementById('sticket').value  = gticket;
							document.getElementById('tagqtys').value  = gqty;
							document.getElementById('tagmodl').value  = gmol;	

							document.getElementById("button2").disabled = false;
							//document.getElementById("button2").submit();
							 document.getElementById("form1").submit();
								//	 return false;
							}else if(gstatusmodel =="difver"){
								let pcombid=document.getElementById('cmid').value ; 
								window.location="index_fg.php?id=<?php echo base64_encode('fg_tag_combine_tag_confirm_version')?>&idcomb=" + pcombid+ "&nstick=" + gticket + "&ntagqtys=" + gqty + "&ntagmodl=" + gmol+ "&ntagbarc=" + tagsp;
							}else{
								
							}// if(gstatusmodel=="sver"){ 

						}//if(combqty<gqty){
						
	
						}//if(statusbsi=="NG"){
						
						
						

					}//if(data!= null){
					
					
				}
			}); // $.ajax({
		
		//----- END CCHECK  FG TAG
		
		 
	 }else{
		 document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน FG TAG for Combine </span>';
		 
		 const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
	 }
		 return false;

    }    return true;
 
 }
	//END ckNext
</script>



 <div  align="center">
<?php
if (!empty($_GET['combid'])) {
	$gcombid = $_GET['combid'];
	$allremain= 0;
	//$g_processst = $_GET['idproc'];
	
 	  $sqlcb = "SELECT a.id_combine,a.combine_qty,c.id_fg_combine_tag,
	 IF(ISNULL(COUNT(e.serial_label_confirm ) ), '0', COUNT(e.serial_label_confirm ))  	AS count_scan,
		 a.item_status,
		 CASE WHEN a.item_status=0 THEN 'Start'
		WHEN a.item_status =1 THEN 'Start Combine' 
		WHEN a.item_status=2 THEN 'Finished' 
		WHEN a.item_status=3 THEN 'Cancel' 
		WHEN a.item_status=4 THEN 'Accept Duplicate Combine' ELSE 'Error' END AS itemstatus,
		b.model_name,b.tag_model_no,b.customer_part_no ,b.customer_part_name,
		CONCAT( d.name_en ,'[', DATE_FORMAT(a.date_insert, '%d-%b-%Y %H:%i'),']') AS conv_date 
		FROM " . DB_DATABASE1 . ".fgt_split_combine a 
		LEFT JOIN " . DB_DATABASE1 . ".fgt_split_combine_fg_tag c ON a.id_combine =c.id_combine 
		LEFT JOIN " . DB_DATABASE1 . ".fgt_split_combine_fg_tag_serial e ON c.id_fg_combine_tag =e.id_fg_combine_tag 
		LEFT JOIN " . DB_DATABASE1 . ".fgt_model b ON c.id_model =b.id_model
		LEFT JOIN ".DB_DATABASESSO.".so_view_fttl_and_sub d ON a.emp_id_insert =d.emp_id 
		WHERE a.id_combine = '$gcombid'
		GROUP BY a.id_combine  ORDER BY a.item_status , a.date_insert DESC 	 ";
	$qrcb = mysqli_query($con, $sqlcb);
	$rscb = mysqli_fetch_array($qrcb);
	$totalcb = mysqli_num_rows($qrcb);
	if ($totalcb <> 0) {
		$i=1;
?>

<table width="1278"  border="1" class="table01" align="center">
  <tr>
	<th height="27" colspan="6"  >Combine F/G Transfer Tag </th>
  </tr>
	<tr>
	  
	  <th width="177">Model No. (Tag)(Original Latest Version)</th>
	  <th width="149">Customer <br />
	    Part No.  </th> 
	  <th width="113">Combine   Date</th>
	  <th width="97">Status</th>
	  <th width="97">Combine Qty</th>
	  <th width="97">Remain Qty. for Combine</th>
	</tr>
	 <?php 
		
		$idcombine = $rscb['id_combine'];  
		$tgmoelmain = $rscb['tag_model_no'];  
		$combqty = $rscb['combine_qty'];
		$cmbsts = $rscb['itemstatus'];
		//$orticket_no = $rscb['ticket_no'];
	//	$g_processst = $rscb['process_status'];
		$count_qty = $rscb['count_scan'];
		
			  ?>
	<tr align="center">
	   
	  <td height="27"><?php echo $tgmoelmain . " [" . $rscb['model_name'] . "]"; ?></td> 
	  <td><?php echo $rscb['customer_part_no'] . " [" . $rscb['customer_part_name'] . "]"; ?></td> 
	  <td><?php echo $rscb['conv_date']; ?></td>
	  <td><?php echo $cmbsts ?></td>
	  <td><?php echo $combqty; ?></td>
		<td><?php echo $allremain= $combqty-$count_qty; ?></td>
	</tr>
	
	<tr align="center">
	  <td height="25" colspan="9">
		  <?php  if($rscb['item_status']=="0"){?> 
		  <input type="button"  id="btn_cancel" name="btn_cancel" class="button5" 
		value="Cancel"     onclick="return deleteRequest(<?php echo $idcombine;?> );" >
	</input>
		<?php } //0= start, 1= spliting,  2= finished, 3=cancel ?>
	</td>
    </tr>
</table>

 <?php } else {
		echo "<br/><br/><br/><center><div class='table_comment' >No hava Data, please try again ";
	} //	if ($totalcb <> 0) {

 	
  $sql = "SELECT b.id_model,b.model_code,e.tag_no_original,b.model_name,b.tag_model_no,b.std_qty, d.combine_qty, 
DATE_FORMAT(d.date_insert, '%d-%b-%Y %H:%i') AS combdate,
DATE_FORMAT(a.date_print, '%d-%b-%Y %H:%i') AS dateprint,
DATE_FORMAT(a.date_work, '%d-%b-%Y') AS workdate ,a.tag_qty, 
IFNULL(a.matching_ticket_no,'-') AS tickt , CASE a.tag_qty WHEN 1 THEN a.sn_start ELSE CONCAT(a.sn_start,'-',a.sn_end) END AS allserial,e.item_status AS status_tag,
a.tag_no,a.fg_tag_barcode,b.customer_part_no,b.customer_part_name,b.model_picture, a.status_print,b.status_tag_printing,c.line_name ,e.id_fg_combine_tag,e.id_fg_tag_conversion
FROM ".DB_DATABASE1.".fgt_split_combine d
LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag e ON d.id_combine=e.id_combine 
LEFT JOIN ".DB_DATABASE1.".fgt_srv_tag a ON e.tag_no_original=a.tag_no 
LEFT JOIN ".DB_DATABASE1.".fgt_model b ON a.id_model=b.id_model 
LEFT JOIN ".DB_DATABASE1.".view_line c ON a.line_id=c.line_id
WHERE e.id_combine = '$gcombid' 
GROUP BY e.id_fg_combine_tag ORDER BY a.date_print DESC  ";
	$qr = mysqli_query($con, $sql);
	//$rs = mysqli_fetch_array($qr);
	$total = mysqli_num_rows($qr);
	if ($total <> 0) {
		$i=1;
		$alltagrequest=0;
?>

<table width="1278"  border="1" class="table01" align="center">
  <tr>
	<th height="27" colspan="13">Combine F/G Transfer Tag Detial</th>
  </tr>
	<tr>
	  <th width="36" height="25">NO.</th>
		 <th width="65">Combine</th>
	  <th width="151">F/G Transfer Tag No.<br/> (Original)</th>
	  <th width="90">Ticket No.<br/> (Original)</th>
	  <th width="117">Model No. (Tag)</th>
		<th width="84">Work Date</th>
		<th width="101">Combine Date</th>
	  <th width="73">Std.  Qty.</th>
	  <th width="70">Tag  Qty.</th>
	  <th width="84">Serial </th>
	  <th width="118">GMS label Ref. </th>
	  <th width="213">Serial Confirm</th> 
	</tr>
	 <?php while ($rs = mysqli_fetch_array($qr)) { 
			$tgmoel = $rs['tag_model_no']; 
			$tgno = $rs['tag_no_original']; 
		$stdqty = $rs['std_qty'];
		$combqty = $rs['combine_qty'];
		$tagqty = $rs['tag_qty'];
		$tagsts = $rs['status_tag'];
		$orticket_no = $rs['tickt'];
		//$g_processst = $rs['process_status'];
		$idfg_conver = $rs['id_fg_tag_conversion'];
		$idfg_combibe_tag = $rs['id_fg_combine_tag'];
		$gms_lr = $rs['gms_label_ref'];
			
				    $qp="SELECT c.gms_label_ref,c.serial_label ,c.serial_label_confirm 
FROM  ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial c 
WHERE c.id_fg_combine_tag='$idfg_combibe_tag' GROUP BY c.id_combine_serial ";	
		/*	  $qp="SELECT c.gms_label_ref,c.serial_label ,c.serial_label_confirm
FROM   ".DB_DATABASE1.".fgt_split_combine_fg_tag a 
LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial c ON a.id_fg_combine_tag=c.id_fg_combine_tag
LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial b ON a.id_fg_tag_conversion=b.id_fg_tag_conversion
WHERE   a.id_fg_tag_conversion='$idfg_conver'  GROUP BY b.id_conversion_serial ";*/	
			$qrp=mysqli_query($con, $qp);
			 $np=mysqli_num_rows($qrp);	
			
			
			  ?>
	<tr align="center">
	  <td height="25" <?php if($np>1){ $nps = $np+1;echo "rowspan='".$nps."'";}?>>
		<?php  echo $i;  ?>
	 </td>
		 <td <?php if($np>1){ $nps = $np+1;echo "rowspan='".$nps."'";}?>>
			 <?php if($tagsts=="0"){?>
		  <a href="index_fg.php?id=<?=base64_encode('fg_tag_combine_tag_serial') ?>&combid=<?= $gcombid?>&tagid=<?= $idfg_combibe_tag?>"><img src="../images/merge.jpeg" width="32" />   </a>
		  <?php } //0=Remaining, 1=combined ?>
		</td>
	  <td <?php if($np>1){ $nps = $np+1;echo "rowspan='".$nps."'";}?>><?php echo $rs['tag_no'] ; ?></td>
	  <td <?php if($np>1){ $nps = $np+1;echo "rowspan='".$nps."'";}?>><?php echo $orticket_no ; ?></td>
	  <td <?php if($np>1){ $nps = $np+1;echo "rowspan='".$nps."'";}?>><?php echo $tgmoel . "<br/>  [" . $rs['model_name'] . "]"; ?></td>
	 <td <?php if($np>1){ $nps = $np+1;echo "rowspan='".$nps."'";}?>><?php echo $rs['workdate']; ?></td>
	 <td <?php if($np>1){ $nps = $np+1;echo "rowspan='".$nps."'";}?>><?php echo $rs['combdate']; ?></td>
	  <td <?php if($np>1){ $nps = $np+1;echo "rowspan='".$nps."'";}?>><?php echo $stdqty; ?></td>
	  <td <?php if($np>1){ $nps = $np+1;echo "rowspan='".$nps."'";}?>><?php echo $tagqty; ?></td>
		
		
      <?php
		 //Start multi row&column
		  if($np==1){ 
         	while($rsp=mysqli_fetch_array($qrp)){

		 ?>
         <td><?php echo $rsp['serial_label']; ?></td>
		  <td><?php echo $rsp['gms_label_ref']; ?></td>
		  <td><?php echo $rsp['serial_label_confirm']; ?></td>
	 
             <?php
		 	}//	while($rsp=mysql_fetch_array($qrp)){
		}//if($np>1){ 
		?>
</tr>
        <?php
		 //Start multi row&column
		   if($np>1){ 
         	while($rsp=mysqli_fetch_array($qrp)){
		 ?>
              <tr  align="center" <?php $v =0; $v = $v + 1; echo  icolor($v); ?> onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;">
               <td><?php echo $rsp['serial_label']; ?></td>
				  <td><?php echo $rsp['gms_label_ref']; ?></td>
				  <td><?php echo $rsp['serial_label_confirm']; ?></td>
           	</tr>
             <?php
		 	}//	while($rsp=mysql_fetch_array($qrp)){
		}//if($np>1){ 
          //END  multi row&column
		  
		 ?>
	
		
	
	<?php 
			 $alltagrequest = $alltagrequest+$tagqty;
			//  $status_remain=$status_remain+$tagsts;
			$i++; 
		}//while ($rstg = mysqli_fetch_array($qrtg)) { ?>
	
</table>

 <?php } else {
		echo "<br/><br/><br/><center><div class='table_comment' >No hava Data, please try again ";
	} ?>

 <?php } else {
	echo "<br/><br/><br/><center><div class='table_comment' >Please scan FG Tag  No. ";
} ?>
 </div>

<div align="center">
	<?php
	 //if($allremain != 0 && $alltagrequest < $combqty){
	 if($allremain != 0 && $alltagrequest < $combqty){//if($status_remain =="0"){
	  $remaintrue=$combqty - $alltagrequest; 
	?>

	<form id="form1" name="form1" method="post" action="index_fg.php?id=<?=base64_encode('fg_tag_combine_tag_start')?>"  autocomplete="off">
   <table width="530" border="1" align="center" class="table01" >
	  <tr>
     <td height="37" colspan="2" align="center" bgcolor= #F0EF4C>Combine F/G Transfer Tag</td>
     </tr>
 
      <tr>
        <td height="37"><div class="tmagin_right">Combine Qty. Remaining</div></td>
        <td><div class="tmagin_right"><input type="text" name="tqty" id="tqty"  
					 value="<?php echo $remaintrue; ?>" class="bigtxtbox" style="width:50px;" readonly  /></div> </td>
      </tr>
      <tr>
     <td width="192" height="37"><div class="tmagin_right">Scan F/G Transfer Tag (Original)</div> </td>
     <td width="274"><div class="tmagin_right">
        <input type="text" name="tsearch" id="tsearch"   value="" onfocus="this.select()"  class="bigtxtbox" style="width:190px;"  onkeypress="return ckNext(event);" /> </div>
	   </td>
   </tr>
   <tr>
     <td height="37" colspan="2" align="center"><div id="txtStatus"></div></td>
     </tr>
   <tr>
     <td height="37" colspan="2" align="center">
	    
		 
		
		 <input type="hidden" name="currentagmodl" id="currentagmodl"  value="<?php echo $tgmoelmain;?>"/>
		 <input type="hidden" name="cmid" id="cmid"  value="<?php echo $gcombid ;?>"/>
		  <input type="hidden" name="sticket" id="sticket"  value=""/>
		  <input type="hidden" name="tagqtys" id="tagqtys"  value=""/>
		 <input type="hidden" name="tagmodl" id="tagmodl"  value=""/>
		  <input type="hidden" name="scan2" id="scan2"  value="Submit" /> 
		 <input type="hidden" name="statusnew" id="statusnew"  value="add"/>
<input type="button" name="button2" id="button2" value="Submit" /> 
		 
	   </td>
   </tr>
   </table>
</form>   
	<?php }//Add new Tag ?>
		 
</div>


