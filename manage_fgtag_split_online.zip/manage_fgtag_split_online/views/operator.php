<?php

function rows_workid($work, $date, $shift, $con) {
	$sql = "SELECT *,b.line_id 
			FROM " . DB_DATABASE1 . ".fgt_operator a 
			LEFT JOIN " . DB_DATABASE1 . ".fgt_leader b ON a.work_id=b.work_id 
			WHERE b.work_date = '$date' AND b.shift = '$shift' AND a.work_id = '$work'
			ORDER BY a.work_id,a.operater_id";
	$qr = mysqli_query($con, $sql);
	$num = mysqli_num_rows($qr);
	return $num;
}

function sumem_work($work_id, $con) {
	$sql = "SELECT COUNT(operater_id) AS sum_em FROM " . DB_DATABASE1 . ".fgt_operator WHERE work_id = '$work_id'";
	$qr = mysqli_query($con, $sql);
	$rs = mysqli_fetch_array($qr);
	return $rs['sum_em'];
}

function select_Name($ilog, $con) {
	$sqln = "SELECT CONCAT(name_en,' ',lastname_en) AS sname 
		FROM sign_on.so_employee_data WHERE emp_id = '$ilog' ";
	$qrn = mysqli_query($con, $sqln);
	$rsn = mysqli_fetch_array($qrn);
	return $rsn['sname'];
}
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<div class="body_resize" align="center">

<form id="form1" name="form1" method="post" action="">
   <table width="710" border="1" align="center" class="table01" >
	 <tr>
	   <td width="418" height="37"><div class="tmagin_right">Search : Work Date,Shift,Emp ID,Emp Name,Process Name</div> </td>
	   <td width="276">
	   <script type="text/javascript">
$(function(){
	$("#dateInput").datepicker({
		dateFormat: 'dd-M-yy'
	});
});
</script>
<input type="text" name="dateInput" id="dateInput" value="" />
	   <input type="submit" name="button" id="button" value="Submit" /></td>
	 </tr>
   </table>
</form>
<?php
	if(!empty($_POST['tsearch'])|| !empty($_GET['serh'])){
		if(!empty($_POST['tsearch'])){$txtsearsh=$_POST['tsearch'];}else{$txtsearsh=$_GET['serh']; }
			$x="AND process_name LIKE '%$txtsearsh%'";
		}else{ $x=""; }

		$q="SELECT b.work_date,b.shift,b.line_id,b.work_id 
			FROM  prod_fg_tag.fgt_leader b
			GROUP BY b.work_date ";
		$qr = mysqli_query($con, $q);
		$total = mysqli_num_rows($qr);

		if($total<>0) {
			$e_page=15;
			if(!isset($_GET['s_page'])){
				$_GET['s_page']=0;
			}else{
				$chk_page=$_GET['s_page'];
				$_GET['s_page']=$_GET['s_page']*$e_page;
			}
			$q.=" LIMIT ".$_GET['s_page'].",$e_page";
			$qr=mysqli_query($con, $q);
			if(mysqli_num_rows($qr)>=1){
				@$plus_p=($chk_page*$e_page)+mysqli_num_rows($qr);
			}else{
				@$plus_p=($chk_page*$e_page);
			}
			$total_p=ceil($total/$e_page);
			@$before_p=($chk_page*$e_page)+1;
			$i=1;
?>
<div class="rightPane">

  <table width="85%" height="123" border="1" bordercolor="#CC9966"class="table01" align="center">
	<tr >
	  <th height="28" colspan="8">
	  <div align="center">Operator</div> </th>
	  <th height="28">
	  <a href="index.php?id=<?=base64_encode('setup_operator')?>&st=add" >
			Add New
			  </a> </th>
	  </tr>

	<tr>
	  <th width="10%" height="28">Work Date</th>
	  <th width="5%">No.</th>
	  <th width="10%">Line</th>
	  <th width="8%">Shift</th>
	  <th width="17%">Leady</th>
	  <th width="16%">Floater</th>
	 <th width="12%">Sum operater</th>
	  <th width="11%">Edit</th>
	  <th width="11%">Add</th>
	</tr>
	   <?php

	   while(@extract($rs=mysqli_fetch_array($qr))){
			$qp="SELECT *
				FROM ".DB_DATABASE1.".fgt_operator a
				RIGHT JOIN ".DB_DATABASE1.".fgt_leader b ON a.work_id=b.work_id
				LEFT JOIN ".DB_DATABASE1.".view_line c ON b.line_id=c.line_id
				WHERE b.work_date = '".$rs['work_date']."'  AND b.line_id = '1'
				GROUP BY b.shift,b.line_id,b.work_id
				ORDER BY c.line_name,b.shift,b.work_id
				";
			$qrp=mysqli_query($con, $qp);
			$np=mysqli_num_rows($qrp);

	   ?>
		<tr >
	   <td height="36" align="center" <?php if($np>=1){ $nps = $np+1;echo "rowspan='".$nps."'";}?>>
	   <?php echo $rs['work_date'];?></td>
		</tr>
	  <?php

	  //Start multi row&column
		  $j=1;
		  while($rsp=mysqli_fetch_array($qrp)){
		?>

	  <tr <?php $v =0; $v = $v + 1; echo  icolor($v); ?> onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" align="center">
	  <td height="30px"><?=$j?></td>
	  <td height="30px"><?=$rsp['line_name']?></td>
	  <td> <?=$rsp['shift'];?></td>
	  <td> <?php if(strtolower($rsp['shift'])=='day'){
		  echo $rsp['leader_day']." ".select_Name($rsp['leader_day'], $con);
		  }else if(strtolower($rsp['shift'])=='night'){
			  echo $rsp['leader_night']." ".select_Name($rsp['leader_night'], $con);
			  }?></td>
	  <td><?php if(strtolower($rsp['shift'])=='day'){
		  echo $rsp['floater_day']." ".select_Name($rsp['floater_day'], $con);
		  }else if(strtolower($rsp['shift'])=='night'){
			  echo $rsp['floater_night']." ".select_Name($rsp['floater_night'], $con);
			  }?></td>
	  <td height="30px"> <?=sumem_work($rsp['work_id'], $con);?> </td>

	  <td>
	  <a href="index.php?id=<?=base64_encode('setup_operetor_emp')?>&wid=<?=$rsp['work_id'];?>&st=edit"  >
		<img src="../images/001_45.gif" /><?php $rsp['work_id'];?></a>
	  </td>
	<td>
	  <a href="index.php?id=<?=base64_encode('setup_operetor_emp')?>&wid=<?=$rsp['work_id'];?>&st=add"  >
		<img src="../images/001_01.gif" /><?php $rsp['work_id'];?></a>
	  </td>

	 <?php
		$i++;$j++;
		  }
		?>

	 </tr>
  <?php      }//  while($rsp=mysqli_fetch_array($qrp)){

	?>


  </table>
   <?php

	 if($total>0){ ?>
<div class="browse_page" >
			  <?php       @page_navigator_user($before_p,$plus_p,$total,$total_p,$chk_page,base64_encode('operator'),$txtsearsh);      ?>
  </div>
<?php }

		}else{
				echo "<br/><br/><br/><center><div class='table_comment' >No hava Data...Click  ";
			?>
  <a href="#" onClick="javascript:openWins('windows.php?win=operetor&idm=', '_blank',650, 380, 1, 1, 0, 0, 0);return false;" >  here    </a>
				<?php
				echo "  to create new data </div> </center>";
			}//if(rows($qr)<>0){
	 ?>

</div>
