<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<form id="form1" name="form1" method="post" action="">
	<table width="710" border="1" align="center" class="table01" >
		<tr>
			<td width="421" height="37"><div class="tmagin_right">Search : Tag No., Model, Print Date (Exp.yyyy-mm-dd)</div> </td>
			<td width="273">
				<input type="text" name="tsearch" id="tsearch" style=" width:180px;"  value="<?php echo @$_POST['tsearch']?>"/>
				<input type="submit" name="button" id="button" value="Search" /></td>
		</tr>
	</table>
</form>   

<div class="rightPane">
<?php
		// สมมติว่ามี $con เป็น mysqli connection แล้ว
		if(!empty($_POST['tsearch'])|| !empty($_GET['serh'])){
				if(!empty($_POST['tsearch'])){
						$txtsearsh = $_POST['tsearch'];
				}else{
						$txtsearsh = $_GET['serh'];
				}
				// Escape string เพื่อป้องกัน SQL Injection
				$txtsearsh_esc = mysqli_real_escape_string($con, $txtsearsh);
				$x = "WHERE ((a.tag_no LIKE '%$txtsearsh_esc%') or (a.date_print LIKE '%$txtsearsh_esc%')  
								or (b.model_name LIKE '%$txtsearsh_esc%')  or (b.tag_model_no LIKE '%$txtsearsh_esc%')  )";
		}else{ 
				$x = ""; 
		}

		$q = "SELECT b.id_model,b.model_code,a.tag_no,a.shift,b.model_name,b.tag_model_no,
				DATE_FORMAT(a.date_print, '%d-%b-%Y %H:%i') AS dateprint ,a.tag_qty,
				IFNULL(DATE_FORMAT(a.date_reprint, '%d-%b-%Y %H:%i'),'-') AS datereprint,
				CONCAT('  [',who_reprint,']') AS whoreprint,status_print,
				CASE status_print WHEN 'Reprinted' THEN CONCAT(DATE_FORMAT(a.date_reprint, '%d-%b-%Y %H:%i'),
				CONCAT(' [',who_reprint,']') ) ELSE '-' END AS rp,
				IFNULL(CONCAT(DATE_FORMAT(a.bsi_date, '%d-%b-%Y %H:%i'),CONCAT(' [',d.line_name,']')),'-') AS bsiline,IFNULL(a.matching_ticket_no,'-') AS tickt,
				IFNULL(CONCAT(DATE_FORMAT(a.matching_date, '%d-%b-%Y %H:%i'),CONCAT(' [',a.emp_matching,']')),'-') AS matchingline,    
				IFNULL(CONCAT(DATE_FORMAT(a.packing_date, '%d-%b-%Y %H:%i'),CONCAT(' [',a.emp_packing,']')),'-') AS packingline,
				CONCAT(a.sn_start,'-',a.sn_end) AS allserial,a.sn_start,a.sn_end,a.line_id,a.fg_tag_barcode,
				b.customer_part_no,b.customer_part_name,b.model_picture,a.status_print,b.status_tag_printing,c.line_name
				FROM ".DB_DATABASE1.".fgt_srv_tag  a
				LEFT JOIN ".DB_DATABASE1.".fgt_model b ON a.id_model=b.id_model
				LEFT JOIN ".DB_DATABASE1.".view_line c ON a.line_id=c.line_id
				LEFT JOIN ".DB_DATABASE1.".view_line d ON a.bsi_line_id=d.line_id
				$x 
				ORDER BY a.date_print DESC";

		$qr = mysqli_query($con, $q);
		$total = mysqli_num_rows($qr);  
		$i = 1;
		if($total != 0) {    
				$e_page = 15; // จำนวนรายการต่อหน้า

				if(!isset($_GET['s_page'])){
						$_GET['s_page'] = 0;     
				}else{     
						$chk_page = $_GET['s_page'];       
						$_GET['s_page'] = $_GET['s_page'] * $e_page;     
				}     
				$q .= " LIMIT ".$_GET['s_page'].",$e_page";  
				$qr = mysqli_query($con, $q);  
				if(mysqli_num_rows($qr) >= 1){     
						@$plus_p = ($chk_page * $e_page) + mysqli_num_rows($qr);     
				}else{     
						@$plus_p = ($chk_page * $e_page);         
				}     
				$total_p = ceil($total / $e_page);     
				@$before_p = ($chk_page * $e_page) + 1; 
?>
<table width="98%" border="1" bordercolor="#CC9966"class="table01" align="center">
		<tr >
			<th height="23" colspan="14">
			<div align="center">Tag Report</div>  </th>
			</tr>
		<tr>
			<th width="3%" height="23">No.</th>
			<th width="6%">Tag No</th>
			<th width="9%"><span class="tmagin_right">Model No. (Tag)</span></th>
			<th width="5%">Model Name</th>
			<th width="11%">Serial </th>
			<th width="3%">Tag Qty.</th>
			<th width="3%">Line</th>
			<th width="5%">Printing Status</th>
			<th width="9%">Print Date</th>
			<th width="9%">Re-Print Date</th>
			<th width="10%">BSI </th>
			<th width="8%">Ticket</th>
			<th width="9%">Matching</th>
			<th width="10%">Packing</th>
		</tr>
		<?php while($rs = mysqli_fetch_array($qr)) { 
				$rtag = $rs['tag_no'];
		?>
		<tr <?php $v = 0; $v = $v + 1; echo icolor($v); ?> height="28" onMouseOver="className='over'"  onMouseOut="className=''" align="center">
			<td ><?=$i?></td>
			<td ><?=$rs['tag_no']?></td>
			<td><?=$rs['tag_model_no']?></td>
			<td><?=$rs['model_name']?></td>
			<td><?=$rs['allserial']?></td>
			<td><?=$rs['tag_qty']?></td>
			<td><?=$rs['line_name']?></td>
			<td><?=$rs['status_print']?></td>
			<td><?=$rs['dateprint']?></td>
			<td><?=$rs['rp']?></td>
			<td><?=$rs['bsiline']?></td>
			<td><?=$rs['tickt']?></td>
			<td><?=$rs['matchingline']?></td>
			<td><?=$rs['packingline']?></td>
		</tr>
		<?php 
				$i++;
				} // end while
		?>
	</table>
	<?php
				if($total > 0){ ?>  
<div class="browse_page" >
		<?php @page_navigator_user($before_p, $plus_p, $total, $total_p, $chk_page, base64_encode('report'), $txtsearsh); ?>
</div>  
<?php }
		} else {
				echo "<br/><br/><br/><center><div class='table_comment' >No hava Data  ";
		}
?>
</div>
