<?php
// สมมติว่ามี $con = new mysqli(...); เชื่อมต่อไว้แล้ว

function abbreviat_dept($dept_id){
	global $con;
	$sql = "SELECT abbreviat FROM sign_on.so_department WHERE dept_id = '$dept_id'";
	$result = mysqli_query($con, $sql);
	$re = mysqli_fetch_array($result, MYSQLI_ASSOC);
	return $re['abbreviat'];
}

function chk_data($work, $id){
	global $con;
	$sql = "SELECT * FROM ".DB_DATABASE1.".fgt_operator WHERE work_id = '$work' AND operater_id = '$id'";
	$result = mysqli_query($con, $sql);
	$num = mysqli_num_rows($result);
	return $num;
}

if($_POST['button']=="Submit"){
	$idemp = $_POST['id_emp'];
	$idpro = $_POST['pro_work'];
	$pwork_id = $_POST['hidwork'];
	$j = 0;
	foreach($idemp as $emps){
		if($emps!="" && $emps!="Array"){
			$process_id = $_POST['pro_work'][$j];
			$j++;
			if(chk_data($pwork_id, $emps)=='0'){
				$sql_int = "INSERT INTO ".DB_DATABASE1.".fgt_operator SET
					work_id = '$pwork_id',
					operater_id = '$emps',
					process_id = '$process_id',
					emp_insert = '$user_login',
					date_insert = '".date('Y-m-d H:i:s')."'";
				log_hist($user_login,"Insert",$emps,"fgt_operator",$sql_int);
			}else{
				$sql_int = "UPDATE ".DB_DATABASE1.".fgt_operator SET
					process_id = '$process_id',
					emp_modify = '$user_login',
					date_modify = '".date('Y-m-d H:i:s')."'
					WHERE work_id = '$pwork_id' AND operater_id = '$emps'";
				log_hist($user_login,"Update",$emps,"fgt_operator",$sql_int);
			}
			$qr_int = mysqli_query($con, $sql_int);
		}
	}
	gotopage("index.php?id=".base64_encode('setup_operetor_emp')."&wid=".$pwork_id."&st=add");
}else if($_POST['button']=="Update"){
	$pwork = $_POST['hidwork_1'];
	$pmax = $_POST['max_row'];
	for($j=0; $j<$pmax; $j++){
		$sql_up = "UPDATE ".DB_DATABASE1.".fgt_operator SET
			process_id = '".$_POST['pro_work1'][$j]."'
			WHERE operater_id = '".$_POST['emp'][$j]."' AND work_id = '$pwork'";
		$qr_up = mysqli_query($con, $sql_up);
		log_hist($user_login,"Update",$_POST['emp'][$j],"fgt_operator",$sql_up);
	}
	gotopage("index.php?id=".base64_encode('setup_operetor_emp')."&wid=".$pwork."&st=edit");
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script language="javascript" type="text/JavaScript">
// ... (JS เหมือนเดิม)
</script>

<?php
$work_id = $_GET['wid'];
$sqlm = "SELECT a.work_date,a.shift,a.line_id,b.line_name,a.work_id  
	FROM ".DB_DATABASE1.".fgt_leader a
	LEFT JOIN ".DB_DATABASE1.".view_line b ON a.line_id = b.line_id
	WHERE a.line_id <> 0 AND b.line_name <> '' AND work_id = '$work_id' 
	GROUP BY a.line_id";
$qrm = mysqli_query($con, $sqlm);
$rsm = mysqli_fetch_array($qrm, MYSQLI_ASSOC);
$work_date = $rsm['work_date'];
$shift = $rsm['shift'];
$line_id = $rsm['line_id'];
$line_name = $rsm['line_name'];
?>
<!-- ... (HTML เหมือนเดิม) -->

<?php if($_GET['st']=='add'){ ?>
<form id="form1" name="form1" method="post" action="">
<table width="450px" border="1" class="table01" align="center">
	<tr>
		<td width="28%" height="28">
			<div style="padding-left:40px" >Line:</div>
		</td>
		<td width="72%" colspan="2"><div class='tmagin_right' >
			<select name="ssearch" id="ssearch">
				<option value="">----Please select line----</option>
				<?php
				$sqls = "SELECT line_name 
					FROM ".DB_DATABASE1.".view_line_emp_prod
					WHERE line_name <>'' 
					GROUP BY line_name
					ORDER BY line_name";
				$qrs = mysqli_query($con, $sqls);
				while($rss = mysqli_fetch_array($qrs, MYSQLI_ASSOC)){
				?>
				<option value="<?=$rss['line_name']?>" <?php if($_POST['ssearch']==$rss['line_name']){ echo "selected='selected'";}?> ><?=$rss['line_name']?></option>
				<?php } ?>
			</select>
			<input type="submit" name="button" id="button" value="Search" />
		</div></td>
	</tr>
</table>
<br />
</form>
</div>
<?php
if(!empty($_POST['ssearch'])){
	$x = " AND line_name LIKE '%".$_POST['ssearch']."%' ";
}
$sql = "SELECT emp_id,name_em,posit,dept_id,emp_shift,line_name,type_shift 
	FROM ".DB_DATABASE1.".view_line_emp_prod 
	WHERE emp_id NOT IN (SELECT a.operater_id
		FROM ".DB_DATABASE1.".fgt_operator a
		LEFT JOIN ".DB_DATABASE1.".fgt_leader b ON a.work_id = b.work_id
		WHERE b.work_date = '".$rsm['work_date']."' AND b.line_id = '".$rsm['line_id']."' 
		AND b.shift = '".$rsm['shift']."' )
		$x
	GROUP BY emp_id";
$qr = mysqli_query($con, $sql);
if(mysqli_num_rows($qr)<>0){
	$i=1;
?>
<form id="form2" name="form2" method="post" action="" onsubmit='return validate(this)' style="height:200px;overflow:auto;" >
<table width="85%" height="55" border="1" class="table01" align="center">
	<!-- ... (thead เหมือนเดิม) -->
	<?php $v =0; while($rs = mysqli_fetch_array($qr, MYSQLI_ASSOC)){ ?>
	<tr <?php echo icolor($v); $v = $v + 1; ?> onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" height="25px" align="center">
		<td ><div align="center"><?=$i?></div></td>
		<td>
			<input name="id_emp[]<?=$i;?>"  id="id_emp" type="checkbox" value="<?=$rs['emp_id']?>"  />
			<input type="hidden" name="id_emp[]<?=$i;?>" id="id_emp" value="<?=$id_emp?>"/>
		</td>
		<td><div align="center"><?=$rs['emp_id']?></div></td> 
		<td><div  class="tmagin_right"><?=$rs['name_em']?></div></td>
		<td><div  class="tmagin_right" ><b><?=$rs['line_name']?></b></div> </td>
		<td><div  class="tmagin_right" ><?=abbreviat_dept($rs['dept_id'])?></div> </td>
		<td><div  class="tmagin_right" ><?=$rs['posit']; ?></div></td>
		<td><div  align="center" ><b><?=$rs['type_shift']?><b></div></td>
		<td>
			<select name="pro_work[]"  id="pro_work"   style="width:100%" <?=$dis?> >
				<option  value="">---- Please Select Process Work ---- </option>
				<?php
				$sql_dept= "SELECT * FROM ".DB_DATABASE1.".fgt_process WHERE deleted = 'N'";
				$qr_dept = mysqli_query($con, $sql_dept);
				while ($re_dept = mysqli_fetch_array($qr_dept, MYSQLI_ASSOC)) {
					$dept = $re_dept['process_id'];
					$dept_name = $re_dept['process_name'];
					$sel = ($rs['process_id']==$re_dept['process_id']) ? "selected " : "";
					echo "<option $sel value='$dept'>$dept_name</option>";
				}
				?>
			</select>
		</td>
	</tr>
	<?php $i++; } ?>
</table>
<input type="hidden" name="hdnLine" value="<?=$i;?>">    
</form>
<?php
}else{ ?>
	<br/><br/><br/><br/><br/>
	<center>
		<div class="table_comment" >No have data...</div>
	</center>
<?php } ?>
<?php } ?>
<?php
$sql = "SELECT c.emp_id,c.name_em,c.posit,c.dept_id,c.emp_shift,c.line_name,c.type_shift,a.process_id,
	CONCAT('','edit') AS st
	FROM prod_fg_tag.fgt_operator a 
	LEFT JOIN prod_fg_tag.fgt_leader b ON a.work_id = b.work_id 
	LEFT JOIN prod_fg_tag.view_line_emp_prod c ON c.emp_id=a.operater_id
	WHERE b.work_date = '".$rsm['work_date']."' AND b.line_id = '".$rsm['line_id']."'
	AND b.shift = '".$rsm['shift']."'
	ORDER BY c.emp_id";
$qr = mysqli_query($con, $sql);
$num_rows = mysqli_num_rows($qr);
if($num_rows<>0){
	$i=1;
?>
<br/>
<hr />
<form id="form3" name="form3" method="post" action="" >
<table width="80%" height="55" border="1" class="table01" align="center">
	<!-- ... (thead เหมือนเดิม) -->
	<?php $v =0; while($rs = mysqli_fetch_array($qr, MYSQLI_ASSOC)){ ?>
	<tr <?php echo icolor($v); $v = $v + 1; ?> onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" height="25px" align="center">
		<td ><div align="center"><?=$i?></div></td>
		<td><div align="center"><?=$rs['emp_id']?></div></td> 
		<td><div  class="tmagin_right"><?=$rs['name_em']?></div></td>
		<td><div  class="tmagin_right" ><?=$rs['line_name']?></div> </td>
		<td><div  class="tmagin_right" ><?=abbreviat_dept($rs['dept_id'])?></div> </td>
		<td><div  class="tmagin_right" ><?=$rs['posit']; ?></div></td>
		<td><div  align="center" ><b><?=$rs['type_shift']?><b></div></td>
		<td>
			<select name="pro_work1[]<?=$i?>"  id="pro_work1"   style="width:100%"  >
				<?php
				$sql_dept= "SELECT * FROM ".DB_DATABASE1.".fgt_process WHERE deleted = 'N'";
				$qr_dept = mysqli_query($con, $sql_dept);
				while ($re_dept = mysqli_fetch_array($qr_dept, MYSQLI_ASSOC)) {
					$dept = $re_dept['process_id'];
					$dept_name = $re_dept['process_name'];
					$sel = ($rs['process_id']==$re_dept['process_id']) ? "selected " : "";
					echo "<option $sel value='$dept'>$dept_name</option>";
				}
				?>
			</select>
			<input type="hidden" name="emp[]<?=$i?>" id="emp" value="<?=$rs['emp_id']?>" />
		</td>
	</tr>
	<?php $i++; } ?>
</table>
</form>
<?php } ?>
