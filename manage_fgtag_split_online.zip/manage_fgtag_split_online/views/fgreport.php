<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<form id="form1" name="form1" method="post" action="">
    <table width="710" border="1" align="center" class="table01">
        <tr>
            <td width="313" height="37">
                <div class="tmagin_right">Search : Model No., Model Code, Model Name</div>
            </td>
            <td width="381">
                <input type="text" name="tsearch" id="tsearch" style="width:180px;" value="<?= htmlspecialchars(@$_POST['tsearch']) ?>"/>
                <input type="submit" name="button" id="button" value="Search" />
            </td>
        </tr>
    </table>
</form>

<div class="rightPane">
<?php
// Assume $con is a valid mysqli connection

function getSearchText() {
        if (!empty($_POST['tsearch'])) {
                return $_POST['tsearch'];
        }
        if (!empty($_GET['serh'])) {
                return $_GET['serh'];
        }
        return '';
}

$txtsearch = getSearchText();
$searchCondition = '';
if ($txtsearch !== '') {
        $txtsearch_esc = mysqli_real_escape_string($con, $txtsearch);
        $searchCondition = "AND (
                id_print_tag IN (
                        SELECT id_print_tag FROM " . DB_DATABASE1 . ".fgt_supplier_tag_split WHERE tag_no = '$txtsearch_esc'
                )
                OR b.model_code LIKE '$txtsearch_esc%'
                OR b.model_name LIKE '$txtsearch_esc%'
                OR b.tag_model_no LIKE '$txtsearch_esc%'
        )";
}

$query = "
        SELECT 
                a.id_print_tag, a.id_model, a.separate_qty, a.emp_print, a.date_print, a.separate_qty,
                IFNULL(a.emp_print, '-') AS empprint,
                IFNULL(DATE_FORMAT(a.date_print, '%d-%b-%Y %H:%i'), '-') AS dateprint,
                CASE a.print_status WHEN 0 THEN 'fgprint_tag' ELSE 'fgreprint_tag' END AS spstatus,
                CONCAT(b.customer_part_no, '[', b.customer_part_name, ']') AS pcust,
                b.model_picture, b.customer, b.model_code, b.tag_model_no, b.model_name, b.std_qty
        FROM " . DB_DATABASE1 . ".fgt_supplier_tag a
        LEFT JOIN " . DB_DATABASE1 . ".fgt_model b ON a.id_model = b.id_model
        WHERE deleted = '0'
        $searchCondition
        ORDER BY a.id_print_tag DESC
";

$result = mysqli_query($con, $query);
$total = mysqli_num_rows($result);

if ($total > 0) {
        $e_page = 15;
        $chk_page = isset($_GET['s_page']) ? intval($_GET['s_page']) : 0;
        $start = $chk_page * $e_page;

        $pagedQuery = $query . " LIMIT $start, $e_page";
        $pagedResult = mysqli_query($con, $pagedQuery);

        $plus_p = ($chk_page * $e_page) + mysqli_num_rows($pagedResult);
        $total_p = ceil($total / $e_page);
        $before_p = ($chk_page * $e_page) + 1;
        $i = $before_p;
?>
<table width="98%" border="1" bordercolor="#CC9966" class="table01" align="center">
        <tr>
                <th height="27" colspan="11">
                        <div align="center">Tag Reprinting</div>
                </th>
        </tr>
        <tr>
                <th width="3%" height="27">No.</th>
                <th width="5%">Model Code</th>
                <th width="12%"><span class="tmagin_right">Model No. (Tag)</span></th>
                <th width="9%">Model Name</th>
                <th width="8%">Customer</th>
                <th width="16%">Customer Part</th>
                <th width="8%">Std. Qty.</th>
                <th width="7%">Separate Qty.</th>
                <th width="9%">Print By</th>
                <th width="16%">Print Date</th>
                <th width="7%">Print Tag</th>
        </tr>
        <?php while ($rs = mysqli_fetch_assoc($pagedResult)): ?>
        <tr <?= icolor($i) ?> height="28" onMouseOver="className='over'" onMouseOut="className=''" align="center">
                <td><?= $i ?></td>
                <td><?= htmlspecialchars($rs['model_code']) ?></td>
                <td><?= htmlspecialchars($rs['tag_model_no']) ?></td>
                <td><?= htmlspecialchars($rs['model_name']) ?></td>
                <td><?= htmlspecialchars($rs['customer']) ?></td>
                <td><?= htmlspecialchars($rs['pcust']) ?></td>
                <td><?= htmlspecialchars($rs['std_qty']) ?></td>
                <td><?= htmlspecialchars($rs['separate_qty']) ?></td>
                <td><?= htmlspecialchars($rs['empprint']) ?></td>
                <td><?= htmlspecialchars($rs['dateprint']) ?></td>
                <td>
                        <a href="index_fg.php?id=<?= base64_encode($rs['spstatus']) ?>&stag=<?= $rs['id_print_tag'] ?>">
                                <img src="../images/<?= $rs['spstatus'] ?>.png" />
                        </a>
                </td>
        </tr>
        <?php $i++; endwhile; ?>
</table>
<?php if ($total > 0): ?>
        <div class="browse_page">
                <?php page_navigator_user($before_p, $plus_p, $total, $total_p, $chk_page, base64_encode('fgreport'), $txtsearch); ?>
        </div>
<?php endif; ?>
<?php
} else {
        echo "<br/><br/><br/><center><div class='table_comment'>No data available.</div></center>";
}
?>
</div>
