<?php
// ใช้ mysqli แทน mysql_* และใช้ $con เป็น connection

if ($_POST['btnsubmit'] == "submit") {
	$sql_mstr = "SELECT work_id FROM " . DB_DATABASE1 . ".fgt_leader 
		WHERE line_id = '" . $_POST['work_line'] . "' 
		AND work_date = '" . $_POST['work_date'] . "' 
		AND shift = '" . $_POST['work_shift'] . "'";
	$qr_mater = mysqli_query($con, $sql_mstr);
	$rs_mst = mysqli_fetch_array($qr_mater);
	$work_id = $rs_mst['work_id'];
	if (!empty($work_id)) {
		gotopage("index.php?id=" . base64_encode('setup_operetor_emp') . "&wid=$work_id&st=add");
	} else {
		alert('Please check data.');
	}
}
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<SCRIPT LANGUAGE="JavaScript" SRC="../javascript/timepicker.js"></SCRIPT>
<script language="javascript">
function fncSubmit()     
{
	if(document.form1.work_date.value == "")
	{
		alert('Please select work date.');
		return false;
	}
	if(document.form1.work_shift.value == "")
	{
		alert('Please select shift.');
		return false;
	}
	if(document.form1.work_line.value == "")
	{
		alert('Please select line');
		return false;
	}
}
</script>

<div align="center"> 
<br> 
<form action="" method="post" name="form1" id="form1" onSubmit="JavaScript:return fncSubmit();" >
 <?php 
	$p = base64_encode('setup_operator');
	$wd = $_GET['wd'];
 ?>
  <table width="447" border="1" align="center" class="table01" >
	 <th height="29" colspan="2"><div align="center">
		Setup Operator
	 </div></th>
   <tr>
	 <td width="141" height="25" ><div class="tmagin_left">Work Date :</div></td>
	 <td width="263" ><span class="txt-brown-b">&nbsp; 
			 <select name="work_date"  id="work_date"   style="width:80%" 
			 onchange="window.location.href='index.php?id=<?=$p?>&wd='+this.value" >
			<option  value="">---- Please Select Work Date ---- </option>
		<?php
		$sql_w = "SELECT a.work_date,a.shift,a.line_id,b.line_name,a.work_id 
			FROM " . DB_DATABASE1 . ".fgt_leader a
			LEFT JOIN " . DB_DATABASE1 . ".view_line b ON a.line_id = b.line_id
			WHERE a.line_id <> 0 AND b.line_name <> ''
			GROUP BY a.work_date
			ORDER BY a.work_date";
		$qr_w = mysqli_query($con, $sql_w);
		while ($re_w = mysqli_fetch_array($qr_w)) {
			$work_id = $re_w['work_id'];
			$work_date = $re_w['work_date'];
			$line_name = $re_w['line_name'];
			$shift = $re_w['shift'];
			$sell = ($_GET['wd'] == $work_date) ? "selected='selected'" : "";
			echo "<option value=\"$work_date\" $sell > $work_date</option>";
		}
		?>
			</select></span></td>
	</tr>
   <tr>
	 <td  height="25" ><div class="tmagin_left">Shift :</div></td> 
	 <td><span class="txt-brown-b">&nbsp; 
			 <select name="work_shift"  id="work_shift"   style="width:80%"
			 onchange="window.location.href='index.php?id=<?=$p?>&wd=<?=$wd?>&shift='+this.value"
			  >
			<option  value="">---- Please Select Shift ---- </option>
		<?php
		$sql_w = "SELECT a.work_date,a.shift,a.line_id,b.line_name,a.work_id 
			FROM " . DB_DATABASE1 . ".fgt_leader a
			LEFT JOIN " . DB_DATABASE1 . ".view_line b ON a.line_id = b.line_id
			WHERE a.line_id <> 0 AND b.line_name <> '' AND a.work_date = '" . $_GET['wd'] . "'
			GROUP BY a.shift
			ORDER BY a.shift";
		$qr_w = mysqli_query($con, $sql_w);
		while ($re_w = mysqli_fetch_array($qr_w)) {
			$work_id = $re_w['work_id'];
			$work_date = $re_w['work_date'];
			$line_name = $re_w['line_name'];
			$shift = $re_w['shift'];
			$sell = ($_GET['shift'] == $shift) ? "selected='selected'" : "";
			echo "<option value=\"$shift\" $sell> $shift </option>";
		}
		?>
			</select></span></td>
	</tr>
   <tr>
	 <td  height="25" ><div class="tmagin_left">Line :</div></td>
	 <td><span class="txt-brown-b">&nbsp; 
			 <select name="work_line"  id="work_line"   style="width:80%" >
			<option  value="">---- Please Select Line ---- </option>
		<?php
		$sql_w = "SELECT a.work_date,a.shift,a.line_id,b.line_name,a.work_id 
			FROM " . DB_DATABASE1 . ".fgt_leader a
			LEFT JOIN " . DB_DATABASE1 . ".view_line b ON a.line_id = b.line_id
			WHERE a.line_id <> 0 AND b.line_name <> '' 
			AND a.shift = '" . $_GET['shift'] . "' AND a.work_date = '" . $_GET['wd'] . "'
			GROUP BY a.line_id 
			ORDER BY b.line_name";
		$qr_w = mysqli_query($con, $sql_w);
		while ($re_w = mysqli_fetch_array($qr_w)) {
			$line_id = $re_w['line_id'];
			$line_name = $re_w['line_name'];
			echo "<option value=\"$line_id\">$line_name </option>";
		}
		?>
			</select></span></td>
   </tr>
   <tr>
	 <td height="31" colspan="2" align="center">
	   <input name="btnSubmit1" type="submit" value="Submit"   class="myButton" style="width:80px;">
	  <input type="hidden" name="btnsubmit" id="btnsubmit" value="submit" /></td>
   </tr>
 </table>
</form>
</div>
