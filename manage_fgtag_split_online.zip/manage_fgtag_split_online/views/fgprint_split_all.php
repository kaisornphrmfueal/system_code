
<?php
  // ใช้ $con เป็น mysqli connection
//echo "==".$_POST['hbutton'];
  if(!empty($_POST['hbutton']) && $_POST['hbutton']=="Start"){ 
	  $p_tagno= $_POST['htgn'];
	   $p_processst= $_POST['hprocessst'];
	 $p_ticket= $_POST['hticket_no'];
	  
 $sqltg = "SELECT IFNULL(max(id_fg_split),0)+1 AS mxsp from " . DB_DATABASE1 . ".fgt_split_fg_tag";
	$qrtg = mysqli_query($con, $sqltg);
	$rstg = mysqli_fetch_array($qrtg);
	$mxidt=$rstg['mxsp'];
	 //echo $sqltg."<br/>";
	 $sqlck = "SELECT tag_no,id_model,sn_start,sn_end,tag_qty,fg_tag_barcode,matching_ticket_no 
			FROM " . DB_DATABASE1 . ".fgt_srv_tag 
			WHERE tag_no = '$p_tagno' ";
	//echo $sqlck."<br/>";
	$qrck = mysqli_query($con, $sqlck);
	$numck = mysqli_num_rows($qrck);
	if ($numck <> 0) {
		$slit_qty=$_POST['tqty'];//qty per page
		$rsck = mysqli_fetch_array($qrck);
		$rstg=$rsck['tag_no'];
		$original_qty = $rsck['tag_qty'];
		 $fg_tag_bc = $rsck['fg_tag_barcode'];
		  $fg_ticket = $p_ticket ; //$fg_ticket = $rsck['matching_ticket_no'];
	  	$sqlup = "INSERT INTO ".DB_DATABASE1.".fgt_split_fg_tag (id_fg_split,id_model,fg_tag_barcode,tag_no_original,tag_qty,separate_qty,ticket_no,process_status,
		emp_id_insert,date_insert)
		VALUES ('".$mxidt."','".$rsck['id_model']."','".$fg_tag_bc."',
		'".$rstg."','".$original_qty."','".$slit_qty."','".$fg_ticket."','".$p_processst."',
		'$user_login','".date('Y-m-d H:i:s')."')";
		mysqli_query($con, $sqlup);
		 //  echo "22<br/>"; $sqlup."<br/>";
		//------ START UPDATE SUPPLIER TAG-------------------------
		$texttest1 = $rsck['sn_start'];
		$texttest2 = $rsck['sn_end'];
		$all_page = ceil($original_qty / $slit_qty); // Qty per each page  3 page , 3 qty
		$textsub1 = substr($texttest1, 3);
		$textsub2 = substr($texttest2, 3);
		$textsn1 = substr($texttest1, 0, 3);
	//	echo 	$all_page."22<br/>";
		
		$sqlutk="UPDATE  ".DB_DATABASE2.".rf_kanban_ticket SET
				 status_write=5, last_status='Split Reserved'
				 WHERE ticket_ref='$fg_ticket'";
		$qrtk=mysqli_query($con, $sqlutk); //Reserved
					 
		for ($p = 1; $p <= $all_page; $p++) {
		
			if ($p == $all_page) {
			//	echo 	$all_page."22<br/>";
				 $sqlmxcon = "SELECT IFNULL(max(id_fg_tag_conversion),0)+1 AS mxcon 
				 				from " . DB_DATABASE1 . ".fgt_split_fg_tag_conversion";
				$qrmxcon = mysqli_query($con, $sqlmxcon);
				$rsmxcon = mysqli_fetch_array($qrmxcon);
				$mxcon=$rsmxcon['mxcon'];
				
				$jnum = ($textsub2 - $textsub1) + 1;
				 $sqls = "INSERT INTO " . DB_DATABASE1 . ".fgt_split_fg_tag_conversion SET 
				 id_fg_tag_conversion='$mxcon', 	id_fg_split='" . $mxidt . "',
					 sn_start='" . $textsn1 . sprintf("%05d", $textsub1) . "', 
					sn_end='" . $textsn1 . sprintf("%05d", $textsub2) . "',stag_qty='$jnum' ";
				mysqli_query($con, $sqls);
				//  echo $sqls."11<br/>";
				while ($textsub1 <= $textsub2) {
						//--Insert all Serial
		
	 				$sql_serial =  "INSERT INTO ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial 
									(id_fg_tag_conversion,serial_label)
									VALUES ('$mxcon','" . $textsn1 . sprintf("%05d", $textsub1) . "') " ;
						mysqli_query($con, $sql_serial);
					
					$textsub1++;
				}
			} else {
				 $sqlmxcon = "SELECT IFNULL(max(id_fg_tag_conversion),0)+1 AS mxcon 
				 				from " . DB_DATABASE1 . ".fgt_split_fg_tag_conversion";
				$qrmxcon = mysqli_query($con, $sqlmxcon);
				$rsmxcon = mysqli_fetch_array($qrmxcon);
				$mxcon=$rsmxcon['mxcon'];
				
				$tstxxx = $textsub1 + $slit_qty;
				$sqls = "INSERT INTO " . DB_DATABASE1 . ".fgt_split_fg_tag_conversion SET 
							id_fg_tag_conversion='$mxcon',  id_fg_split='" . $mxidt . "',
					 sn_start='" . $textsn1 . sprintf("%05d", $textsub1) . "',
					sn_end='" . $textsn1 . sprintf("%05d", ($tstxxx - 1)) . "' ,stag_qty='$slit_qty'";
				mysqli_query($con, $sqls);
				//echo $sqls."22<br/>";
				while ($textsub1 < $tstxxx) {
							//--Insert all Serial
	 				$sql_serial =  "INSERT INTO ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial 
									(id_fg_tag_conversion,serial_label)
									VALUES ('$mxcon','" . $textsn1 . sprintf("%05d", $textsub1) . "') " ;
						mysqli_query($con, $sql_serial);
					
					$textsub1++;
				}
			}
		}
		//------ END  UPDATE SUPPLIER TAG-------------------------
	
   gotopage("index_fg.php?id=".base64_encode('fgprint_split_tag')."&stag=$mxidt"."&idproc=$p_processst");
	}
	  
	  
    
	  
	  
  }//if(!empty($_POST['hbutton']) && $_POST['hbutton']=="Start"){ 
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">

</script>


 <div class="rightPane" align="center">
<?php
	// echo "empty".$_POST['tsearch'];
    if(!empty($_POST['tsearch'])){
		 $sh_barcodetag=$_POST['tsearch'];
		// $sh_sticket=$_POST['sticket'];
		 $sh_process_st=$_POST['process_st']; //0=Split Normal , 1 = Split special
		if($sh_process_st=="0"){  $pagedr="fgprint_split_normal";
							   }else{  $pagedr="fgprint_split_special";}
     
      $sqlckh = "SELECT c.item_status,c.id_fg_split,c.process_status
          FROM ".DB_DATABASE1.".fgt_split_fg_tag c 
          WHERE c.fg_tag_barcode ='".$sh_barcodetag."' 
		  AND c.item_status in (0,1) 
		  ORDER BY c.id_fg_split DESC ";//AND process_status ='$sh_process_st'
      $qrckh = mysqli_query($con, $sqlckh);
      $rsckh = mysqli_fetch_array($qrckh);
      $totalck = mysqli_num_rows($qrckh); 
	if($totalck != 0){  
		$item_id=$rsckh['id_fg_split'];
	//	echo "gotopage split".$item_status;
			  gotopage("index_fg.php?id=".base64_encode('fgprint_split_tag')."&stag=$item_id"."&idproc=$sh_process_st");
		 // 0= start, 1= spliting,  2= finished, 3=cancel
		
	}else{	
		
		 $sql = "SELECT a.tag_no,a.tag_qty,a.matching_ticket_no,c.item_status,c.id_fg_split,
	  		b.id_model,b.model_code,b.model_name,b.tag_model_no,b.customer,b.std_qty,
          b.customer_part_no,b.customer_part_name,b.model_picture,b.status_tag_printing
          FROM ".DB_DATABASE1.".fgt_srv_tag a 
          LEFT JOIN ".DB_DATABASE1.".fgt_model b ON a.id_model =b.id_model
          LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag c ON  a.tag_no =c.tag_no_original
          WHERE a.fg_tag_barcode ='".$sh_barcodetag."'   ";
      $qr = mysqli_query($con, $sql);
      $rs = mysqli_fetch_array($qr); 
		 $item_status=$rs['item_status'];
		if(is_null($item_status) || $item_status == '3'){ 	 
		// kt
		//select data same model ==> 
	 	   $sql_sm = "SELECT a.tag_no_original,a.tag_qty,a.item_status,
		  b.id_model,b.model_code,   b.model_name,b.tag_model_no,b.customer,b.std_qty,
          b.customer_part_no,b.customer_part_name,b.model_picture,b.status_tag_printing,
		CONCAT( d.name_en ,'[', DATE_FORMAT(c.date_conversion, '%d-%b-%Y %H:%i'),']') AS conv_date  
          FROM ".DB_DATABASE1.".fgt_split_fg_tag  a 
          LEFT JOIN ".DB_DATABASE1.".fgt_model b ON a.id_model =b.id_model 
		  LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion c ON a.id_fg_split =c.id_fg_split
		  LEFT JOIN ".DB_DATABASESSO.".so_view_fttl_and_sub d ON c.emp_conversion =d.emp_id 
          WHERE a.item_status ='1' AND b.id_model ='".$rs['id_model']."'
		  GROUP BY a.tag_no_original";// AND process_status='$sh_process_st'
      $qr_sm = mysqli_query($con, $sql_sm);
      $rs_sm = mysqli_fetch_array($qr_sm);
	   $total_sm = mysqli_num_rows($qr_sm); 
	  if($total_sm != 0){
		  alert("Model No. นี้มี FG TAG ที่ถูก Split ค้างอยู่ Tag No.=  ".$rs_sm['tag_no_original']." Split By ".$rs_sm['convuser'].$rs_sm['conv_date'])  ; //select data same model ==> 
		//  gotopage("index_fg.php?id=".base64_encode($pagedr));
	  }else{
		  
	  }// if($total_sm != 0){// have model separate
	  
			
?>
 <form action="" method="post"  name="form2" id="form2"  onsubmit='return validate(this)' autocomplete="off">
<table width="600px"  border="1" class="table01" align="center">

  <tr>
  <th height="27" colspan="2">Separate FG Tag and Supplier Tag</th>
  </tr>
  <tr>
    <td width="452" height="25"><div class="tmagin_left">Model Picture :</div></td>  
    <td width="682"><div class="tmagin_right">
  <?php 
     if(!empty($rs['model_picture'])){
      echo "<img src='".DIR_UPLOAD.DIR_MPIC.$rs['model_picture']."' />";    
      //echo "<img src='".HTTP_SERVER_TRUE.DIR_PAGE.DIR_VIEWS.DIR_UPLOAD.DIR_MPIC.$rs['model_picture']."' />";    
      }
     ?>
    </div>
    </td>
  </tr>
  <tr>
    <td height="25"><div class="tmagin_left">Tag No. :</div></td>
    <td><div class="tmagin_right"> <?php echo $rs['tag_no'];?> </div></td>
  </tr>
  <tr>
    <td height="25"><div class="tmagin_left">Ticket No. :</div></td>
    <td><div class="tmagin_right"> <?php echo  $sh_sticket=$rs['matching_ticket_no'];?> </div></td>
  </tr>
  <tr>
  <td width="452" height="25"><div class="tmagin_left">Model Code. :</div></td>  
  <td width="682"><div class="tmagin_right">
   <?php echo $rs['model_code'];?>
  </div></td>
  </tr>
   <tr>
  <td width="452" height="25"><div class="tmagin_left">Model No. (Tag) :</div></td>
  <td width="682"><div class="tmagin_right">
   <?php echo $rs['tag_model_no']." [".$rs['model_name']."]"; ?>
  </div></td>
  </tr>
   <tr>
   <td width="452" height="25"><div class="tmagin_left">Customer Name :</div></td>  
   <td width="682"><div class="tmagin_right"> 
   <?php echo $rs['customer'];?></div></td>
   </tr>
   <tr>
     <td width="452" height="25"><div class="tmagin_left">Customer Part No.   :</div></td>
     <td width="682"><div class="tmagin_right"> 
       <?php echo $rs['customer_part_no']." [".$rs['customer_part_name']."]";?></div></td>
   </tr>
   <tr>
     <td height="25"><div class="tmagin_left">Standard  Qty.    :</div></td>
     <td><div class="tmagin_right"> <?php echo $rs['std_qty'];?></div></td>
   </tr>
   <tr>
     <td height="25"><div class="tmagin_left">FG Tag   Qty.    :</div></td>
     <td><div class="tmagin_right"> <?php echo $rs['tag_qty'];?></div></td>
   </tr>
   <tr>
     <td width="452" height="25"><div class="tmagin_left">Separate Tag Qty/page :</div></td>  
     <td width="682"><div class="tmagin_right">
       <select name="tqty" id="tqty">
         <?php  
		
			for ($j=1;$j<$rs['tag_qty'];$j++){
       echo " <option value='$j'>$j</option>";
   }?>
         </select>
       </div>
       </td>
   </tr>
  <td height="25" colspan="2" align="center">
    <input id='button'  name='button' type='submit' value='Start' />
    <input type="hidden" name="hbutton" id="hbutton" value="Start" />
	  <input type="hidden" name="hprocessst" id="hprocessst"  value="<?=$sh_process_st?>"/> 
	   <input type="hidden" name="hticket_no" id="hticket_no"  value="<?=$sh_sticket?>"/>
 <!--   <input type="hidden" name="hmodel" id="hmodel"  value="<?=$rs['id_model']?>"/>-->
	<!--   <input type="hidden" name="htgqty" id="htgqty"  value="<?=$rs['tag_qty']?>"/>-->
<!--	  <input type="hidden" name="htbarcode" id="htbarcode"  value="<?=$sh_barcodetag?>"/>-->
    <input type="hidden" name="htgn" id="htgn"  value="<?=$rs['tag_no']?>"/></td>
  </tr>
</table>
 </form>  
 <?php 

	       
			
		}else{ //2= finished
			alert("Tag no นี้ ถูก Split แล้ว กรุณาแสกน Tag No.อื่น");
			gotopage("index_fg.php?id=".base64_encode($pagedr));
		 //echo "finished => Tag no นี้ ถูก Split แล้ว กรุณาแสกน Tag No.อื่น";
  ?>

 <?php 	 
		}//if(is_null($item_status )){  

	  }
		
		
		
		
		
     ?>
 <?php }else{
          echo "<br/><br/><br/><center><div class='table_comment' >กรุณาแสกน FG Tag Original ";
		
		//gotopage("index_fg.php?id=".base64_encode($pagedr));
      }
     ?>
</div>
