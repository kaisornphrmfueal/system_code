<?php

require_once '../includes/configure_host.php';
//include('../includes/configure.php');
				
if(!empty($_GET["guser"]) && $_GET["guser"]<>"undefined"){
	
	 $gusern=$_GET["guser"];
  	$gpassw=$_GET["gpass"];


		  $sqltk=" SELECT u.Username
				FROM ".DB_DATABASE4.".user u
				WHERE u.Username = '$gusern' AND u.Password = '$gpassw' 
				AND u.user_status = '1' AND u.Userlevel = 'Admin'   ";
		  $rstk = mysqli_query($con, $sqltk);

if(mysqli_num_rows($rstk)!= 0){
		$rstksp = mysqli_fetch_array($rstk);
		$rsuser = $rstksp['Username'];
		if($rsuser != ""){
			echo $rsuser;
			}else{
				echo "No";
				// echo $mxsrl ;
			}//if($gserial-$rscht['mxtag']==1){

		
}else{
	 echo "No";
	 // echo $sqlg;
	}
 }//  if(!empty($_GET["code"]) && $_GET["code"]<>"undefined"){


?>