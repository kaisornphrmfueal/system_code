<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<div class="rightPane" align="center">
	<form id="form1" name="form1" method="post" action="">
	 <table width="710" border="1" align="center" class="table01" >
		 <tr>
			 <td width="398" height="37"><div class="tmagin_right">Search : Type Data or Last ID Client Download or Line Name</div> </td>
			 <td width="296">
							<input type="text" name="tsearch" id="tsearch" style=" width:180px;"  value="<?php echo @$_POST['tsearch']?>"/>
				 
<input type="submit" name="button" id="button" value="Submit" /></td>
		 </tr>
	 </table>
</form>
	<br/>
<input type="button" value="Refresh Page" onClick="window.location.reload()">
<?php
		// สมมติว่ามี $con เป็น mysqli connection แล้ว
		if(!empty($_POST['tsearch']) || !empty($_GET['serh'])){
				if(!empty($_POST['tsearch'])){
						$txtsearsh = $_POST['tsearch'];
				}else{
						$txtsearsh = $_GET['serh'];
				}
				// escape string เพื่อป้องกัน SQL Injection
				$txtsearsh_esc = mysqli_real_escape_string($con, $txtsearsh);
				$x = "WHERE ((a.type_data LIKE '%$txtsearsh_esc%') OR (a.last_id_update LIKE '%$txtsearsh_esc%') OR (b.line_name LIKE '%$txtsearsh_esc%'))";
		}else{ 
				$x = "";
		}
		$q = "SELECT a.line_id,a.action_name,a.type_data,a.last_id_update,a.ip_address,b.line_name, 
				DATE_FORMAT(a.record_date, '%d-%b-%Y %H:%i') AS date_modify
				FROM ".DB_DATABASE1.".fgt_log_download a 
				LEFT JOIN ".DB_DATABASE1.".view_line b ON a.line_id=b.line_id
				$x
				ORDER BY a.record_date DESC";
		$qr = mysqli_query($con, $q);
		$total = mysqli_num_rows($qr);  

		if($total != 0) {	
				$e_page = 30; // จำนวนรายการต่อหน้า
				if(!isset($_GET['s_page'])){
						$_GET['s_page'] = 0;
						$chk_page = 0;
				}else{
						$chk_page = $_GET['s_page'];
						$_GET['s_page'] = $_GET['s_page'] * $e_page;
				}
				$q .= " LIMIT ".$_GET['s_page'].",$e_page";
				$qr = mysqli_query($con, $q);
				if(mysqli_num_rows($qr) >= 1){
						@$plus_p = ($chk_page * $e_page) + mysqli_num_rows($qr);
				}else{
						@$plus_p = ($chk_page * $e_page);
				}
				$total_p = ceil($total / $e_page);
				@$before_p = ($chk_page * $e_page) + 1; 
				$i = 1;
?>
<table width="651" border="1" bordercolor="#CC9966"class="table01" align="center">
		<tr >
			<th height="26" colspan="5">
			<div align="center">History client downloading</div>  </th>
			</tr>  
		<tr>
			<th width="5%" height="26">No.</th>
			<th width="18%">Type DataId </th>
			<th width="30%">Last ID Client Download <br />
			(ID Update)</th>
			<th width="25%">User Update</th>
			<th width="22%">Date Updated</th>
		</tr>
			 <?php while($rs = mysqli_fetch_array($qr)) { ?>
			<tr <?php $v = 0; $v = $v + 1; echo  icolor($v); ?> height="28" onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" align="center">
			<td><?=$i?></td>
			<td><?=$rs['type_data']?></td>
			<td><?=$rs['last_id_update']?></td>
			<td><?=$rs['line_name']?></td>
			<td><?=$rs['date_modify']?></td>
		</tr>
		 <?php 
				$i++;
				}
		?>
	</table>
		<?php
				if($total > 0){ ?>  
<div class="browse_page" >
		<?php @page_navigator_user($before_p, $plus_p, $total, $total_p, $chk_page, base64_encode('client_download_report'), $txtsearsh); ?>
	</div>  
<?php }
		}else{
				echo "<br/><br/><br/><center><div class='table_comment' >No have History client downloading  ";
		}
?>
</div>
</div>
