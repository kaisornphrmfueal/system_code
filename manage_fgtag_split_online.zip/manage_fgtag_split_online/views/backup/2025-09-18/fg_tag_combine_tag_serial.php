
<?php


//echo "<br/>--". $_POST['button2'].$_POST['hidsplit'];
if(!empty($_POST['button2']) && $_POST['button2']=="Submit" && !empty($_POST['hidcombine']) ){ 
$pcombineid= $_POST['hidcombine'];
$pidcombintag= $_POST['hidcombinetag'];
$phcombqtyremain= $_POST['hcombqtyremain'];
//echo "<br/>--".$phcombtagqty= $_POST['tagqtys'];	
$psccanmodel =$_POST['model']; 	
$phidtagno =$_POST['hidtagno'];	
$pgmslb =$_POST['hidprocsplit'];	
$pidconver =$_POST['hidconver'];	
	$pgmslabelbarcode= $_POST['gms_label'];
	$pgmslabel= substr($pgmslabelbarcode,64,9);
	
	$gmodel = substr($psccanmodel,0,15);
	$gserial=substr($psccanmodel,16,8);
	//0= start, 1= spliting,  2= finished, 3=cancel

	// COUNT ALL TAG serial_label_confirm IS NULL == COMBINE QTY => UPDATE STATUS TO START 
		$sql_countstart="SELECT COUNT(id_combine_serial) AS counttagscan,b.tag_qty 
					FROM ".DB_DATABASE1.".fgt_split_combine_fg_tag b
					LEFT JOIN   ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial c ON b.id_fg_combine_tag =c.id_fg_combine_tag 
					 WHERE  b.id_fg_combine_tag= $pidcombintag  
					   AND c.gms_label_ref IS  NULL ";
	
		$qr_count_st=mysqli_query($con, $sql_countstart);
	   $rsstcount_st=mysqli_fetch_array($qr_count_st);	
		$tagcounts=$rsstcount_st['counttagscan'];
		$tag_qtychk=$rsstcount_st['tag_qty'];
	 
		if($tagcounts==$tag_qtychk){ 
			///Start UPDATE TAG AND STATUS COMBINE
			
					$sql_updateold="UPDATE ".DB_DATABASE1.".fgt_srv_tag SET 
											status_fg_reprint='4',tag_location='7',
											date_fg_reprint='".date('Y-m-d H:i:s')."'
											WHERE tag_no=$phidtagno"; // UPdate old TAG
								mysqli_query($con, $sql_updateold); 
			
			//0= Not yet , 1= Reprint, 2 = Split Normal Case ,3=Split Special Case, 4= Combine (DOM)
			//0=Tag Reserved ,1=Line Printed ,2= BSI Passed , 3 = Packing Passed, 4 =FG Passed, 5 = PC Cancel, 6= FG Splite , 7 FG Combine, 8= Line cancel, 9= Line conversion, 10 = FG Modify
							
							
							 $pidsplitcon = (empty($pidconver) || $pidconver == 0) ? 'NULL' : (int)$pidconver;

							$sql_uptag="UPDATE  ".DB_DATABASE1.".fgt_split_combine a
							LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag b ON a.id_combine = b.id_combine 
							LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion c ON b.fg_tag_barcode_original=c.tag_no_new 
									SET b.process_tag_from='$pgmslb',
										b.id_fg_tag_conversion=$pidsplitcon,
										a.item_status='1',
										c.item_status ='2'
									WHERE b.id_fg_combine_tag='$pidcombintag'   ";
							mysqli_query($con, $sql_uptag); 

		}//  UPDATE TAG AND STATUS COMBINE
	
	
	
		 $sqlg="SELECT MIN(c.id_combine_serial)AS idconserial,c.serial_label,d.tag_model_no,
		 b.tag_no_original,b.tag_qty,a.item_status,b.id_fg_combine_tag ,a.combine_qty,
		 b.sn_start,b.sn_end, COUNT(c.id_combine_serial ) AS countnull ,
		 IF(COUNT(c.id_combine_serial )  > 1, '0', '1') AS countup
        FROM  ".DB_DATABASE1.".fgt_split_combine AS a 
		LEFT JOIN  ".DB_DATABASE1.".fgt_split_combine_fg_tag AS b ON a.id_combine=b.id_combine 
		LEFT JOIN  ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial c ON b.id_fg_combine_tag =c.id_fg_combine_tag 
		  LEFT JOIN  ".DB_DATABASE1.".fgt_model d ON b.id_model =d.id_model
          WHERE b.id_fg_combine_tag ='$pidcombintag' 
		  AND serial_label_confirm IS  NULL    ";
		  $resultg = mysqli_query($con, $sqlg);
		if(mysqli_num_rows($resultg)<>0){
			//select count MAIN MOM TAG 
			//	$pline=$_POST['hslid'];
			$rstg = mysqli_fetch_array($resultg);
	
				$serial = $rstg['serial_label'];
				$tagmodel = $rstg['tag_model_no'];
				$idconser = $rstg['idconserial'];
				$count_allTag=$rstg['countnull'];
			 $countupd=$rstg['countup'];
			if($serial == $gserial ){
					if($phcombqtyremain==1){
						//Print Tag
						$sqlutk="UPDATE  prod_fg_tag.fgt_split_combine a
								LEFT JOIN prod_fg_tag.fgt_split_combine_fg_tag b ON a.id_combine = b.id_combine 
								LEFT JOIN prod_fg_tag.fgt_split_combine_fg_tag_serial c ON b.id_fg_combine_tag=c.id_fg_combine_tag 
								SET b.item_status=1,
									a.item_status='2',
									a.date_combine='".date('Y-m-d H:i:s')."',a.emp_id_combine='$user_login',
									c.serial_label_confirm='$psccanmodel',c.gms_label_ref='$pgmslabel',
									c.gms_label_ref_barcode='$pgmslabelbarcode',
									c.date_scan_confirm='".date('Y-m-d H:i:s')."',c.emp_scan_confirm='$user_login'
								WHERE c.id_combine_serial='$idconser'  ";
								$qrtk=mysqli_query($con, $sqlutk); 

						//------
						
						
						$sqlcbtg = "SELECT f.id_model, m.status_tag_printing, f.tag_no_original 
									FROM ".DB_DATABASE1.".fgt_split_combine_fg_tag  f
									LEFT JOIN ".DB_DATABASE1.".fgt_model m ON f.id_model =m.id_model 
									WHERE f.id_combine='$pcombineid'
									GROUP BY f.id_model  
									ORDER BY f.id_model DESC ";
		
						$qrmo = mysqli_query($con, $sqlcbtg);
						$qrmomax = mysqli_query($con, $sqlcbtg);
						$totalmo = mysqli_num_rows($qrmo);	
					if ($totalmo != 0) {
						$rsmomax = mysqli_fetch_array($qrmomax);
						// START Print Suppllier TAG 
						if($rsmomax['status_tag_printing']==0){
							$mxsptag=$rsmomax['tag_no_original'];
							printTagCombineSupplier($mxsptag,$pcombineid);
						}
						
						
						///------END  Print Suppllier TAG -------
						
						while ($rsmo = mysqli_fetch_array($qrmo)) {
							$modelqrcomb=$rsmo['id_model'];
							$sql_maxtag="
							SELECT t2.tag_no_original,a.date_print ,f.id_model,SUM(f.tag_qty) AS tagqt,t2.date_print
							FROM  ".DB_DATABASE1.".fgt_split_combine_fg_tag  f
							LEFT JOIN  ".DB_DATABASE1.".fgt_srv_tag  a  ON f.tag_no_original =a.tag_no 
							INNER JOIN (
								SELECT f.tag_no_original,MAX(a.date_print ) AS date_print  ,f.id_model,f.id_combine
								FROM  ".DB_DATABASE1.".fgt_split_combine_fg_tag  f
								LEFT JOIN  ".DB_DATABASE1.".fgt_srv_tag  a  ON f.tag_no_original =a.tag_no 
								WHERE a.date_print = (SELECT MAX(a.date_print ) 
												FROM  ".DB_DATABASE1.".fgt_split_combine_fg_tag f 
								 			LEFT JOIN  ".DB_DATABASE1.".fgt_srv_tag a ON f.tag_no_original =a.tag_no
											 WHERE f.id_combine='$pcombineid' AND f.id_model = '$modelqrcomb'    ) 
								) t2 ON f.id_combine = t2.id_combine AND f.id_model=t2.id_model  
							WHERE   f.id_model = '$modelqrcomb'
							GROUP BY f.id_combine , f.id_model  ";
								$qr_maxtag=mysqli_query($con, $sql_maxtag);
							   $rsmaxtag=mysqli_fetch_array($qr_maxtag);	
								$mxtagn=$rsmaxtag['tag_no_original'];
								$tagqtymodel=$rsmaxtag['tagqt'];
							
							//echo "</br>--".$pcombineid;
								
										printTagCombine($mxtagn,$pcombineid,$tagqtymodel,$modelqrcomb); 
						
						sleep(3);
						

						}//while ($rsmo = mysqli_fetch_array($qrserial)) {
					}//if($phcombqtyremain==1){

						
						
						//---------
						
						
						
										//eprinTag
											log_hist($user_login,"Printed Tag Combibe",$pcombineid,"fgt_srv_tag","");
										//---END  Checking Qty if 1 print -----------		
										
									gotopage("index_fg.php?id=".base64_encode('fg_tag_combine_tag'));

								//Print Tag
					}else{
						// check remain and go save and go 

						$sqlutk="UPDATE   prod_fg_tag.fgt_split_combine_fg_tag b
								LEFT JOIN prod_fg_tag.fgt_split_combine_fg_tag_serial c ON b.id_fg_combine_tag=c.id_fg_combine_tag 
								SET b.item_status='$countupd',
									c.serial_label_confirm='$psccanmodel',c.gms_label_ref='$pgmslabel',
									c.gms_label_ref_barcode='$pgmslabelbarcode',
									c.date_scan_confirm='".date('Y-m-d H:i:s')."',c.emp_scan_confirm='$user_login'
								WHERE c.id_combine_serial='$idconser'  ";
						$qrtk=mysqli_query($con, $sqlutk); 
						if( $count_allTag == "1" ){ //split qty  Or remain ==1
							gotopage("index_fg.php?id=".base64_encode('fg_tag_combine_tag_start')."&combid=$pcombineid");
						}else{
							gotopage("index_fg.php?id=".base64_encode('fg_tag_combine_tag_serial')."&combid=$pcombineid&tagid=$pidcombintag");
						}


					}//	if($phcombqtyremain==1){

	
				}elseif ($tagmodel != $gmodel ) {
						 alert("Model No. ไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่อีกครั้ง");
					gotopage("index_fg.php?id=".base64_encode('fg_tag_combine_tag_serial')."&combid=$pcombineid&tagid=$pidcombintag");
				}else{
						 alert("Serial No. ไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่อีกครั้ง");
						gotopage("index_fg.php?id=".base64_encode('fg_tag_combine_tag_serial')."&combid=$pcombineid&tagid=$pidcombintag");
						// echo $mxsrl ;
					}//if($gserial-$rscht['mxtag']==1){


		}else{
			 alert("ข้อมูลไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่อีกครั้ง");
		 gotopage("index_fg.php?id=".base64_encode('fg_tag_combine_tag_serial')."&combid=$pcombineid&tagid=$pidcombintag");
			 // echo $sqlg;
			}

	
	
	
	
	
		
		
	
}//if(!empty($_POST['button2']) && $_POST['button2']=="Submit" && !empty($_POST['hidsplit']) ){ 
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">
window.onload = function() {


	
	let hidprocesssplit=document.getElementById("hidprocsplit").value;
		//alert("+++"+hidprocesssplit); 
			if(hidprocesssplit != "0"){ 
				document.getElementById("gms_label").focus();
	  			document.getElementById("gms_label").select(); 
				document.getElementById("model").disabled = false;
				document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน GMS Label ref. </span>';
			}else{
			 
				document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน Serial Label หลังเครื่อง</span>';
				document.getElementById("model").disabled = false;
				document.getElementById("model").focus();
	
			}//if(hidprocesssplit != "no"){
		
	
	document.getElementById("btnscan").disabled = true;
}//window.onload = function() {


	
	
	//======
function ckKeyPresse1(e) 
{

    // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
		document.getElementById("btnscan").disabled = false;
        document.getElementById('btnscan').click();
		//alert( document.getElementById('btnscan').value)
		 return false;
   
    }    return true;

    
}//  if (e.keyCode == 13)
	
	
///START SMG label Ref
	
	
 function ckGMSla(e) {
	  // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
        let val=document.getElementById("gms_label").value.toString();
	 let len = val.length;
//alert(len);
		 
		  //----- START CHECK  Ticket special
			//  alert(document.getElementById("gms_label").value);
		 let txsplit_tagnew_qty = document.getElementById("split_tagnew_qty").innerHTML; 
		 let ticketck=document.getElementById("gms_label").value;
		 let tagmodel=document.getElementById("txtModel").innerHTML;
	
		 if( len == 77){//Nomal
			 
			 let chkhidgmsref=document.getElementById("hidgmsref").value;  
			 let mol = ticketck.substring(3, 18);
			let modl = mol.replace("/", "-");
			let tks = ticketck.substring(64, 73);
			 let tkbarc = ticketck.replace("/", "-");
				 if(modl != tagmodel){
				document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >ข้อมูล Model No. ใน GMS label Ref.  ไม่ตรงกับ F/G Transfer Tag (Original) กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("gms_label");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("btnscan").disabled = true;
				}else if(chkhidgmsref != tks){
					//alert(chkhidgmsref +"!= "+tks);
						 document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >ข้อมูล   GMS label Ref.  ไม่ตรงกับข้อมูลที่แสกน กรุณาแสกน GMS label Ref. ใหม่  </span>';
						const input = document.getElementById("gms_label");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("btnscan").disabled = true;
				}else{
					document.getElementById("gms_label").value=tkbarc;
					document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน Serial Label หลังเครื่อง</span>';
						document.getElementById("model").disabled = false;
						document.getElementById("model").focus();
						  document.getElementById("gms_label").readOnly = true;
				}// if(modl!=tagmodel){
			 
		 }else{
			  const input = document.getElementById("gms_label");
						  input.focus();
						  input.select(); // Update for handheld
		document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน  GMS Label Ref.</span>';
			 
		 }//if( len == 77){//Nomal
		
		///=---------
		 return false;
   	 
    }    // if (e.keyCode == 13)
	 return true; 


 }// function ckGMSla(e) {


		
	
	//======
	
	
// END GMS Label Ref	
	
//------
	function validatecombineTag(my_request) {
	var sModel=document.getElementById("model").value;
	var subModel = sModel.substring(0, 15);
	var idcombin= document.getElementById("concombin").innerHTML;
				 
	let lengthm = sModel.length;
				//	alert(idcombin); 
	if (sModel == "" || lengthm != 24){
		document.getElementById("model").select();
		document.getElementById("model").focus();
		document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" ><img src="../images/no.gif"  /> <br/>กรุณาแสกนซีเรียลลาเบล</span>';//Please scan model no.
		return false;
		}else{
			
		
				if (document.getElementById("model").value.length < 16 ){
					
					document.getElementById("model").select();
					document.getElementById("txtStatus").innerHTML  = '<span class="txt-red-b-s" ><img src="../images/no.gif"  /><br/>ข้อมูลไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่</span>';
				}else{
				//alert(sModel.length);
				
					
				//S-------------------------------------------------------------------------------------------	
					if (window.XMLHttpRequest) {
						// code for IE7+, Firefox, Chrome, Opera, Safari
						xmlhttp = new XMLHttpRequest();
					} else {
						// code for IE6, IE5
						xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
					}
					xmlhttp.open("GET","chklabelcombine.php?tcomb="+idcombin+"&modelsr="+sModel,true); 
					xmlhttp.onreadystatechange = function() {
						if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
						  // document.getElementById("txtHint").innerHTML = xmlhttp.responseText;
							var qrTxt= xmlhttp.responseText;
							var rqrTxt= qrTxt.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '')
							//alert(rqrTxt);
							switch(rqrTxt) {
									case "Wrong":
										document.getElementById("model").select();
										document.getElementById("txtStatus").innerHTML  = '<span class="txt-red-b-s" ><img src="../images/no.gif"  /><br/>Serial No. ไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่</span>';
										break;
									case "No":
										document.getElementById("model").select();
										document.getElementById("txtStatus").innerHTML  = '<span class="txt-red-b-s" ><img src="../images/no.gif"  /><br/>ข้อมูลโมเดลที่แสกนไม่ตรงกับในระบบ กรุณาแสกนโมเดลที่ถูกต้อง</span>';
										break;
									case "1":
										document.getElementById("txtStatus").innerHTML  = '<span class="txt-green-b-s" ><img src="../images/yes.gif"  /><br/>ข้อมูลถูกต้อง ระบบกำลังบันทึกข้อมูล...</span>';//Please scan model no.
										document.getElementById("scan").submit();
										break;
									case "Non":
										document.getElementById("model").select();
										document.getElementById("txtStatus").innerHTML  = '<span class="txt-red-b-s" ><img src="../images/no.gif"  /><br/>ข้อมูลไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่</span>';
										break;
									default:
										document.getElementById("model").select();
										document.getElementById("txtStatus").innerHTML  = '<span class="txt-red-b-s" ><img src="../images/no.gif"  /><br/>ข้อมูลไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่</span>';
										break;
								} //	switch(rqrTxt) {
						}
						
					};
				// xmlhttp.send();
				 xmlhttp.send(null)
				
				
				//E-------------------------------------------------------------------------------------------		
				
				}//	if (document.getElementById("model").value.length < 16 ){
			
				
		}//if (sModel == ""){
}// page print

/*EndReal time printing - printtag.php*/


	
	
	
	
	
</script>

<?php
?>
 <div class="rightPane" align="center">
  <?php
  	//$lineid= $_GET['lid'];

	
  	if (!empty($_GET['combid'])){
		$gidcomb =$_GET['combid'];
		$gtag_id =$_GET['tagid'];
	 	$sql_count_all ="SELECT  COUNT(e.id_combine_serial ) AS count_all  ,c.id_model,b.tag_model_no AS model_st
          FROM ".DB_DATABASE1.".fgt_split_combine  a 
		  LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag c ON a.id_combine =c.id_combine 
		  LEFT JOIN ".DB_DATABASE1.".fgt_model b ON c.id_model =b.id_model 
		  LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial e ON c.id_fg_combine_tag =e.id_fg_combine_tag  AND e.serial_label_confirm IS NOT NULL
		   WHERE  c.id_combine ='$gidcomb'  ";
		$qr_count=mysqli_query($con, $sql_count_all);
	   $rsstcount=mysqli_fetch_array($qr_count);	
		$countall=$rsstcount['count_all'];
	 	$mainmodel=$rsstcount['model_st'];
		
	  	$sql_st="SELECT CASE WHEN d.process_status IS NULL THEN 0  ELSE 1 END AS processst ,
			IFNULL(g.gms_label_ref,'-') AS gms_label_r ,
			IFNULL(f.id_fg_tag_conversion,'0') AS id_fg_tag_convers,
			c.tag_no_original,a.combine_qty,a.item_status,a.id_combine,
			c.id_fg_combine_tag, c.fg_tag_barcode_original,c.ticket_no,c.tag_qty, 
			COUNT(e.id_combine_serial) AS count_scan,
			 b.id_model,b.model_code,   b.model_name,b.tag_model_no,b.customer,b.std_qty,
          b.customer_part_no,b.customer_part_name,b.model_picture,b.status_tag_printing,
		    CONCAT(c.sn_start,'-',c.sn_end) AS allserial,f.id_fg_tag_conversion 
          FROM ".DB_DATABASE1.".fgt_split_combine  a 
		  LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag c ON a.id_combine =c.id_combine 
		  LEFT JOIN ". DB_DATABASE1.".fgt_split_combine_fg_tag_serial e ON c.id_fg_combine_tag =e.id_fg_combine_tag AND e.serial_label_confirm IS NOT NULL 
		  LEFT JOIN ". DB_DATABASE1.".fgt_split_fg_tag_conversion f  ON  c.tag_no_original =f.tag_no_new   
		  									AND f.item_status =1 	
		  LEFT JOIN ". DB_DATABASE1.".fgt_split_fg_tag_conversion_serial g ON f.id_fg_tag_conversion =g.id_fg_tag_conversion  AND g.serial_label_confirm IS NOT NULL 
		   LEFT JOIN ". DB_DATABASE1.".fgt_split_fg_tag d ON f.id_fg_split =d.id_fg_split 	
		   							AND d.item_status = '2' AND process_status='0'
          LEFT JOIN ".DB_DATABASE1.".fgt_model b ON c.id_model =b.id_model 
		   WHERE  c.id_fg_combine_tag='$gtag_id' ";
		
		
		
		
	 // echo $sql_st;
		$qr_st=mysqli_query($con, $sql_st);
		if($num_st=mysqli_num_rows($qr_st)<>0){
			$rsst=mysqli_fetch_array($qr_st);
			$modelid=$rsst['id_model'];
			$id_combine=$rsst['id_combine'];
			$id_fg_combine_tag=$rsst['id_fg_combine_tag'];
			$id_fg_tag_convers=$rsst['id_fg_tag_conversion'];
			$stmodel=$rsst['tag_model_no'];
			$combine_qty=$rsst['combine_qty'];
			$sttag=$rsst['tag_no_original'];
			 $sttag_barc=$rsst['fg_tag_barcode_original'];
			$sttag_qty=(int)$rsst['tag_qty'];
			$stticket=$rsst['ticket_no']; 
			 $split_proces = $rsst['processst'];
			 $id_fg_tag_conver = $rsst['id_fg_tag_convers'];
			$all_serial=$rsst['allserial'];
			
			
  ?>
  

<form name="scan"  id="scan" method="post" action="index_fg.php?id=<?=base64_encode('fg_tag_combine_tag_serial')?>"   onsubmit="return false;"  autocomplete="off" >
            
    <table width="952" height="359" border="1" align="center" class="table01">
              <tr>
                <td height="40" colspan="2" align="center"bgcolor="#70F4ED">
					<span class="text_black">F/G Transfer Tag Combine</span>  </td>
              </tr>
		
	
			<tr bgcolor="#EBF8F7">
			<td height="40" ><div class="tmagin_left"><span class="text_black">Combine Qty. : </span></div></td>
                <td height="40"><div class="tmagin_right"> <span class="txt-black-big">
                  <?php  echo "<span id=txtTag>$combine_qty</span> ";?>
                  </span> ||  <span class="text_black"> Combine Qty. Remaining : </span><span class="txt-blue-big" id="split_tagnew_qty">
                    <?php  echo $combine_remain=$combine_qty-$countall; ?>
                </span></div></td>
      </tr>
		<tr bgcolor="#EBF8F7">
			<td height="40"><div class="tmagin_left"><span class="text_black">Combine Target Model : </span></div></td>
                <td height="40"><div class="tmagin_right"> <span class="txt-black-big">
                
                    <?php  echo $mainmodel; ?>
                </span></div></td>
      </tr>
		
              <tr>
                <td height="40"><div class="tmagin_left"><span class="text_black">Model Curent Scan Data:<br />
                </span></div></td>
                <td height="40"><div class="tmagin_right"> <span class="text_black">
                  <?php  echo "<span id=txtModel>$stmodel</span> ";?> 
                  </span> <span class="txt-blue-big"><?php echo "[".$rsst['model_name']."]"; ?></span>
					<span type="hidden"  name="concombin"  id="concombin" style="display: none" ><?php echo $id_fg_combine_tag;?></span> 
              		<!--   style="display:none;" -->
					
                  <!--0= start, 1= spliting,  2= finished, 3=cancel-->
                </div></td>
              </tr>
              <tr>
                <td width="375" height="40"><div class="tmagin_left"><span class="text_black">Combine Tag  No. :<br />
                </span></div></td>
                <td width="561" height="40">  <div class="tmagin_right">
                <span class="text_black"><?php  echo "$sttag";?> </span>
                <!--0= start, 1= spliting,  2= finished, 3=cancel--></div>
                </td>
              </tr>
          
				   <tr>
                <td height="40"><div class="tmagin_left"><span class="text_black">Ticket  No. : <br />
                </span></div></td>
                <td height="40">  <div class="tmagin_right"> <span class="text_black" id="sticket" >
				<?php  echo $stticket; ?>  || Ticket Qty. :</span>
					<span class="text_black" id="tagqtys" name="tagqtys"  > 	<?php  echo $sttag_qty; ?> </span> 
						<span class="text_black"  > 	Qty. Available: </span>
               
               <span class="txt-blue-big" id="tagqtys"  > 	
				   <?php  
			 $sql_tagq ="SELECT COUNT(*) AS count_scan
							FROM ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial 
							WHERE  serial_label_confirm IS NOT NULL
							AND id_fg_combine_tag='$gtag_id'   ";
		$qr_tagq=mysqli_query($con, $sql_tagq);
	   $rssttagqt=mysqli_fetch_array($qr_tagq);	
		 $count_qty = $rssttagqt['count_scan'];
						echo $sttag_qty-$count_qty; 
				   
				   ?> </span> </div>
                </td>
              </tr>
	
		 <tr>
                <td height="40"><div class="tmagin_left"><span class="text_black">Serial Split Start - End </span><br />
                </div></td>
                <td height="40">  <div class="tmagin_right"> 
                <span class="txt-black-big"><?php  echo "<span id=txtTag>$all_serial</span> ";?>
                </span> </div>
                </td>
              </tr>
           
		
			<?php 
			if($split_proces !="0"){
				
				 $sql_gms ="SELECT serial_label ,serial_label_confirm ,gms_label_ref
							FROM ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial 
							WHERE id_fg_tag_conversion = '$id_fg_tag_convers'
							AND gms_label_ref NOT IN (SELECT gms_label_ref 
														FROM ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial 
														WHERE  id_fg_combine_tag = '$id_fg_combine_tag' 
														AND gms_label_ref IS NOT NULL )
							ORDER BY  id_conversion_serial ASC LIMIT 1   ";
			
		$qr_gms=mysqli_query($con, $sql_gms);
	   $rsgms=mysqli_fetch_array($qr_gms);	
				
				
			$gms_label_ref=$rsgms['gms_label_ref']; 
				
		?>
		<tr>
                <td height="40"><div class="tmagin_left"><span class="text_black">Scan GMS Label ref. : </span><br />
                </div></td>
                <td height="40">  <div class="tmagin_right">
                  <input type="text" name="gms_label" id="gms_label"  class="bigtxtbox" style="width:290px;"  onkeypress="return ckGMSla(event);" onClick="this.select();" />
					<input type="hidden" name="hidgmsref" id="hidgmsref" value="<?=$gms_label_ref?>" />
					<?php 
			
			
			
			
			echo $gms_label_ref ;?>
                </div>
                </td>
      </tr>
		<?php }//if(split_proces=="0"){ ?>
		
                <tr>
                <td height="40"><div class="tmagin_left"> <span class="text_black">Scan Label barcode  : <br />
                </span></div></td> 
                <td >
                <div class="tmagin_right">
               
                  <input type="text" name="model" id="model"  class="bigtxtbox" style="width:290px;"  onkeypress="return ckKeyPresse1(event);" />
				  </div>
             
              </tr>	
				
					<tr>
			     
                <td colspan="2" height="75px"  align="center">
             <div id="txtStatus"></div>

                </td>
              </tr>
				<tr>
                <td height="40" colspan="2" align="center">
              
					
					
					<button onclick="window.location.href='index_fg.php?id=<?php echo base64_encode('fg_tag_combine_tag_start');?>&combid=<?php echo $id_combine ;?>'">Back</button>
					
					  <input type="button" name="btnscan" id="btnscan" value="Submit" class="myButton" onclick="validatecombineTag(this.value)" />
                  	<input type="hidden" name="button2" id="button2"  value="Submit" />  
                  	<input type="hidden" name="hidcombine" id="hidcombine" value="<?=$gidcomb?>" />
					<input type="hidden" name="hidcombinetag" id="hidcombinetag" value="<?=$id_fg_combine_tag?>" />
					<input type="hidden" name="hcombqtyremain" id="hcombqtyremain" value="<?=$combine_remain?>" />
					<input type="hidden" name="hidprocsplit" id="hidprocsplit" value="<?=$split_proces?>" />	
					<input type="hidden" name="hidtagno" id="hidtagno" value="<?=$sttag?>" />
					<input type="hidden" name="hidconver" id="hidconver" value="<?=$id_fg_tag_conver?>" />
					
                </td>
              </tr>	
					
    </table>
  
</form>


<?php
 $qtg = " 
SELECT  c.id_fg_combine_tag,c.serial_label,IF(ISNULL(c.gms_label_ref), '-', c.gms_label_ref)  AS gms_label_r  , c.serial_label_confirm, c.date_scan_confirm, c.emp_scan_confirm,
IF(ISNULL(c.emp_scan_confirm), '-', CONCAT (a.name_en ,'(',c.emp_scan_confirm,')' ))  AS convuser ,
IF(ISNULL(c.emp_scan_confirm), '-',CONCAT('[', DATE_FORMAT(c.date_scan_confirm, '%d-%b-%Y %H:%i'),']')  )  AS conv_date 
        FROM  ".DB_DATABASE1.".fgt_split_combine_fg_tag  b  
		LEFT JOIN ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial c ON b.id_fg_combine_tag =c.id_fg_combine_tag 
		 LEFT JOIN ".DB_DATABASESSO.".so_view_fttl_and_sub a ON c.emp_scan_confirm =a.emp_id 
          WHERE b.id_fg_combine_tag ='$id_fg_combine_tag' AND serial_label_confirm IS NOT NULL   ";
$qrtg = mysqli_query($con, $qtg);
$totaltg = mysqli_num_rows($qrtg);
$j = 1;
	if ($totaltg <> 0) {
	?>
	<table width="950px"  border="1" bordercolor="#CC9966"class="table01" align="center">
		<tr >
		  <th height="27" colspan="6">
		  <div align="center">FG Tag Combine Serial Confirmed</div>  </th>
		  </tr>

		<tr>


		  <th width="5%" height="27">No.</th>
		  <th width="15%">Serial </th>
		  <th width="12%">GMS Rabel Ref.</th>
		  <th width="16%">Serial Label Confirm</th>
		  <th width="13%">Scan by</th>
		  <th width="16%">Scan Date</th>
		</tr>
		   <?php while ($rstg = mysqli_fetch_array($qrtg)) { 
				  ?>
		  <tr  <?php $v = 0; $v = $v + 1; echo icolor($v); ?>height="28" onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" align="center">
		  <td ><?php echo $j ;?></td>
		  <td ><?php echo $rstg['serial_label'] ;?></td>
		  <td ><?php echo $rstg['gms_label_r'] ;?></td>
		  <td><?php echo $rstg['serial_label_confirm'] ;?></td>
		  <td ><?php echo $rstg['convuser']; ?></td>
		  <td><?php echo $rstg['conv_date']; ?></td>
		</tr>
		 <?php
			$j++;
		}
		?>

	  </table>
		  <div align="center"></div>
	  <?php
		} else {
			//echo "<br/><br/><br/><center><div class='table_comment' >No hava Data  ";
		}
		?>
			  <?php

	}else{
		echo "<center><div class='table_comment' >
		<a href='index.php?id=".base64_encode('line')."'>ไม่มีข้อมูลการตั้งต้นของโมเดล คลิกที่นี่ เพื่อแสกน Kanban อีกครั้ง</a></div></center>";
		}//if($num_st=mysql_num_rows($qr_st)<>0){


	} //if (!empty($_GET['combid'])){
	 ?>
</div>
