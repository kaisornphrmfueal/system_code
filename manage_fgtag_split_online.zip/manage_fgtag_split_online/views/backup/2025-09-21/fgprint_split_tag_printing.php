
<?php
//echo "<br/>--". $_POST['button2'].$_POST['hidsplit'];
if(!empty($_POST['button2']) && $_POST['button2']=="Submit" && !empty($_POST['hidsplit']) ){ 
	  $psplitid= $_POST['hidsplit'];
$pidconv= $_POST['hidconver'];
$psplitqty= $_POST['hidsplitqty'];
//$pgmslabelbarcode= $_POST['gms_label'];

$psccanmodel =$_POST['model'];
$phidproc =$_POST['hidproc'];	
		
	
	
	$gmodel = substr($psccanmodel,0,15);
	$gserial=substr($psccanmodel,16,8);
	//0= start, 1= spliting,  2= finished, 3=cancel
	 $sql_updateplit="UPDATE prod_fg_tag.fgt_split_fg_tag SET item_status=1 WHERE id_fg_split=$psplitid";
	mysqli_query($con, $sql_updateplit); 
	
  	 $sqlg_split="SELECT  c.id_fg_tag_conversion,count(c.id_fg_tag_conversion) AS countsplit_qty,
				a.id_model,a.fg_tag_barcode,a.ticket_no,a.tag_no_original,a.tag_qty
				 FROM ".DB_DATABASE1.".fgt_split_fg_tag  a 
			  LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion b ON a.id_fg_split =b.id_fg_split
			  LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial c ON b.id_fg_tag_conversion=c.id_fg_tag_conversion
				  WHERE c.id_fg_tag_conversion ='$pidconv' AND gms_label_ref IS  NULL ";
		  $resultg_split = mysqli_query($con, $sqlg_split);
		$rstg_split = mysqli_fetch_array($resultg_split);
		$countsplit=$rstg_split['countsplit_qty'];
		$idmodel=$rstg_split['id_model'];
		$tagsplit=$rstg_split['tag_no_original'];
	
						if($phidproc=="0"){  $pagedr="fgprint_split_normal";
						   $ticket_no=	$rstg_split['ticket_no'];
						   $pgmslabelbarcode= $_POST['gms_label'];
							//echo substr($txt,3,15)."Model<br>";
						   $pgmslabel= substr($pgmslabelbarcode,64,9);
							   }else{  $pagedr="fgprint_split_special";
									 $ticket_no=$_POST['gms_label'];
									$pgmslabelbarcode= "";
									 $pgmslabel= $_POST['gms_label'];
									}

	
	
		if($countsplit==$psplitqty){ ////Create  NEW Tag
			 //$mxtag=selectMxTag($ss_fgidline);
			 $mxtag=selectMxTagFG();
	//	echo "<br/>--".$ss_fgidline;
				$linesp=sprintf("%02d",$ss_fgidline);
				$mxtagsp=sprintf("%07d",$mxtag);
				$tagnon=$linesp.$mxtagsp;
				if( date("H:i:s") >= "07:50:00" AND date("H:i:s") <= "20:19:59"){
							$chshift="Day";
							$datework=date('Y-m-d');
						}else{
							$chshift="Night";
							if( date("H:i:s") > "20:19:59" AND date("H:i:s") <= "23:59:59"){
								$datework=date('Y-m-d');
							}else{
								$datework=date( "Y-m-d",  strtotime("-1 day") );
							}
						}
				$tagb=date("Ymd").$tagnon;
				
				 $sqltg="INSERT INTO ".DB_DATABASE1.".fgt_srv_tag (line_id, 					
									tag_no,id_model,model_kanban,shift,fg_tag_barcode,
									status_print,matching_ticket_no,ticket_qty,kanban_status,
									date_insert,date_work,
									tag_location,who_upload,sn_start,tag_qty,
									tag_location_creating,work_id,bsi_line_id,bsi_model,bsi_tag_scan,bsi_date)
									 SELECT  line_id,  '$tagnon' AS tag_no, 
									'$idmodel' AS id_model, '$gmodel' AS model_kanban, 
									'$chshift' AS shift, '$tagb' AS fg_tag_barcode, 
									'Not yet' AS status_print , '$ticket_no' AS matching_ticket_no, 
									'$psplitqty' AS ticket_qty, kanban_status,  
									'".date('Y-m-d H:i:s')."' AS date_insert,   date_work ,
										'6' AS tag_location ,'$user_login' AS who_upload,'$gserial' AS sn_start, 
										'$psplitqty' AS tag_qty,
									 '1' AS tag_location_creating, work_id,bsi_line_id,bsi_model,bsi_tag_scan,bsi_date
									FROM ".DB_DATABASE1.".fgt_srv_tag WHERE  tag_no = '$tagsplit'"; 
			//'$datework' AS date_work , '$ss_fgidline' AS line_id, 'A' AS kanban_status,
							$qrtg=mysqli_query($con, $sqltg);
							log_hist($user_login,"New Tag",$mxtag,"fgt_srv_tag",$sqltg);

								$sql_updateold="UPDATE ".DB_DATABASE1.".fgt_srv_tag SET 
											status_fg_reprint='2',tag_location='10',
											date_fg_reprint='".date('Y-m-d H:i:s')."'
											WHERE tag_no= '$tagsplit'"; // UPdate old TAG
								mysqli_query($con, $sql_updateold); 
			
			
			//0= Not yet , 1= Reprint, 2 = Split Normal Case ,3=Split Special Case, 4= Combine (DOM)
			//0=Tag Reserved ,1=Line Printed ,2= BSI Passed , 3 = Packing Passed, 4 =FG Passed, 5 = PC Cancel, 6= FG Splite , 7 FG Combine, 8= Line cancel, 9= Line conversion, 10 = FG Modify
							
							$tickno9=sprintf("%09d",$ticket_no);
								$sql_newtag="UPDATE ".DB_DATABASE1.".fgt_split_fg_tag_conversion
											SET tag_no_new='$tagnon',fg_tag_barcode='$tagb',
											ticket_no_new = '$tickno9'
											WHERE id_fg_tag_conversion='$pidconv' "; // UPdate old TAG
							mysqli_query($con, $sql_newtag); 
			
							$sqlutk="UPDATE  ".DB_DATABASE2.".rf_kanban_ticket SET
												 status_write=6, last_status='Print Tag',
												 date_write ='".date('Y-m-d H:i:s')."', emp_write ='$user_login'
												 WHERE ticket_ref='$ticket_no'";
									$qrtk=mysqli_query($con, $sqlutk); //Print Tag
			
		}//Create  NEW Tag
	
		 $sqlg="SELECT MIN(c.id_conversion_serial) AS idconserial,c.serial_label,d.tag_model_no, 
		  a.tag_no_original,a.tag_qty,a.item_status,b.id_fg_tag_conversion,d.model_destination,
		  b.stag_qty AS splittagqty,b.sn_start,b.sn_end,
		  count(b.id_fg_tag_conversion) AS countnotnull,b.tag_no_new,b.fg_tag_barcode
          FROM ".DB_DATABASE1.".fgt_split_fg_tag  a 
		  LEFT JOIN ".DB_DATABASE1.".fgt_model d ON a.id_model =d.id_model
          LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion b ON a.id_fg_split =b.id_fg_split
          LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial c ON b.id_fg_tag_conversion=c.id_fg_tag_conversion
          WHERE b.id_fg_tag_conversion ='$pidconv' AND gms_label_ref IS  NULL  ";
		  $resultg = mysqli_query($con, $sqlg);
	
		if(mysqli_num_rows($resultg)<>0){
			//select count MAIN MOM TAG 
			
			
			//	$pline=$_POST['hslid'];
			$rstg = mysqli_fetch_array($resultg);
			$serial = $rstg['serial_label'];
				$tagmodel = $rstg['tag_model_no'];
				$splittagqty = $rstg['splittagqty'];
				$idconser = $rstg['idconserial'];
				$model_dest = $rstg['model_destination'];
				$count_allTag=$rstg['countnotnull'];
				$tagnon=$rstg['tag_no_new'];
				$tagb=$rstg['fg_tag_barcode'];
				$tickno9=sprintf("%09d",$ticket_no);
				if($serial == $gserial ){
					if($splittagqty == "1" || $count_allTag == "1" ){ //split qty  Or remain ==1
							//print Tag  // sn_start='$gserial' , 
								$sqlup_tag="UPDATE ".DB_DATABASE1.".fgt_srv_tag SET sn_end='$gserial' ,
										status_print='Printed', tag_qty='$psplitqty',
										date_print='".date('Y-m-d H:i:s')."',
										date_fg_reprint = '".date('Y-m-d H:i:s')."' ,
										status_fg_reprint = '2' 
										WHERE tag_no='$tagnon' " ; 
						
							$qrup_tag=mysqli_query($con, $sqlup_tag);
							//0=Tag Reserved ,1=Line Printed ,2= BSI Passed , 3 = Packing Passed, 4 =FG Passed, 5 = PC Cancel, 6= FG Splite , 7 FG Combine, 8= Line cancel
						 	$sqlsr="INSERT INTO ".DB_DATABASE1.".fgt_srv_serial SET  tag_no='$tagnon', 
									model_scan_label='$tagmodel', serial_scan_label='$gserial', 
									date_scan='".date('Y-m-d H:i:s')."'";
							$qrsr=mysqli_query($con, $sqlsr);
							log_hist($user_login,"Insert",$gserial,"fgt_srv_serial",$sqlsr);
	
						
						 $sqlutk="UPDATE ".DB_DATABASE1.".fgt_split_fg_tag_conversion a 
									LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial b ON a.id_fg_tag_conversion = b.id_fg_tag_conversion
									SET a.date_conversion='".date('Y-m-d H:i:s')."',
									a.emp_conversion='$user_login',a.tag_no_new='$tagnon',a.item_status=1,
									a.ticket_no_new = '$tickno9',
									b.serial_label_confirm='$psccanmodel',b.gms_label_ref='$pgmslabel',
									b.gms_label_ref_barcode='$pgmslabelbarcode',
									b.date_scan_confirm='".date('Y-m-d H:i:s')."',b.emp_scan_confirm='$user_login'
									WHERE b.id_conversion_serial ='$idconser' ";
							$qrtk=mysqli_query($con, $sqlutk); 
						
						// START INSERT FOR MATCHING
						//echo "--".$model_dest;
						
						if($model_dest=="E"){
						$ip = $_SERVER['REMOTE_ADDR']; 
						//$tkno9=sprintf("%09d",$ticket_no);
						$sqlmc = "INSERT INTO ewi_packing.record_mathing_kanban SET 
							record_code='".date("YmdHis")."', ticket_no='$tickno9',	model_no_scan='$gmodel', 
							fg_tag_no='$tagb', model_no_auto='$gmodel', judge='OK', 
							operator_id='$user_log_name', record_time='".date('Y-m-d H:i:s')."', 
							error_code='-', line_leader_id='-',ip='$ip',kanban_group='".date("ymdH")."',
							working_location='2',status_scan = '8'"; 
							mysqli_query($con, $sqlmc); 
							
							
						$sqlmc = "INSERT INTO ewi_packing.record_mathing_kanban_log SET 
							record_code='".date("YmdHis")."', ticket_no='$tickno9', model_no_scan='$gmodel', fg_tag_no='$tagb', 
							model_no_auto='$gmodel', judge='ok', operator_id='$user_log_name', record_time='".date('Y-m-d H:i:s')."',
							error_code='-', line_leader_id='-',ip='$ip'";
							mysqli_query($con, $sqlmc);
							
							//log_record_packing($user_log_name,'FG insert to record_mathing_kanban',$sqlmc);
							}//if($model_dest==""){
						// END  INSERT FOR MATCHING 
						
						
								
								
								//START Count all Tag Split
							$sql_count_alltagsp="SELECT IFNULL(COUNT(id_fg_split),0) AS count_all_tagsplit 
													FROM  ".DB_DATABASE1.".fgt_split_fg_tag_conversion
													WHERE id_fg_split=$psplitid  AND item_status =0";
								$qrcount_alltagsp=mysqli_query($con, $sql_count_alltagsp);
								$rscout_alltagsp = mysqli_fetch_array($qrcount_alltagsp);
								 $count_all=$rscout_alltagsp['count_all_tagsplit'];
								if($count_all == 0){
									/*
										//print Tag Finished // Update split ststus
									// UPdate fgt_srv_tag => status_fg_reprint=2 = Split Normal Case 
									// UPdate fgt_srv_tag => tag_location6= FG Splite
									//this process UPdate fgt_srv_tag for split qty >1 */
									
									
									
									// fgt_split_fg_tag => item_status 2= finished
								$sql_updatefinish="UPDATE ".DB_DATABASE1.".fgt_split_fg_tag SET item_status=2 WHERE id_fg_split=$psplitid";
									mysqli_query($con, $sql_updatefinish); 
									
									
									
									
									
										//sprintTag
									printTagSplit($tagnon);
									//eprinTag
										log_hist($user_login,"Printed Tag",$tagnon,"fgt_srv_tag","");
									//---END  Checking Qty if 1 print -----------		
									sleep(3);
									gotopage("index_fg.php?id=".base64_encode($pagedr));


									//Print Tag

								}else{
									
									//sprintTag
									printTagSplit($tagnon);
									//eprinTag
										log_hist($user_login,"Printed Tag",$tagnon,"fgt_srv_tag","");
									//---END  Checking Qty if 1 print -----------		
									sleep(3);
									gotopage("index_fg.php?id=".base64_encode('fgprint_split_tag')."&stag=$psplitid"."&idproc=$phidproc");


									//Print Tag
									
								}//if($count_all == 0){

								//END Count all Tag Split
								
								
						
						
							
						}else{//split qty > 1=> else <> 1 
						
						// =>>>>>> Insert Start  gotopage scan again
						
								//save and Next
								$sqlsr="INSERT INTO ".DB_DATABASE1.".fgt_srv_serial SET  tag_no='$tagnon', 
									model_scan_label='$tagmodel', serial_scan_label='$gserial', 
									date_scan='".date('Y-m-d H:i:s')."'";
							$qrsr=mysqli_query($con, $sqlsr);
							log_hist($user_login,"Insert",$gserial,"fgt_srv_serial",$sqlsr);
	
					$sqlutk="UPDATE ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial
									SET serial_label_confirm='$psccanmodel',gms_label_ref='$pgmslabel',
									gms_label_ref_barcode='$pgmslabelbarcode',
									date_scan_confirm='".date('Y-m-d H:i:s')."',
									emp_scan_confirm='$user_login'
									WHERE id_conversion_serial ='$idconser' ";
							$qrtk=mysqli_query($con, $sqlutk); 
						// START INSERT FOR MATCHING
						//echo "--".$model_dest;
						
					
									log_hist($user_login,"Printed Tag",$tagnon,"fgt_srv_tag","");
							//---END  Checking Qty if 1 print -----------		
							
							gotopage("index_fg.php?id=".base64_encode('fgprint_split_tag_printing')."&idconv=".$pidconv."&idproc=$phidproc");

						}//if($splittagqty == "1" || $count_allTag == "1" ){ //split qty  Or remain ==1
					
	
				}elseif ($tagmodel != $gmodel ) {
						 alert("Model No. ไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่อีกครั้ง");
						gotopage("index_fg.php?id=".base64_encode('fgprint_split_tag')."&stag=$psplitid"."&idproc=$phidproc");
				}else{
						 alert("Serial No. ไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่อีกครั้ง");
						gotopage("index_fg.php?id=".base64_encode('fgprint_split_tag')."&stag=$psplitid"."&idproc=$phidproc");
						// echo $mxsrl ;
					}//if($gserial-$rscht['mxtag']==1){


		}else{
			 alert("Serial No. ไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่อีกครั้ง");
		gotopage("index_fg.php?id=".base64_encode($pagedr));
			 // echo $sqlg;
			}

	
	
	
	
	
		
		
			
/*	alert("Serial No. ไม่ถูกต้อง กรุณาแสกนข้อมูลใหม่อีกครั้ง");
			gotopage("index.php?id=".base64_encode('printtag')."&idtg=".base64_encode($ptagno));
	*/
	
}//if(!empty($_POST['button2']) && $_POST['button2']=="Submit" && !empty($_POST['hidsplit']) ){ 
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">
window.onload = function() {
var sprocess = '<?php echo $_GET['idproc']; ?>';
	//alert(sprocess);
		if(sprocess==0){
			//alert(sprocess);
			document.getElementById("txtTicket").innerHTML="GMS Label Ref.";
		
		}else{
			document.getElementById("txtTicket").innerHTML="Ticket No.( Special Ticket)";
			
		}
	//alert("==");
	
	let tkbox=document.getElementById("gms_label").value.toString();
	
	if(tkbox == ""){
		document.getElementById("gms_label").focus();
	  	document.getElementById("gms_label").select();
		document.getElementById("model").disabled = true;
 		document.getElementById("btnscan").disabled = true;
  
	}else{
		document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน Serial Label หลังเครื่อง</span>';
		document.getElementById("model").disabled = false;
		document.getElementById("model").focus();
		document.getElementById("gms_label").readOnly = true;
		
	}//if(tkbox == ""){
		
}//window.onload = function() {


 function ckNext(e) {
	  // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
        let val=document.getElementById("gms_label").value.toString();
	 let len = val.length;
//alert(len);
		let txtalert = document.getElementById("txtTicket").innerHTML; 

		 var sprocess = '<?php echo $_GET['idproc']; ?>';
		  //----- START CHECK  Ticket special
			//  alert(document.getElementById("gms_label").value);
		 let txsplit_tagnew_qty = document.getElementById("split_tagnew_qty").innerHTML; 
		 let ticketck=document.getElementById("gms_label").value;
		 let tagmodel=document.getElementById("txtModel").innerHTML;
		
		 if(sprocess=="0"&& len == 77){//Nomal
			 let mol = ticketck.substring(3, 18);
			let modl = mol.replace("/", "-");
			let tks = ticketck.substring(64, 73);//let tks = ticketck.substring(64, 72);
			 let tkbarc = ticketck.replace("/", "-");
			 if(modl != tagmodel){
				document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >ข้อมูล Model No. ใน GMS label Ref.  ไม่ตรงกับ F/G Transfer Tag (Original) กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("gms_label");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("btnscan").disabled = true;
				}else{
					document.getElementById("gms_label").value=tkbarc;
					document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน Serial Label หลังเครื่อง</span>';
						document.getElementById("model").disabled = false;
						document.getElementById("model").focus();
						  document.getElementById("gms_label").readOnly = true;
				}// if(modl!=tagmodel){
			 
		 }else if(sprocess=="1" && len == 9){ //special
			 
		// alert (txsplit_tagnew_qty + txtalert + ticketck+ tagmodel);
			     $.ajax({
				url: "chklticketsp.php?gdata="+ ticketck + "&gtagmodel="+ tagmodel +"&gsptagqry="+ txsplit_tagnew_qty,
				method: 'GET', 
				success: function (datap) {
					//"&gprocess="+ sprocess+
						//alert(datap)
			var rqrTxtlb= datap.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '')
		
			//	alert(rqrTxtlb);
	
				if(rqrTxtlb == "No"){
					//Duplicate
						document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >ไม่พบข้อมูล  '+ txtalert +' ในระบบ กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("gms_label");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("btnscan").disabled = true;
				
					
					}else if(rqrTxtlb == "MNo"){
						document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >ข้อมูล Model No. ใน Ticket ไม่ตรงกับ  F/G Transfer Tag (Original) กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("gms_label");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("btnscan").disabled = true;
					}else if(rqrTxtlb == "qtNO"){
						document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" > จำนวนใน Ticket No. ไม่เท่ากับ จำนวนใน  F/G Transfer Tag (Original)  กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("gms_label");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("btnscan").disabled = true;
					/*}else if(rqrTxtlb == "gmsrefIsTK"){
						document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >ข้อมูลที่แสกน คือ Ticket No. กรุณาแสกน GMS Label Ref. ที่ถูกต้อง </span>';
						const input = document.getElementById("gms_label");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("btnscan").disabled = true;*/
						
				
					}else{
						
						 document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน Serial Label หลังเครื่อง</span>';
						document.getElementById("model").disabled = false;
						document.getElementById("model").focus();
						  document.getElementById("gms_label").readOnly = true;
						 
						
									

					}//if(data!= null){
					
					
				}
			}); // $.ajax({
		
		//----- END CCHECK  Ticket special
			 
		 }else{
			  //alert(txtalert)
		 const input = document.getElementById("gms_label");
						  input.focus();
						  input.select(); // Update for handheld
		 document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน  '+ txtalert +'</span>';
	
			 
		 }// if(sprocess=="0"){// Nomal

		 return false;
   
    }    // if (e.keyCode == 13)
	 return true; 

	 
 }


		
	
	//======
function ckKeyPresse1(e) 
{

    // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
		document.getElementById("btnscan").disabled = false;
        document.getElementById('btnscan').click();
		//alert( document.getElementById('btnscan').value)
		 return false;
   
    }    return true;

    
}//  if (e.keyCode == 13)
	
	
</script>

<?php
?>
 <div class="rightPane" align="center">
  <?php
  	//$lineid= $_GET['lid'];

	
  	if (!empty($_GET['idconv'])){
		$gidconv =$_GET['idconv'];
		$gidproc =$_GET['idproc'];
		
			$sql_st="SELECT a.tag_no_original,a.tag_qty,a.item_status,a.id_fg_split,c.stag_qty,a.ticket_no,
		  b.id_model,b.model_code,   b.model_name,b.tag_model_no,b.customer,b.std_qty,
          b.customer_part_no,b.customer_part_name,b.model_picture,b.status_tag_printing,
		  CONCAT(c.sn_start,'-',c.sn_end) AS allserial,c.ticket_no_new,
		  IF(process_status = '1', d.gms_label_ref, '') AS gms_label_r  ,
		  IF(process_status = '1', 'Ticket', 'GMS Label Ref.') AS txtticket 
          FROM ".DB_DATABASE1.".fgt_split_fg_tag  a 
		  LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion c ON a.id_fg_split =c.id_fg_split
		   LEFT JOIN prod_fg_tag.fgt_split_fg_tag_conversion_serial d ON c.id_fg_tag_conversion =d.id_fg_tag_conversion 
          LEFT JOIN ".DB_DATABASE1.".fgt_model b ON a.id_model =b.id_model 
		   WHERE  c.id_fg_tag_conversion ='".$gidconv."'  ";
						
	} 
	  //echo $sql_st;
		$qr_st=mysqli_query($con, $sql_st);
		if($num_st=mysqli_num_rows($qr_st)<>0){
			$rsst=mysqli_fetch_array($qr_st);
			$modelid=$rsst['id_model'];
			$id_split=$rsst['id_fg_split'];
			$stmodel=$rsst['tag_model_no'];
			$splitqty=$rsst['stag_qty'];
			$sttag=$rsst['tag_no_original'];
			$sttag_qty=$rsst['tag_qty'];
			$stticket=$rsst['ticket_no'];
			//$stfg_tag_barcode=$rsst['fg_tag_barcode'];
			$all_serial=$rsst['allserial'];
			$ticketno_new=$rsst['ticket_no_new'];
			$ticket_gms=$rsst['gms_label_r'];
			
			
  ?>
  

<form name="scan"  id="scan" method="post" action="index_fg.php?id=<?=base64_encode('fgprint_split_tag_printing')?>"   onsubmit="return false;"  autocomplete="off" >
            
    <table width="952" height="359" border="1" align="center" class="table01">
              <tr>
                <td height="40" colspan="2" align="center"><span class="text_black">F/G Transfer Tag Spliting
				
                </span>  </td>
              </tr>
              <tr>
                <td height="40"><div class="tmagin_left"><span class="text_black">Model :<br />
                </span></div></td>
                <td height="40"><div class="tmagin_right"> <span class="text_black">
                  <?php  echo "<span id=txtModel>$stmodel</span> ";?>
                  </span> <span class="txt-blue-big"><?php echo "[".$rsst['model_name']."]"; ?></span>
					<span type="hidden"  name="convid"  id="convid" style="display: none" ><?php echo $gidconv;?></span> 
              		<!--   style="display:none;" -->
					
                  <!--0= start, 1= spliting,  2= finished, 3=cancel-->
                </div></td>
              </tr>
              <tr>
                <td width="375" height="40"><div class="tmagin_left"><span class="text_black"> F/G Transfer Tag (Original) No. :<br />
                </span></div></td>
                <td width="561" height="40">  <div class="tmagin_right">
                <span class="text_black"><?php  echo "<span id=txt-black-big>$sttag</span> ";?> </span>
                <!--0= start, 1= spliting,  2= finished, 3=cancel--></div>
                </td>
              </tr>
             
				   <tr>
                <td height="40"><div class="tmagin_left"><span class="text_black">Ticket Original No. : <br />
                </span></div></td>
                <td height="40">  <div class="tmagin_right"> <span class="text_black">
				<?php  echo $stticket; ?>  || Ticket Qty. : </span>
               
               <span class="text_black"> 	<?php  echo $sttag_qty; ?> </span> </div>
                </td>
              </tr>
              <tr>
                <td height="40"><div class="tmagin_left"><span class="text_black">Serial Split Start - End </span><br />
                </div></td>
                <td height="40">  <div class="tmagin_right"> 
                <span class="txt-black-big"><?php  echo "<span id=txtTag>$all_serial</span> ";?>
                </span> || <span class="text_black">Tag Split  Qty. : </span><span class="txt-blue-big" id="split_tagnew_qty">
                <?php  echo $splitqty; ?>
                </span></div>
                </td>
              </tr>
           
		
		<tr>
			<td height="40"><div class="tmagin_left"><span class="text_black">Scan </span><span class="text_black" id="txtTicket">  </span>
                </div></td>
                <td height="40">  <div class="tmagin_right">
                  <input type="text" name="gms_label" id="gms_label"  class="bigtxtbox" style="width:290px;"  onkeypress="return ckNext(event);" onClick="this.select();" value="<?php echo $ticket_gms;?>" />
				<!--	<input type="hidden" name="hdtkmodel" id='hdtkmodel' value="">-->
                </div>
                </td>
      </tr>
		
                <tr>
                <td height="40"><div class="tmagin_left"> <span class="text_black">Scan Label barcode  : <br />
                </span></div></td> 
                <td >
                <div class="tmagin_right">
               
                  <input type="text" name="model" id="model"  class="bigtxtbox" style="width:290px;"  onkeypress="return ckKeyPresse1(event);" />
				  </div>
             
              </tr>	
				
					<tr>
			     
                <td colspan="2" height="75px"  align="center">
             <div id="txtStatus"></div>

                </td>
              </tr>
				<tr>
                <td height="40" colspan="2" align="center">
                <!--<input type="button" name="button3" id="button3" value="Cancel" class="button3"  
            onClick="window.location.href='index.php?id=<?=base64_encode('fgprint_split_tag_printing')?>&stag=<?=$id_split?>&idconv=<?=$gidconv?>';"/>
					-->
					
					
					<button onclick="window.location.href='index_fg.php?id=<?php echo base64_encode('fgprint_split_tag');?>&stag=<?php echo $id_split?>&idproc=<?php echo $gidproc;?>'">Back</button>
					
					  <input type="button" name="btnscan" id="btnscan" value="Submit" class="myButton" onclick="validateConverTag(this.value)" />
                  	<input type="hidden" name="button2" id="button2"  value="Submit" /> 
                  	<input type="hidden" name="hidsplit" id="hidsplit" value="<?=$id_split?>" />
					<input type="hidden" name="hidconver" id="hidconver" value="<?=$gidconv?>" />
					<input type="hidden" name="hidsplitqty" id="hidsplitqty" value="<?=$splitqty?>" />	
					<input type="hidden" name="hidproc" id="hidproc" value="<?=$gidproc?>" />	
				
					

                </td>
              </tr>	
					
    </table>
  
</form>


<?php
 $qtg = "SELECT c.id_fg_tag_conversion,serial_label, c.gms_label_ref, c.serial_label_confirm, c.date_scan_confirm, c.emp_scan_confirm,
IF(ISNULL(c.emp_scan_confirm), '-', CONCAT (a.name_en ,'(',c.emp_scan_confirm,')' ))  AS convuser ,
IF(ISNULL(c.emp_scan_confirm), '-',CONCAT('[', DATE_FORMAT(c.date_scan_confirm, '%d-%b-%Y %H:%i'),']')  )  AS conv_date ,  IF(gms_label_ref_barcode = '', '-', gms_label_ref_barcode) AS gms_label_ref_bc
FROM ".DB_DATABASE1.".fgt_split_fg_tag_conversion b 
LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial c ON b.id_fg_tag_conversion=c.id_fg_tag_conversion 
LEFT JOIN ".DB_DATABASESSO.".so_view_fttl_and_sub a ON c.emp_scan_confirm =a.emp_id 
WHERE c.id_fg_tag_conversion ='".$gidconv."' AND gms_label_ref IS NOT NULL  ";
$qrtg = mysqli_query($con, $qtg);
$totaltg = mysqli_num_rows($qrtg);
$j = 1;
if ($totaltg <> 0) {
?>
<table width="950px"  border="1" bordercolor="#CC9966"class="table01" align="center">
	<tr >
	  <th height="27" colspan="7">
	  <div align="center">FG Tag Spliting Serial Confirmed</div>  </th>
	  </tr>
	  
	<tr>


	  <th width="5%" height="27">No.</th>
	  <th width="15%">Serial </th>
	  <th width="12%">GMS Label Ref. Barcode</th>
	  <th width="12%"><?php echo $rsst['txtticket'] ;?></th>
	  <th width="16%">Serial Label Confirm</th>
	  <th width="13%">Scan by</th>
	  <th width="16%">Scan Date</th>
    </tr>
	   <?php while ($rstg = mysqli_fetch_array($qrtg)) { 
			  ?>
	  <tr  <?php $v = 0; $v = $v + 1; echo icolor($v); ?>height="28" onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" align="center">
	  <td ><?php echo $j ;?></td>
	  <td ><?php echo $rstg['serial_label'] ;?></td>
	  <td ><?php echo $rstg['gms_label_ref_bc'] ;?></td>
	  <td ><?php echo $rstg['gms_label_ref'] ;?></td>
	  <td><?php echo $rstg['serial_label_confirm'] ;?></td>
	  <td ><?php echo $rstg['convuser']; ?></td>
	  <td><?php echo $rstg['conv_date']; ?></td>
    </tr>
	 <?php
		$j++;
	}
	?>
  
  </table>
	  <div align="center"></div>
  <?php
	} else {
		//echo "<br/><br/><br/><center><div class='table_comment' >No hava Data  ";
	}
	?>
		  <?php
                
}else{
	echo "<center><div class='table_comment' >
	<a href='index.php?id=".base64_encode('line')."'>ไม่มีข้อมูลการตั้งต้นของโมเดล คลิกที่นี่ เพื่อแสกน Kanban อีกครั้ง</a></div></center>";
	}//if($num_st=mysql_num_rows($qr_st)<>0){
          ?>
</div>
