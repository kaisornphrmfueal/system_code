<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<div class="body_resize"  align="center"> 

 <form id="form1" name="form1" method="post" action="">
  <table width="410" border="1" align="center" class="table01" >
    <tr>
     <td width="206" height="37"><div class="tmagin_right">Search : Process Name</div> </td>
     <td width="288">
          <input type="text" name="tsearch" id="tsearch" style=" width:180px;"  value="<?php echo @$_POST['tsearch']?>"/>
     <input type="submit" name="button" id="button" value="Submit" /></td>
    </tr>
  </table>
</form>   
   <?php
      if(!empty($_POST['tsearch'])|| !empty($_GET['serh'])){
        if(!empty($_POST['tsearch'])){$txtsearsh=$_POST['tsearch'];}else{$txtsearsh=$_GET['serh']; }
          $x="AND process_name LIKE '%".mysqli_real_escape_string($con, $txtsearsh)."%'";
        }else{ $x=""; }
          $q="SELECT process_id,process_name,deleted,emp_insert,date_insert,emp_modify,date_modify
        FROM ".DB_DATABASE1.".fgt_process 
        WHERE deleted = 'N'  $x ";
          //echo  $q;
          $qr = mysqli_query($con, $q);
          $total=mysqli_num_rows($qr);  
          
          if($total<>0)	{	
                $e_page=15; // ????? ?????????????????????????????     
                
                
                if(!isset($_GET['s_page']) ){     //or !empty($txtsearsh)
                  $_GET['s_page']=0;     
                }else{     
                  $chk_page=$_GET['s_page'];       
                  $_GET['s_page']=$_GET['s_page']*$e_page;     
                }     
                $q.=" LIMIT ".$_GET['s_page'].",$e_page";  
                $qr=mysqli_query($con, $q);  
                if(mysqli_num_rows($qr)>=1){     
                  @$plus_p=($chk_page*$e_page)+mysqli_num_rows($qr);     
                }else{     
                  @$plus_p=($chk_page*$e_page);         
                }     
                $total_p=ceil($total/$e_page);     
                @$before_p=($chk_page*$e_page)+1; 
              $i=1;
                
              ?>
<div class="rightPane">  

  <table width="60%" height="123" border="1" bordercolor="#CC9966"class="table01" align="center">
   <tr >
    <th height="28" colspan="3">
    <div align="center">Manage Work Process</div> </th>
    <th height="28">
    <a href="#" onClick="javascript:openWins('windows.php?win=workp&idm=', '_blank',650, 180, 1, 1, 0, 0, 0);return false;" > 
    Add New Work Process </a></th>
    </tr>
    
   <tr>
    <th width="8%" height="28">No.</th>
    <th width="12%">Proces No.</th>
     <th width="66%"><span class="tmagin_right">Process Name</span></th>
     <th width="14%">Update</th>
    
   </tr>
     <?php while($rs=mysqli_fetch_array($qr)){   ?>
    <tr  <?php $v =0; $v = $v + 1; echo  icolor($v); ?> onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" align="center">
    <td height="30px"><?=$i?></td>
    <td height="30px"> <?=$rs['process_id']?> </td> 
    <td><?=$rs['process_name']?></td>
    <td> <a href="#" onClick="javascript:openWins('windows.php?win=workp&idm=<?=$rs['process_id'];?>', '_blank', 650, 180, 1, 1, 0, 0, 0);return false;"  >
      <img src="../images/001_45.gif" /></a> </td>
   </tr>
   <?php 
      $i++;
    
      }//	while($rsp=mysql_fetch_array($qrp)){
   ?>
  
  </table>
  <?php
                
     if($total>0){ ?>  
<div class="browse_page" >
        <?php       @page_navigator_user($before_p,$plus_p,$total,$total_p,$chk_page,base64_encode('manage'),$txtsearsh);  	  ?>
  </div>  
<?php }
        
      }else{
          echo "<br/><br/><br/><center><div class='table_comment' >No hava Data...Click  ";
        ?>
  <a href="#" onClick="javascript:openWins('windows.php?win=add&idm=', '_blank',650, 380, 1, 1, 0, 0, 0);return false;" >  here    </a>
           <?php
        echo "  to create new data </div> </center>";
      }//if(rows($qr)<>0){
     ?>

</div>
