<?php

require_once '../includes/configure_host.php';
//include('../includes/configure.php');
				//echo "No";
if(!empty($_GET["gdata"]) && $_GET["gdata"]<>"undefined"){
	
	$gticket=$_GET["gdata"];
	$gtag_model=$_GET["gtagmodel"];
	//$g_process=$_GET["gprocess"]; 
	$g_gsptagqry=$_GET["gsptagqry"]; 
	
	//a.tag_no,a.tag_qty,a.item_status,b.id_fg_tag_conversion, 
				
	$sqltk="SELECT b.ticket_ref,b.ticket_qty ,b.status_write ,b.model_no
						FROM   ".DB_DATABASE2.".rf_kanban_ticket  b					 
						WHERE b.ticket_ref = '$gticket' 
						AND b.status_write = '0'
						AND b.ticket_special_status ='1'
						GROUP BY b.ticket_ref  ";
		  $rstk = mysqli_query($con, $sqltk);

if(mysqli_num_rows($rstk)!= 0){
		$rstksp = mysqli_fetch_array($rstk);
		$tkmodel = $rstksp['model_no'];
		$rsticket_qty = $rstksp['ticket_qty'];
	
		if($tkmodel ==$gtag_model ){
				if($g_gsptagqry==$rsticket_qty){
					echo $tkmodel ;
				}else{
					echo "qtNO" ;
				}
				
			}else{
				echo "MNo";
				// echo $mxsrl ;
			}//if($gserial-$rscht['mxtag']==1){

		
}else{
	 echo "No";
	 // echo $sqlg;
	}
	
	


 }//  if(!empty($_GET["code"]) && $_GET["code"]<>"undefined"){


?>