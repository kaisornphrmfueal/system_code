
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">
window.onload = function() {
	//alert("s");
	document.getElementById("button2").disabled = true;

	  document.getElementById("tsearch").focus();
	  document.getElementById("tsearch").select();
		document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน  FG TAG  Original </span>';

	 
}

	//START ckNext
 function ckNext(e) {
	  // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
        let tagbc=document.getElementById("tsearch").value.toString();
	 let lenbc = tagbc.length;
//alert(lenbc);
	if(lenbc == 17){
		 	 //----- START CHECK  FG TAG 
		
		
			 let tagsp=document.getElementById("tsearch").value;
		//  alert(tkmodel);
		 
			     $.ajax({
				url: "chkltagspn.php?gdata="+ tagsp ,
				method: 'GET', 
				success: function (datap) {
					//	alert(datap)
			var rqrTxtlb= datap.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '')
				
			//	alert(rqrTxtlb);
	
				if(rqrTxtlb == "No"){
					//Duplicate
						document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >ไม่พบข้อมูล  FG TAG No. ในระบบ กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("button2").disabled = true;
				
					
					}else{
						
					//	alert("+"+rqrTxtlb);
						let text = rqrTxtlb;
						const myArray = text.split("--&&--");	
						var gticket = myArray[0];
						var statusbsi = myArray[1];	
						if(statusbsi=="NG"){
							document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >NG ยังไม่มีการสแกนข้อมูล FG tag นี้จาก BSI,<br/> กรุณาแสกนใหม่  </span>';
						const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
						// input.value="";
						document.getElementById("button2").disabled = true;
				
						}else{
							document.getElementById("txtStatus").innerHTML  = '<span class="txt-green-b-s" ><img src="../../images/yes.gif"  /><br/>ข้อมูลถูกต้อง ระบบกำลังบันทึกข้อมูล...</span>';
						document.getElementById('sticket').value  = gticket;
						document.getElementById("button2").disabled = false;
						//document.getElementById("button2").submit();
						 document.getElementById("form1").submit();
								//	 return false;
						
						}
						
								

					}//if(data!= null){
					
					
				}
			}); // $.ajax({
		
		//----- END CCHECK  FG TAG
		
		 
	 }else{
		 document.getElementById("txtStatus").innerHTML  ='<span class="txt-red-b-s" >กรุณาแสกน FG TAG Original</span>';
		 
		 const input = document.getElementById("tsearch");
						  input.focus();
						  input.select(); // Update for handheld
	 }
		 return false;

    }    return true;
 
 }
	//END ckNext
</script>

<div align="center">
 <form id="form1" name="form1" method="post" action="<?php echo "index_fg.php?id=".base64_encode('fgprint_split_all');?>" autocomplete="off">
   <table width="482" border="1" align="center" class="table01" >
	  <tr>
     <td height="37" colspan="2" align="center" bgcolor="#A7FBE7">Split F/G Transfer Tag</td>
     </tr>
 
   <tr>
     <td width="196" height="37"><div class="tmagin_right">Scan  F/G Transfer Tag (Original)</div> </td>
     <td width="411">
        <input type="text" name="tsearch" id="tsearch"   value="" onfocus="this.select()"  class="bigtxtbox" style="width:190px;"  onkeypress="return ckNext(event);" />
        <input type="hidden" name="process_st" id="process_st"  value="0"/>
		  <input type="hidden" name="sticket" id="sticket"  value=""/>
<input type="button" name="button2" id="button2" value="Submit" />
	   
	   
	   </td>
   </tr>
   <tr>
     <td height="37" colspan="2" align="center"><div id="txtStatus"></div></td>
     </tr>
   </table>
</form>   
</div>
<?php
?>