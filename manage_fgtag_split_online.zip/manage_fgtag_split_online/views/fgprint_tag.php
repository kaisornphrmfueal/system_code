<?php
// สมมติว่ามี $con = new mysqli(...); เชื่อมต่อไว้แล้ว

if (!empty($_POST['scan2']) && $_POST['scan2'] == "Submit") {
	$pidprint = $_POST['hidprint'];
	$ptag = $_POST['model'];

	$sqlck = "SELECT tag_no,id_model,sn_start,sn_end,tag_qty 
			FROM " . DB_DATABASE1 . ".fgt_srv_tag 
			WHERE tag_no = '$ptag'
			AND tag_no NOT IN (SELECT tag_no 
								FROM " . DB_DATABASE1 . ".fgt_supplier_tag_split 
								WHERE tag_no = '$ptag' 
								AND  id_print_tag = '$pidprint')";
	$qrck = mysqli_query($con, $sqlck);
	$numck = mysqli_num_rows($qrck);
	if ($numck <> 0) {
		$rsck = mysqli_fetch_array($qrck);
		//------ START UPDATE SUPPLIER TAG-------------------------
		$original_qty = $rsck['tag_qty'];
		$slit_qty = $_POST['hqtysplit']; //qty per page
		$texttest1 = $rsck['sn_start'];
		$texttest2 = $rsck['sn_end'];
		$all_page = ceil($original_qty / $slit_qty); // Qty per each page  3 page , 3 qty
		$textsub1 = substr($texttest1, 3);
		$textsub2 = substr($texttest2, 3);
		$textsn1 = substr($texttest1, 0, 3);
		for ($p = 1; $p <= $all_page; $p++) {
			if ($p == $all_page) {
				$jnum = ($textsub2 - $textsub1) + 1;
				$sqls = "INSERT INTO " . DB_DATABASE1 . ".fgt_supplier_tag_split SET id_print_tag='" . $pidprint . "',
					tag_no='$ptag', sn_start='" . $textsn1 . sprintf("%05d", $textsub1) . "', 
					sn_end='" . $textsn1 . sprintf("%05d", $textsub2) . "',stag_qty='$jnum' ";
				mysqli_query($con, $sqls);
				while ($textsub1 <= $textsub2) {
					$textsub1++;
				}
			} else {
				$tstxxx = $textsub1 + $slit_qty;
				$sqls = "INSERT INTO " . DB_DATABASE1 . ".fgt_supplier_tag_split SET id_print_tag='" . $pidprint . "',
					tag_no='$ptag', sn_start='" . $textsn1 . sprintf("%05d", $textsub1) . "',
					sn_end='" . $textsn1 . sprintf("%05d", ($tstxxx - 1)) . "' ,stag_qty='$slit_qty'";
				mysqli_query($con, $sqls);
				while ($textsub1 < $tstxxx) {
					$textsub1++;
				}
			}
		}
		//------ END  UPDATE SUPPLIER TAG-------------------------
	} else {
		echo "<script>alert('ระบบไม่พบข้อมูล หรือ FG Tag No. $ptag ไม่ถูกต้อง กรุณาตรวจสอบข้อมูลอีกครั้ง');</script>";
	}
}
 
if (!empty($_POST['btnprint']) && $_POST['btnprint'] == "Print") {
	$stagp = $_POST['hidprintst'];
	printSPTag($stagp, $_SESSION['station']);
	mysqli_query($con, "UPDATE " . DB_DATABASE1 . ".fgt_supplier_tag SET print_status=1, 
				emp_print='$user_login', date_print='" . date('Y-m-d H:i:s') . "' 
				WHERE id_print_tag='$stagp' ");

	mysqli_query($con, "UPDATE " . DB_DATABASE1 . ".fgt_supplier_tag_split 
				SET emp_print='$user_login', date_print='" . date('Y-m-d H:i:s') . "' 
				WHERE id_print_tag='$stagp'");

	log_hist($user_login, "LGT Print", $stagp, "fgt_supplier_tag", "");
	gotopage("index_fg.php?id=" . base64_encode('fgprint'));
}

if (!empty($_GET['ctagp'])) {
	$sqldl = "UPDATE  " . DB_DATABASE1 . ".fgt_supplier_tag SET deleted=1, 
			emp_modify='$user_login', date_modify='" . date('Y-m-d H:i:s') . "'
			WHERE id_print_tag='" . $_GET['ctagp'] . "'";
	$qrdl = mysqli_query($con, $sqldl);
	gotopage("index_fg.php?id=" . base64_encode('fgprint'));
}
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">

window.onload = function() {
  document.getElementById("model").focus();
  document.getElementById("model").select();
}
function validate(form2) {   
	if(document.form2.model_code.value == ""){
			alert("Please input Model code");
			document.form2.model_code.focus();
			return (false);
	}else{  
			form2.button.disabled = true;  
			form2.button.value = 'Adding...';  
			return true;  
			}
}///function validate(form) {

</script>
 <div  align="center">
<?php
if (!empty($_GET['stag'])) {
	$gstag = $_GET['stag'];
	$sql = "SELECT b.id_model,b.model_code,b.model_name,b.tag_model_no,b.std_qty,a.separate_qty,b.model_picture,
			b.customer_part_no,b.customer_part_name,b.customer,a.id_print_tag
			FROM " . DB_DATABASE1 . ".fgt_supplier_tag a
			LEFT JOIN " . DB_DATABASE1 . ".fgt_model b ON a.id_model=b.id_model    
			WHERE a.id_print_tag ='" . $gstag . "' ";
	$qr = mysqli_query($con, $sql);
	$rs = mysqli_fetch_array($qr);
	$total = mysqli_num_rows($qr);
	if ($total <> 0) {
		$tgmoel = $rs['tag_model_no'];
		$idpstag = $rs['id_print_tag'];
		$stdqty = $rs['std_qty'];
		$splitqty = $rs['separate_qty'];
?>

<table width="762"  border="1" class="table01" align="center">
  <tr>
	<th height="27" colspan="6">Separate Supplier Tag</th>
  </tr>
	<tr>
	  <th width="117" height="25">Model Picture</th>
	  <th width="177">Model No. (Tag)</th>
	  <th width="113">Customer </th>
	  <th width="149">Customer <br />
	  Part No.  </th>
	  <th width="69">Standard  Qty</th>
	  <th width="97">Separate Tag Qty/page</th>
	</tr>
	<tr align="center">
	  <td height="25">
		<?php  if (!empty($rs['model_picture'])) {
			echo "<img src='" . DIR_UPLOAD . DIR_MPIC . $rs['model_picture'] . "' />";
		}
		 ?>
	 </td>
	  <td><?php echo $tgmoel . " [" . $rs['model_name'] . "]"; ?></td>
	  <td><?php echo $rs['customer']; ?></td>
	  <td><?php echo $rs['customer_part_no'] . " [" . $rs['customer_part_name'] . "]"; ?></td>
	  <td><?php echo $stdqty; ?></td>
	  <td><?php echo $splitqty; ?></td>
	</tr>
</table>

 <?php } else {
		echo "<br/><br/><br/><center><div class='table_comment' >No hava Data, please try again ";
	} ?>

 <?php } else {
	echo "<br/><br/><br/><center><div class='table_comment' >Please scan FG Tag  No. ";
} ?>

 <form id="scan" name="scan" method="post" action="" onsubmit="return false;"  autocomplete="off" >
   <table width="548" border="1" align="center" class="table01" >
	 <tr>
	   <td width="132" height="37"><div class="tmagin_right">Scan FG Tag No. :</div> </td>
	   <td width="400">
		 <input type="text" name="model" id="model" style=" width:180px;"   onkeypress="return ckKeyPresse(event);" />
		 <input type="button" name="btnscan" id="btnscan" value="Submit" class="myButton" onclick="validateSpTag(this.value)" />
		 <input type="hidden" name="nmodel" id="nmodel"  value="<?= isset($tgmoel) ? $tgmoel : '' ?>" /> 
		 <input type="hidden" name="hidprint" id="hidprint"  value="<?= isset($idpstag) ? $idpstag : '' ?>" /> 
		 <input type="hidden" name="hqtysplit" id="hqtysplit"  value="<?= isset($splitqty) ? $splitqty : '' ?>" />
		 <input type="hidden" name="scan2" id="scan2"  value="Submit" /> 
		 <input type="button" name="button3" id="button3" value="Cancel" class="myButton"  
		 onclick="window.location.href='index_fg.php?id=<?= base64_encode('fgprint_tag') ?>&ctagp=<?= isset($idpstag) ? $idpstag : '' ?>';"/>
	   </td>
	 </tr>
	 <tr>
	   <td height="28" colspan="2" align="center"> <div id="txtStatus"> </div></td>
	 </tr>
   </table>
</form>   

</div>
<div class="rightPane" align="center">
	<form id="form1" name="form1" method="post" action="">
<?php
$q = "SELECT tag_no ,CONCAT(sn_start,'-',sn_end) AS allserial,stag_qty
		FROM " . DB_DATABASE1 . ".fgt_supplier_tag_split 
		WHERE id_print_tag = '" . (isset($idpstag) ? $idpstag : '') . "'
		ORDER BY id_split DESC";

$qr = mysqli_query($con, $q);
$total = mysqli_num_rows($qr);
$i = 1;
if ($total <> 0) {
?>
<table width="47%" height="108" border="1" bordercolor="#CC9966"class="table01" align="center">
	<tr >
	  <th height="27" colspan="4">
	  <div align="center">Tag Reprinting</div>  </th>
	  </tr>
	  
	<tr>
	  <th width="5%" height="27">No.</th>
	  <th width="24%">Tag No</th>
	  <th width="47%">Serial </th>
	  <th width="24%">Tag Qty.</th>
	</tr>
	   <?php while ($rs = mysqli_fetch_array($qr)) { 
			$rtag = $rs['tag_no'];
			  ?>
	  <tr  <?php $v = 0; $v = $v + 1; echo icolor($v); ?>height="28" onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" align="center">
	  <td ><?= $i ?></td>
	  <td ><?= $rs['tag_no'] ?></td>
	  <td><?= $rs['allserial'] ?></td>
	  <td><?= $rs['stag_qty'] ?></td>
	</tr>
	 <?php
		$i++;
	}
	?>
  
  </table>
	  <div align="center">  <input type="submit" name="btnprint" id="btnprint" value="Print" />   
		   <input type="hidden" name="hidprintst" id="hidprintst" value="<?= isset($idpstag) ? $idpstag : '' ?>" />
		 </div>
  <?php
	} else {
		echo "<br/><br/><br/><center><div class='table_comment' >No hava Data  ";
	}
	?>
	 
 
	</form>
</div>
