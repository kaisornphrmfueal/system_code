<?php
//include('../includes/configure.php');
require_once '../includes/configure_host.php';
if(!empty($_GET["tcomb"]) && $_GET["tcomb"]<>"undefined"){
	
	$gtconv=$_GET["tcomb"];
	$gmodelsr=$_GET["modelsr"];
	$gmodel = substr($gmodelsr,0,15);
	$gserial=substr($gmodelsr,16,8);
	//a.tag_no,a.tag_qty,a.item_status,b.id_fg_tag_conversion, 
		  $sqlg="SELECT MIN(c.id_combine_serial),c.serial_label,d.tag_model_no
        FROM  ".DB_DATABASE1.".fgt_split_combine AS a 
		LEFT JOIN  ".DB_DATABASE1.".fgt_split_combine_fg_tag AS b ON a.id_combine=b.id_combine 
		LEFT JOIN  ".DB_DATABASE1.".fgt_split_combine_fg_tag_serial c ON b.id_fg_combine_tag =c.id_fg_combine_tag 
		  LEFT JOIN  ".DB_DATABASE1.".fgt_model d ON b.id_model =d.id_model
          WHERE b.id_fg_combine_tag ='$gtconv' AND serial_label_confirm IS  NULL   ";
		  $resultg = mysqli_query($con, $sqlg);

if(mysqli_num_rows($resultg)<>0){
		$rstg = mysqli_fetch_array($resultg);
		$serial = $rstg['serial_label'];
		$tagmodel = $rstg['tag_model_no'];
		if($tagmodel != $gmodel ){
			 echo "No";
			}elseif ($serial == $gserial) {
				echo "1";
			}else{
				echo "Wrong";
				//echo $serial ."=". $gserial ;
			//echo $sqlg;
			}//if($gserial-$rscht['mxtag']==1){

		
}else{
	 echo "Non";
	 // echo $sqlg;
	}
 }//  if(!empty($_GET["code"]) && $_GET["code"]<>"undefined"){


?>