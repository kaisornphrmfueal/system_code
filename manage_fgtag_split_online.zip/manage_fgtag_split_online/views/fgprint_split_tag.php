
<?php
if (!empty($_GET['idrep']) && $_GET['idrep'] == "rep") {

	$gtag_no=$_GET['tagno'];
	 $id_tagsplit=$_GET['reqid'];
	
	$sqldl = "UPDATE " . DB_DATABASE1 . ".fgt_split_fg_tag_conversion
			SET  emp_reprint='$user_login',date_reprint='" . date('Y-m-d H:i:s') . "'
			WHERE tag_no_new='" . $gtag_no . "' ";
	$qrdl = mysqli_query($con, $sqldl);

	
/*	
	$sqlu="UPDATE  ".DB_DATABASE1.".fgt_srv_tag SET status_print='Reprinted',who_reprint='".$station_name."', 
			 		date_reprint='".date('Y-m-d H:i:s')."' WHERE tag_no=$gtag_no";  //upload_status = '0',
			mysqli_query($con, $sqlu);*/
			//sprintTag
			 printTagSplit($gtag_no);
			//eprinTag
			log_hist($user_login,"Reprinted Combine Tag",$gtag_no,"fgt_tag","");
	gotopage("index_fg.php?id=" . base64_encode('fgprint_split_tag')."&stag=$id_tagsplit");
	
	
}
//--------------------------

if (!empty($_GET['idcanc']) && $_GET['idcanc'] == "cncl") {
/*	if($_GET['idproc']=='1'){
		$sqlutk="UPDATE  ".DB_DATABASE2.".rf_kanban_ticket SET
				 status_write=0, last_status='FG Split Cancle'
				 WHERE ticket_ref='$fg_ticket'";
		$qrtk=mysqli_query($con, $sqlutk); //Reserved
		
	}*/
		if($_GET['idproc']=='1'){ $pagedr="fgprint_split_special";
							   }else{  $pagedr="fgprint_split_normal"; }
	$sqldl = "UPDATE " . DB_DATABASE1 . ".fgt_split_fg_tag
			SET item_status=3,emp_id_delete='$user_login',date_delete='" . date('Y-m-d H:i:s') . "'
			WHERE id_fg_split='" . $_GET['reqid'] . "' ";
	$qrdl = mysqli_query($con, $sqldl);
	gotopage("index_fg.php?id=" . base64_encode($pagedr));
	
	
}


?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" type="text/JavaScript">
	function rePrint(stag,reqid){//(reqid)
  if(confirm('Do you want to Repritn F/G Trensfer Tag?')) { 
 //	alert(reqid);(
	 
    let linkenc =  btoa(unescape(encodeURIComponent("fgprint_split_tag")));
 window.location.href="index_fg.php?id="+ linkenc +"&reqid="+ reqid + "&idrep=rep&tagno="+ stag ; 
  }
  else {
     //'Cancel' is clicked
  }
}
	
	
	
	
window.onload = function() {
  document.getElementById("model").focus();
  document.getElementById("model").select();
}
function validate(form2) {   
	if(document.form2.model_code.value == ""){
			alert("Please input Model code");
			document.form2.model_code.focus();
			return (false);
	}else{  
			form2.button.disabled = true;  
			form2.button.value = 'Adding...';  
			return true;  
			}
}///function validate(form) {
function deleteRequest(reqid,idproc){//(reqid,idproc,ticket)
  if(confirm('Do you want to cancel Split Tag?')) { 
 	//alert(reqid);
	  
    let linkenc =  btoa(unescape(encodeURIComponent("fgprint_split_tag")));

    window.location.href="index_fg.php?id="+ linkenc +"&reqid="+ reqid + "&idcanc=cncl&idproc="+idproc;
  }
  else {
     //'Cancel' is clicked
  }
}
</script>
 <div  align="center">
<?php
if (!empty($_GET['stag'])) {
	$gstag = $_GET['stag'];
	//$g_processst = $_GET['idproc'];
	
	
	 $sql = "SELECT a.tag_no_original,a.tag_qty,a.item_status,a.separate_qty,b.id_model,b.model_code,
	 		DATE_FORMAT(d.date_work, '%d-%b-%Y') AS workdate ,
		  b.model_name,b.tag_model_no,b.customer,b.std_qty,SUM(IF( IFNULL(c.tag_no_new,0),  1,0 )) AS newtag_qty,
         b.customer_part_no,b.customer_part_name,b.model_picture,b.status_tag_printing,a.ticket_no,a.process_status,
		  IF(a.process_status='0', 'GMS Label Ref. ', 'Ticket No.')  AS gms_label_tk
          FROM ".DB_DATABASE1.".fgt_split_fg_tag  a 
		  LEFT JOIN ".DB_DATABASE1.".fgt_srv_tag d ON a.tag_no_original =d.tag_no
          LEFT JOIN ".DB_DATABASE1.".fgt_model b ON d.id_model =b.id_model 
		  LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion c ON a.id_fg_split =c.id_fg_split
          WHERE a.id_fg_split  ='" . $gstag . "' ";
	$qr = mysqli_query($con, $sql);
	$rs = mysqli_fetch_array($qr);
	$total = mysqli_num_rows($qr);
	if ($total <> 0) {
		$tgmoel = $rs['tag_model_no'];
		//$idpstag = $rs['id_print_tag'];
		$stdqty = $rs['std_qty'];
		$splitqty = $rs['separate_qty'];
		$tagqty = $rs['tag_qty'];
		 $tagsts = $rs['item_status'];
		$qrnewtag_qty = $rs['newtag_qty'];
		$orticket_no = $rs['ticket_no'];
		$g_processst = $rs['process_status'];
?>
 <form id="form1" name="form1" method="post" action="" autocomplete="off">
<table width="1203"  border="1" class="table01" align="center">
  <tr>
	<th height="27" colspan="9">Separate F/G Tranfer Tag and Supplier Tag</th>
  </tr>
	<tr>
	  <th width="117" height="25">Model Picture</th>
	  <th width="177">Tag No. Original</th>
	  <th width="177">Model No. (Tag)</th>
	  <th width="113">Customer </th>
	  <th width="149">Customer <br />
      Part No.  </th>
		<th width="113">Produce Date</th>
	  <th width="69">Standard  Qty.</th>
	  <th width="69">Tag  Qty.</th>
	  <th width="97">Separate Tag Qty/page</th>
	</tr>
	<tr align="center">
	  <td height="25">
		<?php  if (!empty($rs['model_picture'])) {
			echo "<img src='" . DIR_UPLOAD . DIR_MPIC . $rs['model_picture'] . "' />";
		}
		 ?>
	 </td>
	  <td><?php echo $rs['tag_no_original'] ; ?></td>
	  <td><?php echo $tgmoel . " [" . $rs['tag_no_original'] . "]"; ?></td>
	  <td><?php echo $rs['customer']; ?></td>
	  <td><?php echo $rs['customer_part_no'] . " [" . $rs['customer_part_name'] . "]"; ?></td>
		<td><?php echo $rs['workdate']; ?></td>
	  <td><?php echo $stdqty; ?></td>
	  <td><?php echo $tagqty; ?></td>
	  <td><?php echo $splitqty; ?></td>
	</tr>
	<tr align="center">
	  <td height="25" colspan="9">
		  <?php if($qrnewtag_qty=="0"){?>
		  <input type="button"  id="btn_cancel" name="btn_cancel" class="button5" 
		value="Cancel"     onclick="return deleteRequest(<?php echo $gstag;?> ,<?php echo $g_processst;?>);" >
	<!--	    <input type="button"  id="btn_cancel" name="btn_cancel" class="button5" 
		value="Cancel"     onclick="return deleteRequest(<?php echo $gstag;?>,<?php echo $g_processst;?>,<?php echo $orticket_no;?>);" >-->
	
	</input>
		<?php } //0= start, 1= spliting,  2= finished, 3=cancel ?>
	</td>
	  </tr>
</table>
</form>
 <?php } else {
		echo "<br/><br/><br/><center><div class='table_comment' >No hava Data, please try again ";
	} ?>

 <?php } else {
	echo "<br/><br/><br/><center><div class='table_comment' >Please scan FG Tag  No. ";
} ?>
 </div>

<div class="rightPane" align="center">

<?php
 $qtg = "SELECT a.tag_no_original,a.tag_qty,a.item_status,b.id_fg_tag_conversion,
		b.id_fg_split, b.tag_no_new, b.sn_start, b.sn_end, b.stag_qty,b.item_status,
		IFNULL(tag_no_new, '-') AS new_tag ,IFNULL(ticket_no_new, '-') AS new_ticket,
		b.item_status as conversion_status,
 		CASE WHEN b.item_status=0 THEN 'Pending' WHEN b.item_status =1 THEN 'Finished' 
		WHEN b.item_status=2  THEN 'Cancel' ELSE 'Available' END AS itemstatus,
		IF(ISNULL(b.emp_conversion), '-', CONCAT (c.name_en ,'(',b.emp_conversion,')' ))  AS convuser ,
		IF(ISNULL(b.emp_conversion), '-',CONCAT('[', DATE_FORMAT(b.date_conversion, '%d-%b-%Y %H:%i'),']')  )  AS conv_date ,
		IFNULL(CONCAT( e.name_en ,'[', DATE_FORMAT(b.date_reprint, '%d-%b-%Y %H:%i'),']'),'-') AS reprint_date 
          FROM ".DB_DATABASE1.".fgt_split_fg_tag  a 
          LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion b ON a.id_fg_split =b.id_fg_split
		  LEFT JOIN ".DB_DATABASESSO.".so_view_fttl_and_sub c ON b.emp_conversion =c.emp_id 
		  LEFT JOIN ".DB_DATABASESSO.".so_view_fttl_and_sub e ON b.emp_reprint = e.emp_id 
          WHERE  b.id_fg_split ='" . (isset($gstag) ? $gstag : '') . "'";

$qrtg = mysqli_query($con, $qtg);
$totaltg = mysqli_num_rows($qrtg);
$j = 1;
if ($totaltg <> 0) {
?>
<table width="1050px"  border="1" bordercolor="#CC9966"class="table01" align="center">
	<tr >
	  <th height="27" colspan="11">
	  <div align="center">F/G Transfer Tag Spliting</div>  </th>
	  </tr>
	  
	<tr>
	  <th width="4%" height="27">No.</th>
	  <th width="8%">New Tag No.</th>
	  <th width="10%"> Ticket No.</th>
	  <th width="10%">Split by</th>
	  <th width="9%">Serial Start</th>
	  <th width="9%">Serial End</th>
	  <th width="6%">Tag Qty.</th>
	  <th width="9%">Status Printing</th>
	  <th width="14%">Re-Print By</th>
	  <th width="10%">Split Tag</th>
	  <th width="11%">Reprint</th>
	</tr>
	   <?php while ($rstg = mysqli_fetch_array($qrtg)) { 
			$rtag = $rstg['tag_no_original'];
			$idsplit = $rstg['id_fg_split'];
			$conversion_status = $rstg['conversion_status'];
			$id_conversion = $rstg['id_fg_tag_conversion']; 
			  ?>
	  <tr  <?php $v = 0; $v = $v + 1; echo icolor($v); ?>height="28" onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" align="center">
	  <td ><?php echo $j ;?></td>
	  <td ><a href="index_fg.php?id=<?=base64_encode('fgprint_split_tag')?>&stag=<?php echo $gstag ;?>&idconv=<?php echo $id_conversion;?>">  <?php echo $rstg['new_tag']; ?>
		  </a></td>
	  <td ><?php echo $rstg['new_ticket']; ?></td>
	  <td ><?php echo $rstg['convuser']; ?></td>
	  <td><?php echo $rstg['sn_start'] ;?></td>
	  <td><?php echo $rstg['sn_end']; ?></td>
	  <td><?php echo $rstg['stag_qty'] ;?></td>
	  <td><?php echo $rstg['itemstatus'] ;?></td>
	  <td><?= htmlspecialchars($rstg['reprint_date']) ?></td>
	  <td> <?php if($conversion_status=="0"){?>
		  <a href="index_fg.php?id=<?=base64_encode('fgprint_split_tag_printing') ?>&idconv=<?= $id_conversion?>&idproc=<?= $g_processst?>"><img src="../images/scan.png" width="52" />   </a>
		  <?php } //0=Remaining,  1= splitied, 2=combined ?></td>
	  <td> 
		        <?php  if($rs['item_status']=="2"){?> 
		  <input type="button"  id="btn_reprint" name="btn_reprint" class="button3" 
		value="Re-Print"     onclick="return rePrint(<?php echo $rstg['new_tag'];?>,<?php echo $idsplit;?> );" >
		 
		</input>
		<?php } //0= start, 1= spliting,  2= finished, 3=cancel ?>
                     
		  </td>
	</tr>
	 <?php
		$j++;
	}
	?>
  
  </table>
	  
  <?php
	} else {
		echo "<br/><br/><br/><center><div class='table_comment' >No hava Data  ";
	}
	?>
	 
 
  <button onclick="window.location.href='index_fg.php?id=<?php echo base64_encode('fgsplitreport');?>'">F/G Transfer Tag Spliting Report</button> 
				<br/>	<br/>	
	
	
<?php
	if(!empty($_GET['idconv'])){
		
			
 $qtg = "SELECT c.id_fg_tag_conversion,serial_label, c.gms_label_ref, c.serial_label_confirm, c.date_scan_confirm, c.emp_scan_confirm,
IF(ISNULL(c.emp_scan_confirm), '-', CONCAT (a.name_en ,'(',c.emp_scan_confirm,')' ))  AS convuser ,
IF(ISNULL(c.emp_scan_confirm), '-',CONCAT('[', DATE_FORMAT(c.date_scan_confirm, '%d-%b-%Y %H:%i'),']')  )  AS conv_date ,  IF(gms_label_ref_barcode = '', '-', gms_label_ref_barcode) AS gms_label_ref_bc,
 IF(gms_label_ref_barcode = '',  'GMS Label Ref. ', 'Ticket No.') AS gms_label_tk
FROM ".DB_DATABASE1.".fgt_split_fg_tag_conversion b 
LEFT JOIN ".DB_DATABASE1.".fgt_split_fg_tag_conversion_serial c ON b.id_fg_tag_conversion=c.id_fg_tag_conversion 
LEFT JOIN ".DB_DATABASESSO.".so_view_fttl_and_sub a ON c.emp_scan_confirm =a.emp_id 
WHERE c.id_fg_tag_conversion ='".$_GET['idconv']."' AND gms_label_ref IS NOT NULL  ";
$qrtg = mysqli_query($con, $qtg);
$totaltg = mysqli_num_rows($qrtg);
$j = 1;
if ($totaltg <> 0) {
?>
<table width="950px"  border="1" bordercolor="#CC9966"class="table01" align="center">
	<tr>
	  <th height="27" colspan="7">
	  <div align="center">FG Tag Spliting Serial Confirmed</div>  </th>
	  </tr>
	  
	<tr>


	  <th width="5%" height="27">No.</th>
	  <th width="15%">Serial </th>
	  <th width="12%">GMS Label Ref. Barcode</th>
	  <th width="12%"><?php echo $rs['gms_label_tk'] ;?></th>
	  <th width="16%">Serial Label Confirm</th>
	  <th width="13%">Scan by</th>
	  <th width="16%">Scan Date</th>
    </tr>
	   <?php while ($rstg = mysqli_fetch_array($qrtg)) { 
			  ?>
	  <tr  <?php $v = 0; $v = $v + 1; echo icolor($v); ?>height="28" onMouseOver="className=&quot;over&quot;"  onMouseOut="className=&quot;&quot;" align="center">
	  <td ><?php echo $j ;?></td>
	  <td ><?php echo $rstg['serial_label'] ;?></td>
	  <td ><?php echo  $rstg['gms_label_ref_bc'] ;?></td>
	  <td ><?php echo $rstg['gms_label_ref'] ;?></td>
	  <td><?php echo $rstg['serial_label_confirm'] ;?></td>
	  <td ><?php echo $rstg['convuser']; ?></td>
	  <td><?php echo $rstg['conv_date']; ?></td>
    </tr>
	 <?php
		$j++;
	}
	?>
  
  </table>
	  
  <?php
			} else {
				//echo "<br/><br/><br/><center><div class='table_comment' >No hava Data  ";
			}
	
	}//if(!empty($_GET['idconv'])){
?>
</div>




